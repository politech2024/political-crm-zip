import { pgTable, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const assemblyDataTable = pgTable("assembly_data", {
  assembly_name: text("assembly_name").primaryKey(),
  reservation_type: text("reservation_type"),
  area_type: text("area_type"),
  total_voters: integer("total_voters"),
  male_voters: integer("male_voters"),
  female_voters: integer("female_voters"),
  other_voters: integer("other_voters"),
  total_booths: integer("total_booths"),
  urban_booths: integer("urban_booths"),
  rural_booths: integer("rural_booths"),
  sensitive_booths: integer("sensitive_booths"),
  mla_name: text("mla_name"),
  mla_party: text("mla_party"),
  winning_margin: integer("winning_margin"),
  winning_margin_pct: real("winning_margin_pct"),
  vote_share_pct: real("vote_share_pct"),
  term_since: integer("term_since"),
  previous_mla_name: text("previous_mla_name"),
  linked_mp: text("linked_mp"),
  party_strength_pct: real("party_strength_pct"),
  org_score: integer("org_score"),
  campaign_score: integer("campaign_score"),
  ground_score: integer("ground_score"),
  media_score: integer("media_score"),
  d2d_coverage_pct: real("d2d_coverage_pct"),
  issue_resolution_rate: real("issue_resolution_rate"),
  sentiment_positive: integer("sentiment_positive"),
  sentiment_neutral: integer("sentiment_neutral"),
  sentiment_negative: integer("sentiment_negative"),
  d2d_villages_covered: integer("d2d_villages_covered"),
  d2d_villages_total: integer("d2d_villages_total"),
  updated_at: timestamp("updated_at").defaultNow(),
});

export const boothRecordsTable = pgTable("booth_records", {
  id: text("id").primaryKey(),
  assembly_name: text("assembly_name").notNull(),
  booth_number: text("booth_number").notNull(),
  village_ward: text("village_ward"),
  status: text("status").default("no_data"),
  total_voters: integer("total_voters"),
  male_voters: integer("male_voters"),
  female_voters: integer("female_voters"),
  worker_name: text("worker_name"),
  notes: text("notes"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at"),
});

export const insertAssemblyDataSchema = createInsertSchema(assemblyDataTable).omit({ updated_at: true });
export const insertBoothRecordSchema = createInsertSchema(boothRecordsTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type AssemblyData = typeof assemblyDataTable.$inferSelect;
export type InsertAssemblyData = z.infer<typeof insertAssemblyDataSchema>;
export type BoothRecord = typeof boothRecordsTable.$inferSelect;
export type InsertBoothRecord = z.infer<typeof insertBoothRecordSchema>;
