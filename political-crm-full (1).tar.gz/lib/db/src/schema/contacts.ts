import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const contactsTable = pgTable("contacts", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  first_name: text("first_name"),
  middle_name: text("middle_name"),
  last_name: text("last_name"),
  mobile: text("mobile").notNull(),
  whatsapp_number: text("whatsapp_number"),
  email: text("email"),
  birthday: text("birthday"),
  gender: text("gender"),
  district: text("district"),
  constituency: text("constituency"),
  lok_sabha_constituency: text("lok_sabha_constituency"),
  booth_number: text("booth_number"),
  village_ward: text("village_ward"),
  political_party: text("political_party"),
  party_frontal: text("party_frontal"),
  party_department: text("party_department"),
  political_affiliation: text("political_affiliation"),
  caste: text("caste"),
  religion: text("religion"),
  leader_group: text("leader_group"),
  second_leader: text("second_leader"),
  non_political_org: text("non_political_org"),
  voter_id: text("voter_id"),
  additional_mobiles: text("additional_mobiles"),
  family_members: text("family_members"),
  volunteer: boolean("volunteer").default(false),
  facebook: text("facebook"),
  instagram: text("instagram"),
  twitter: text("twitter"),
  notes: text("notes"),
  contact_status: text("contact_status").default("active"),
  source: text("source"),
  import_batch: text("import_batch"),
  photo_url: text("photo_url"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at"),
});

export const insertContactSchema = createInsertSchema(contactsTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contactsTable.$inferSelect;
