import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const issuesTable = pgTable("issues", {
  id: text("id").primaryKey(),
  issue_title: text("issue_title").notNull(),
  issue_description: text("issue_description"),
  issue_status: text("issue_status").notNull().default("new"),
  issue_priority: text("issue_priority"),
  contact_id: text("contact_id"),
  contact_name: text("contact_name"),
  district: text("district"),
  constituency: text("constituency"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at"),
});

export const insertIssueSchema = createInsertSchema(issuesTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type InsertIssue = z.infer<typeof insertIssueSchema>;
export type Issue = typeof issuesTable.$inferSelect;
