import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const messagesTable = pgTable("messages", {
  id: text("id").primaryKey(),
  message_content: text("message_content").notNull(),
  message_channel: text("message_channel").notNull().default("whatsapp"),
  recipient_count: integer("recipient_count").notNull().default(0),
  message_sent_at: timestamp("message_sent_at").defaultNow().notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messagesTable).omit({
  id: true,
  created_at: true,
  message_sent_at: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messagesTable.$inferSelect;
