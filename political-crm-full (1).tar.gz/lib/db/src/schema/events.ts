import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const eventsTable = pgTable("events", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  activity_type: text("activity_type").notNull().default("meeting"),
  event_date: text("event_date").notNull(),
  start_time: text("start_time"),
  end_time: text("end_time"),
  location: text("location"),
  district: text("district"),
  constituency: text("constituency"),
  booth_number: text("booth_number"),
  expected_attendance: integer("expected_attendance"),
  priority: text("priority").default("normal"),
  reminder: boolean("reminder").default(false),
  linked_issue: text("linked_issue"),
  notes: text("notes"),
  source: text("source"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at"),
});

export const insertEventSchema = createInsertSchema(eventsTable).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type CalendarEvent = typeof eventsTable.$inferSelect;
