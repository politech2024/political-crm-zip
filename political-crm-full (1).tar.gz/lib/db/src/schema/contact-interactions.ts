import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const contactInteractionsTable = pgTable("contact_interactions", {
  id: text("id").primaryKey(),
  contact_id: text("contact_id").notNull(),
  type: text("type").notNull(),
  notes: text("notes"),
  outcome: text("outcome"),
  interaction_date: text("interaction_date").notNull(),
  scheduled_for: text("scheduled_for"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export type ContactInteraction = typeof contactInteractionsTable.$inferSelect;
