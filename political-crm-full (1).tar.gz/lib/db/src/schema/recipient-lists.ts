import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

export const recipientListsTable = pgTable("recipient_lists", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  filters: text("filters").notNull().default("{}"),
  contact_count: integer("contact_count").default(0),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at"),
});

export type RecipientList = typeof recipientListsTable.$inferSelect;
