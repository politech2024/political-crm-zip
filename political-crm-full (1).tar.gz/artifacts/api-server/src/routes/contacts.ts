import { Router, type IRouter } from "express";
import { db, contactsTable, issuesTable, contactInteractionsTable } from "@workspace/db";
import { eq, inArray, and, isNotNull, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

const router: IRouter = Router();

// ─── List contacts ────────────────────────────────────────────────────────────
router.get("/contacts", async (req, res) => {
  try {
    const { party, caste, district, assembly, search, volunteers, contact_status } = req.query as Record<string, string>;
    let contacts = await db.select().from(contactsTable).orderBy(contactsTable.created_at);

    if (party) contacts = contacts.filter(c => c.political_party === party);
    if (caste) contacts = contacts.filter(c => c.caste === caste);
    if (district) contacts = contacts.filter(c => c.district?.toLowerCase().includes(district.toLowerCase()));
    if (assembly) contacts = contacts.filter(c => c.constituency?.toLowerCase().includes(assembly.toLowerCase()));
    if (volunteers === "true") contacts = contacts.filter(c => c.volunteer === true);
    if (contact_status) contacts = contacts.filter(c => (c.contact_status || "active") === contact_status);
    if (search) {
      const s = search.toLowerCase();
      contacts = contacts.filter(c =>
        c.name?.toLowerCase().includes(s) ||
        c.mobile?.includes(s) ||
        c.district?.toLowerCase().includes(s) ||
        c.constituency?.toLowerCase().includes(s) ||
        c.village_ward?.toLowerCase().includes(s)
      );
    }

    res.json({ success: true, data: contacts.map(fmt), total: contacts.length });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Export CSV ───────────────────────────────────────────────────────────────
router.get("/contacts/export", async (req, res) => {
  try {
    const { party, caste, district, volunteers } = req.query as Record<string, string>;
    let contacts = await db.select().from(contactsTable).orderBy(contactsTable.created_at);
    if (party) contacts = contacts.filter(c => c.political_party === party);
    if (caste) contacts = contacts.filter(c => c.caste === caste);
    if (district) contacts = contacts.filter(c => c.district === district);
    if (volunteers === "true") contacts = contacts.filter(c => c.volunteer === true);

    const headers = ["Name","Mobile","WhatsApp","Email","Birthday","Gender","Caste","Religion","Political Party","Affiliation","Leader Group","Second Leader","Non-Political Org","Village/Ward","Booth Number","District","Assembly Constituency","Lok Sabha","Facebook","Instagram","Twitter","Volunteer","Notes","Source","Created At"];
    const rows = contacts.map(c => [
      c.name, c.mobile, c.whatsapp_number, c.email, c.birthday, c.gender,
      c.caste, c.religion, c.political_party, c.political_affiliation,
      c.leader_group, c.second_leader, c.non_political_org,
      c.village_ward, c.booth_number, c.district,
      c.constituency, c.lok_sabha_constituency, c.facebook, c.instagram, c.twitter,
      c.volunteer ? "Yes" : "No", c.notes, c.source,
      c.created_at instanceof Date ? c.created_at.toISOString() : c.created_at,
    ]);
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="contacts_${new Date().toISOString().slice(0,10)}.csv"`);
    res.send(csv);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Bulk import ──────────────────────────────────────────────────────────────
router.post("/contacts/import", async (req, res) => {
  try {
    const { records, import_batch } = req.body;
    if (!Array.isArray(records) || !records.length) {
      return res.status(400).json({ success: false, error: "records array required" });
    }
    const batchId = import_batch || randomUUID();
    const validRecords = records.filter((r: any) => r.name && r.mobile).map((r: any) => ({
      id: randomUUID(), name: r.name, mobile: r.mobile,
      whatsapp_number: r.whatsapp_number || null, email: r.email || null,
      birthday: r.birthday || null, gender: r.gender || null,
      district: r.district || null, constituency: r.constituency || null,
      lok_sabha_constituency: r.lok_sabha_constituency || null, booth_number: r.booth_number || null,
      village_ward: r.village_ward || null, political_party: r.political_party || null,
      political_affiliation: r.political_affiliation || null, caste: r.caste || null,
      religion: r.religion || null, leader_group: r.leader_group || null,
      second_leader: r.second_leader || null, non_political_org: r.non_political_org || null,
      volunteer: r.volunteer === true || r.volunteer === "true",
      facebook: r.facebook || null, instagram: r.instagram || null, twitter: r.twitter || null,
      notes: r.notes || null, source: r.source || "csv_import",
      import_batch: batchId,
    }));
    if (validRecords.length > 0) await db.insert(contactsTable).values(validRecords);
    res.json({ success: true, imported: validRecords.length, import_batch: batchId });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Bulk delete by IDs ───────────────────────────────────────────────────────
router.delete("/contacts/bulk", async (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || !ids.length) {
      return res.status(400).json({ success: false, error: "ids array required" });
    }
    await db.delete(contactsTable).where(inArray(contactsTable.id, ids));
    res.json({ success: true, deleted: ids.length });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Last import batch info ───────────────────────────────────────────────────
router.get("/contacts/import-batch/latest", async (req, res) => {
  try {
    // Find the most recent import_batch value
    const [latest] = await db
      .select({ import_batch: contactsTable.import_batch, created_at: contactsTable.created_at })
      .from(contactsTable)
      .where(isNotNull(contactsTable.import_batch))
      .orderBy(desc(contactsTable.created_at))
      .limit(1);
    if (!latest?.import_batch) {
      return res.json({ success: true, data: null });
    }
    const rows = await db
      .select({ id: contactsTable.id })
      .from(contactsTable)
      .where(eq(contactsTable.import_batch, latest.import_batch));
    res.json({ success: true, data: { import_batch: latest.import_batch, count: rows.length, created_at: latest.created_at } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Delete last import batch ─────────────────────────────────────────────────
router.delete("/contacts/import-batch/latest", async (req, res) => {
  try {
    const [latest] = await db
      .select({ import_batch: contactsTable.import_batch })
      .from(contactsTable)
      .where(isNotNull(contactsTable.import_batch))
      .orderBy(desc(contactsTable.created_at))
      .limit(1);
    if (!latest?.import_batch) {
      return res.json({ success: true, deleted: 0 });
    }
    await db.delete(contactsTable).where(eq(contactsTable.import_batch, latest.import_batch));
    res.json({ success: true, deleted: true, import_batch: latest.import_batch });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Get single contact ───────────────────────────────────────────────────────
router.get("/contacts/:id", async (req, res) => {
  try {
    const [contact] = await db.select().from(contactsTable).where(eq(contactsTable.id, req.params.id));
    if (!contact) return res.status(404).json({ success: false, error: "Not found" });
    res.json({ success: true, data: fmt(contact) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Create contact ───────────────────────────────────────────────────────────
router.post("/contacts", async (req, res) => {
  try {
    const b = req.body;
    if (!b.name || !b.mobile) return res.status(400).json({ success: false, error: "name and mobile required" });
    // Default WhatsApp to primary mobile if not provided
    const whatsapp = b.whatsapp_number || b.mobile;
    const [contact] = await db.insert(contactsTable).values({
      id: randomUUID(), name: b.name, mobile: b.mobile,
      first_name: b.first_name || null, middle_name: b.middle_name || null, last_name: b.last_name || null,
      whatsapp_number: whatsapp || null, email: b.email || null,
      birthday: b.birthday || null, gender: b.gender || null,
      district: b.district || null, constituency: b.constituency || null,
      lok_sabha_constituency: b.lok_sabha_constituency || null, booth_number: b.booth_number || null,
      village_ward: b.village_ward || null, political_party: b.political_party || null,
      party_frontal: b.party_frontal || null, party_department: b.party_department || null,
      political_affiliation: b.political_affiliation || null, caste: b.caste || null,
      religion: b.religion || null, leader_group: b.leader_group || null,
      second_leader: b.second_leader || null, non_political_org: b.non_political_org || null,
      voter_id: b.voter_id || null,
      additional_mobiles: b.additional_mobiles ? JSON.stringify(b.additional_mobiles) : null,
      family_members: b.family_members ? JSON.stringify(b.family_members) : null,
      volunteer: b.volunteer === true || b.volunteer === "true",
      facebook: b.facebook || null, instagram: b.instagram || null, twitter: b.twitter || null,
      notes: b.notes || null, source: b.source || "manual",
    }).returning();
    res.status(201).json({ success: true, data: fmt(contact) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Update contact ───────────────────────────────────────────────────────────
router.put("/contacts/:id", async (req, res) => {
  try {
    const b = req.body;
    const patch: Record<string, any> = { ...b, updated_at: new Date() };
    // JSON-stringify array fields (stored as text in DB)
    if (b.additional_mobiles !== undefined) patch.additional_mobiles = b.additional_mobiles ? JSON.stringify(b.additional_mobiles) : null;
    if (b.family_members !== undefined) patch.family_members = b.family_members ? JSON.stringify(b.family_members) : null;
    const [updated] = await db.update(contactsTable).set(patch).where(eq(contactsTable.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ success: false, error: "Not found" });
    res.json({ success: true, data: fmt(updated) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Delete contact ───────────────────────────────────────────────────────────
router.delete("/contacts/:id", async (req, res) => {
  try {
    await db.delete(contactsTable).where(eq(contactsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Get interactions for a contact ──────────────────────────────────────────
router.get("/contacts/:id/interactions", async (req, res) => {
  try {
    const rows = await db.select().from(contactInteractionsTable)
      .where(eq(contactInteractionsTable.contact_id, req.params.id))
      .orderBy(contactInteractionsTable.interaction_date);
    res.json({ success: true, data: rows.map(fmtInteraction) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Add interaction ──────────────────────────────────────────────────────────
router.post("/contacts/:id/interactions", async (req, res) => {
  try {
    const { type, notes, outcome, interaction_date, scheduled_for } = req.body;
    if (!type || !interaction_date) return res.status(400).json({ success: false, error: "type and interaction_date required" });
    const [row] = await db.insert(contactInteractionsTable).values({
      id: randomUUID(), contact_id: req.params.id,
      type, notes: notes || null, outcome: outcome || null,
      interaction_date, scheduled_for: scheduled_for || null,
    }).returning();
    res.status(201).json({ success: true, data: fmtInteraction(row) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Delete interaction ───────────────────────────────────────────────────────
router.delete("/contacts/:id/interactions/:iid", async (req, res) => {
  try {
    await db.delete(contactInteractionsTable).where(eq(contactInteractionsTable.id, req.params.iid));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Get issues for a contact ─────────────────────────────────────────────────
router.get("/contacts/:id/issues", async (req, res) => {
  try {
    const [contact] = await db.select().from(contactsTable).where(eq(contactsTable.id, req.params.id));
    if (!contact) return res.status(404).json({ success: false, error: "Not found" });
    let issues = await db.select().from(issuesTable).orderBy(issuesTable.created_at);
    issues = issues.filter(i =>
      i.contact_id === contact.id ||
      (i.contact_name && contact.name && i.contact_name.toLowerCase().includes(contact.name.toLowerCase().split(" ")[0]))
    );
    res.json({ success: true, data: issues });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function fmt(c: any) {
  const safeJson = (v: any) => { try { return v ? JSON.parse(v) : null; } catch { return null; } };
  return {
    ...c,
    additional_mobiles: safeJson(c.additional_mobiles),
    family_members: safeJson(c.family_members),
    created_at: c.created_at instanceof Date ? c.created_at.toISOString() : c.created_at,
    updated_at: c.updated_at instanceof Date ? c.updated_at.toISOString() : c.updated_at,
  };
}

function fmtInteraction(i: any) {
  return {
    ...i,
    created_at: i.created_at instanceof Date ? i.created_at.toISOString() : i.created_at,
  };
}

export default router;
