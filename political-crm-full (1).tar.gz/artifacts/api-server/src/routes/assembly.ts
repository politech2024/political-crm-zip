import { Router, type IRouter } from "express";
import { db, assemblyDataTable, boothRecordsTable } from "@workspace/db";
import { randomUUID } from "crypto";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/assembly-data/:name", async (req, res) => {
  try {
    const name = decodeURIComponent(req.params.name);
    const [row] = await db.select().from(assemblyDataTable).where(eq(assemblyDataTable.assembly_name, name));
    res.json({ success: true, data: row || null });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/assembly-data/:name", async (req, res) => {
  try {
    const name = decodeURIComponent(req.params.name);
    const body = req.body;
    const [existing] = await db.select().from(assemblyDataTable).where(eq(assemblyDataTable.assembly_name, name));

    const payload = {
      assembly_name: name,
      reservation_type: body.reservation_type ?? existing?.reservation_type ?? null,
      area_type: body.area_type ?? existing?.area_type ?? null,
      total_voters: body.total_voters != null ? Number(body.total_voters) : (existing?.total_voters ?? null),
      male_voters: body.male_voters != null ? Number(body.male_voters) : (existing?.male_voters ?? null),
      female_voters: body.female_voters != null ? Number(body.female_voters) : (existing?.female_voters ?? null),
      other_voters: body.other_voters != null ? Number(body.other_voters) : (existing?.other_voters ?? null),
      total_booths: body.total_booths != null ? Number(body.total_booths) : (existing?.total_booths ?? null),
      urban_booths: body.urban_booths != null ? Number(body.urban_booths) : (existing?.urban_booths ?? null),
      rural_booths: body.rural_booths != null ? Number(body.rural_booths) : (existing?.rural_booths ?? null),
      sensitive_booths: body.sensitive_booths != null ? Number(body.sensitive_booths) : (existing?.sensitive_booths ?? null),
      mla_name: body.mla_name ?? existing?.mla_name ?? null,
      mla_party: body.mla_party ?? existing?.mla_party ?? null,
      winning_margin: body.winning_margin != null ? Number(body.winning_margin) : (existing?.winning_margin ?? null),
      winning_margin_pct: body.winning_margin_pct != null ? Number(body.winning_margin_pct) : (existing?.winning_margin_pct ?? null),
      vote_share_pct: body.vote_share_pct != null ? Number(body.vote_share_pct) : (existing?.vote_share_pct ?? null),
      term_since: body.term_since != null ? Number(body.term_since) : (existing?.term_since ?? null),
      previous_mla_name: body.previous_mla_name ?? existing?.previous_mla_name ?? null,
      linked_mp: body.linked_mp ?? existing?.linked_mp ?? null,
      party_strength_pct: body.party_strength_pct != null ? Number(body.party_strength_pct) : (existing?.party_strength_pct ?? null),
      org_score: body.org_score != null ? Number(body.org_score) : (existing?.org_score ?? null),
      campaign_score: body.campaign_score != null ? Number(body.campaign_score) : (existing?.campaign_score ?? null),
      ground_score: body.ground_score != null ? Number(body.ground_score) : (existing?.ground_score ?? null),
      media_score: body.media_score != null ? Number(body.media_score) : (existing?.media_score ?? null),
      d2d_coverage_pct: body.d2d_coverage_pct != null ? Number(body.d2d_coverage_pct) : (existing?.d2d_coverage_pct ?? null),
      issue_resolution_rate: body.issue_resolution_rate != null ? Number(body.issue_resolution_rate) : (existing?.issue_resolution_rate ?? null),
      sentiment_positive: body.sentiment_positive != null ? Number(body.sentiment_positive) : (existing?.sentiment_positive ?? null),
      sentiment_neutral: body.sentiment_neutral != null ? Number(body.sentiment_neutral) : (existing?.sentiment_neutral ?? null),
      sentiment_negative: body.sentiment_negative != null ? Number(body.sentiment_negative) : (existing?.sentiment_negative ?? null),
      d2d_villages_covered: body.d2d_villages_covered != null ? Number(body.d2d_villages_covered) : (existing?.d2d_villages_covered ?? null),
      d2d_villages_total: body.d2d_villages_total != null ? Number(body.d2d_villages_total) : (existing?.d2d_villages_total ?? null),
      updated_at: new Date(),
    };

    if (existing) {
      const [row] = await db.update(assemblyDataTable).set(payload).where(eq(assemblyDataTable.assembly_name, name)).returning();
      res.json({ success: true, data: row });
    } else {
      const [row] = await db.insert(assemblyDataTable).values(payload).returning();
      res.status(201).json({ success: true, data: row });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get("/booth-records/:name", async (req, res) => {
  try {
    const name = decodeURIComponent(req.params.name);
    const rows = await db.select().from(boothRecordsTable).where(eq(boothRecordsTable.assembly_name, name));
    res.json({ success: true, data: rows });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/booth-records", async (req, res) => {
  try {
    const { assembly_name, booth_number, village_ward, status, total_voters,
            male_voters, female_voters, worker_name, notes } = req.body;
    if (!assembly_name || !booth_number) {
      return res.status(400).json({ success: false, error: "assembly_name and booth_number required" });
    }
    const [existing] = await db.select().from(boothRecordsTable)
      .where(eq(boothRecordsTable.assembly_name, assembly_name));

    const existingBooth = (await db.select().from(boothRecordsTable)
      .where(eq(boothRecordsTable.assembly_name, assembly_name)))
      .find(b => b.booth_number === String(booth_number));

    if (existingBooth) {
      const [row] = await db.update(boothRecordsTable).set({
        village_ward: village_ward || existingBooth.village_ward,
        status: status || existingBooth.status,
        total_voters: total_voters != null ? Number(total_voters) : existingBooth.total_voters,
        male_voters: male_voters != null ? Number(male_voters) : existingBooth.male_voters,
        female_voters: female_voters != null ? Number(female_voters) : existingBooth.female_voters,
        worker_name: worker_name || existingBooth.worker_name,
        notes: notes || existingBooth.notes,
        updated_at: new Date(),
      }).where(eq(boothRecordsTable.id, existingBooth.id)).returning();
      return res.json({ success: true, data: row });
    }

    const [row] = await db.insert(boothRecordsTable).values({
      id: randomUUID(),
      assembly_name,
      booth_number: String(booth_number),
      village_ward: village_ward || null,
      status: status || "no_data",
      total_voters: total_voters != null ? Number(total_voters) : null,
      male_voters: male_voters != null ? Number(male_voters) : null,
      female_voters: female_voters != null ? Number(female_voters) : null,
      worker_name: worker_name || null,
      notes: notes || null,
    }).returning();
    res.status(201).json({ success: true, data: row });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
