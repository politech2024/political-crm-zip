import { Router, type IRouter } from "express";
import healthRouter from "./health";
import contactsRouter from "./contacts";
import issuesRouter from "./issues";
import messagesRouter from "./messages";
import statsRouter from "./stats";
import eventsRouter from "./events";
import assemblyRouter from "./assembly";
import aiIntakeRouter from "./ai-intake";
import storageRouter from "./storage";
import recipientListsRouter from "./recipient-lists";

const router: IRouter = Router();

router.use(healthRouter);
router.use(contactsRouter);
router.use(issuesRouter);
router.use(messagesRouter);
router.use(statsRouter);
router.use(eventsRouter);
router.use(assemblyRouter);
router.use(aiIntakeRouter);
router.use(storageRouter);
router.use(recipientListsRouter);

export default router;
