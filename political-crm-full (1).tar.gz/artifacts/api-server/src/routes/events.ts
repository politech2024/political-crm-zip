import { Router, type IRouter } from "express";
import { db, eventsTable } from "@workspace/db";
import { randomUUID } from "crypto";
import { eq, asc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/events", async (req, res) => {
  try {
    const events = await db.select().from(eventsTable).orderBy(asc(eventsTable.event_date));
    res.json({ success: true, data: events.map(fmt) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/events", async (req, res) => {
  try {
    const { title, activity_type, event_date, start_time, end_time, location,
            district, constituency, booth_number, expected_attendance, priority,
            reminder, linked_issue, notes, source } = req.body;
    if (!title || !event_date) {
      return res.status(400).json({ success: false, error: "title and event_date required" });
    }
    const [ev] = await db.insert(eventsTable).values({
      id: randomUUID(),
      title,
      activity_type: activity_type || "meeting",
      event_date,
      start_time: start_time || null,
      end_time: end_time || null,
      location: location || null,
      district: district || null,
      constituency: constituency || null,
      booth_number: booth_number || null,
      expected_attendance: expected_attendance ? Number(expected_attendance) : null,
      priority: priority || "normal",
      reminder: reminder === true || reminder === "true",
      linked_issue: linked_issue || null,
      notes: notes || null,
      source: source || null,
    }).returning();
    res.status(201).json({ success: true, data: fmt(ev) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.put("/events/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const fields: any = {};
    const allowed = ["title","activity_type","event_date","start_time","end_time","location",
                     "district","constituency","booth_number","expected_attendance","priority",
                     "reminder","linked_issue","notes"];
    for (const k of allowed) {
      if (req.body[k] !== undefined) fields[k] = req.body[k];
    }
    fields.updated_at = new Date();
    const [ev] = await db.update(eventsTable).set(fields).where(eq(eventsTable.id, id)).returning();
    if (!ev) return res.status(404).json({ success: false, error: "not found" });
    res.json({ success: true, data: fmt(ev) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.delete("/events/:id", async (req, res) => {
  try {
    await db.delete(eventsTable).where(eq(eventsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function fmt(e: any) {
  return {
    ...e,
    created_at: e.created_at instanceof Date ? e.created_at.toISOString() : e.created_at,
    updated_at: e.updated_at instanceof Date ? e.updated_at.toISOString() : e.updated_at,
  };
}

export default router;
