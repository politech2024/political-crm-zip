import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.post("/ai-intake", async (req, res) => {
  const baseUrl = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
  const apiKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;

  if (!baseUrl || !apiKey) {
    return res.status(503).json({
      success: false,
      error: "Anthropic AI integration not configured",
      fallback: true,
    });
  }

  const { system_prompt, user_input } = req.body;
  if (!user_input) {
    return res.status(400).json({ success: false, error: "user_input required" });
  }

  const apiUrl = `${baseUrl.replace(/\/$/, "")}/v1/messages`;

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: system_prompt + "\n\nInput text:\n" + user_input,
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: errText, fallback: true });
    }

    const data: any = await response.json();
    const text = data.content?.map((b: any) => b.text || "").join("") || "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return res.status(422).json({ success: false, error: "No JSON in response", fallback: true });
    }
    const parsed = JSON.parse(jsonMatch[0]);
    res.json({ success: true, data: parsed });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, fallback: true });
  }
});

export default router;
