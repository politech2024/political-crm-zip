import { Router, type IRouter } from "express";
import { db, recipientListsTable, contactsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const router: IRouter = Router();

function applyFilters(contacts: any[], filters: Record<string, any>) {
  let result = [...contacts];
  if (filters.party)         result = result.filter(c => c.political_party === filters.party);
  if (filters.district)      result = result.filter(c => c.district?.toLowerCase() === filters.district.toLowerCase());
  if (filters.assembly)      result = result.filter(c => c.constituency?.toLowerCase().includes(filters.assembly.toLowerCase()));
  if (filters.lok_sabha)     result = result.filter(c => c.lok_sabha_constituency?.toLowerCase().includes(filters.lok_sabha.toLowerCase()));
  if (filters.caste)         result = result.filter(c => c.caste === filters.caste);
  if (filters.religion)      result = result.filter(c => c.religion === filters.religion);
  if (filters.gender)        result = result.filter(c => c.gender === filters.gender);
  if (filters.leader_group)  result = result.filter(c => c.leader_group?.toLowerCase().includes(filters.leader_group.toLowerCase()));
  if (filters.party_frontal) result = result.filter(c => c.party_frontal === filters.party_frontal);
  if (filters.volunteer === true || filters.volunteer === "true") result = result.filter(c => c.volunteer);
  if (filters.has_whatsapp === true || filters.has_whatsapp === "true") result = result.filter(c => c.whatsapp_number);
  return result;
}

router.get("/recipient-lists", async (req, res) => {
  try {
    const lists = await db.select().from(recipientListsTable).orderBy(recipientListsTable.created_at);
    res.json({ success: true, data: lists.map(fmt) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get("/recipient-lists/:id/contacts", async (req, res) => {
  try {
    const [list] = await db.select().from(recipientListsTable).where(eq(recipientListsTable.id, req.params.id));
    if (!list) return res.status(404).json({ success: false, error: "Not found" });
    const filters = JSON.parse(list.filters ?? "{}");
    const all = await db.select().from(contactsTable);
    const filtered = applyFilters(all, filters);
    res.json({ success: true, data: filtered, total: filtered.length });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/recipient-lists/preview", async (req, res) => {
  try {
    const filters: Record<string, any> = req.body ?? {};
    const all = await db.select().from(contactsTable);
    const filtered = applyFilters(all, filters);
    res.json({ success: true, total: filtered.length });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/recipient-lists", async (req, res) => {
  try {
    const { name, description, filters } = req.body;
    if (!name) return res.status(400).json({ success: false, error: "name required" });
    const f = filters ?? {};
    const all = await db.select().from(contactsTable);
    const filtered = applyFilters(all, f);
    const [list] = await db.insert(recipientListsTable).values({
      id: randomUUID(),
      name,
      description: description || null,
      filters: JSON.stringify(f),
      contact_count: filtered.length,
    }).returning();
    res.status(201).json({ success: true, data: fmt(list) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.delete("/recipient-lists/:id", async (req, res) => {
  try {
    await db.delete(recipientListsTable).where(eq(recipientListsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function fmt(r: any) {
  return {
    ...r,
    created_at: r.created_at instanceof Date ? r.created_at.toISOString() : r.created_at,
    updated_at: r.updated_at instanceof Date ? r.updated_at.toISOString() : r.updated_at,
  };
}

export default router;
