import { Router, type IRouter } from "express";
import { db, issuesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const router: IRouter = Router();

router.get("/issues", async (req, res) => {
  try {
    const { status, priority } = req.query as Record<string, string>;
    let issues = await db.select().from(issuesTable).orderBy(issuesTable.created_at);

    if (status) issues = issues.filter(i => i.issue_status === status);
    if (priority) issues = issues.filter(i => i.issue_priority === priority);

    res.json({ success: true, data: issues.map(formatIssue) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/issues", async (req, res) => {
  try {
    const { issue_title, issue_description, issue_status, issue_priority, contact_id, contact_name, district, constituency } = req.body;
    if (!issue_title) return res.status(400).json({ success: false, error: "issue_title required" });

    const [issue] = await db.insert(issuesTable).values({
      id: randomUUID(),
      issue_title,
      issue_description: issue_description || null,
      issue_status: issue_status || "new",
      issue_priority: issue_priority || null,
      contact_id: contact_id || null,
      contact_name: contact_name || null,
      district: district || null,
      constituency: constituency || null,
    }).returning();
    res.status(201).json({ success: true, data: formatIssue(issue) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.put("/issues/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updates = { ...req.body, updated_at: new Date() };
    const [updated] = await db.update(issuesTable).set(updates).where(eq(issuesTable.id, id)).returning();
    if (!updated) return res.status(404).json({ success: false, error: "Not found" });
    res.json({ success: true, data: formatIssue(updated) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.delete("/issues/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await db.delete(issuesTable).where(eq(issuesTable.id, id));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function formatIssue(i: any) {
  return {
    ...i,
    created_at: i.created_at instanceof Date ? i.created_at.toISOString() : i.created_at,
    updated_at: i.updated_at instanceof Date ? i.updated_at.toISOString() : i.updated_at,
  };
}

export default router;
