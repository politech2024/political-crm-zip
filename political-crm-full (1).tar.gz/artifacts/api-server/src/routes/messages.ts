import { Router, type IRouter } from "express";
import { db, messagesTable, contactsTable } from "@workspace/db";
import { randomUUID } from "crypto";
import { count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/messages", async (req, res) => {
  try {
    const messages = await db.select().from(messagesTable).orderBy(messagesTable.created_at);
    res.json({ success: true, data: messages.map(formatMessage) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/messages", async (req, res) => {
  try {
    const body = req.body;
    const content = body.message_content || body.content;
    const channel = body.message_channel || body.channel || "whatsapp";
    const recipientCountRaw = body.recipient_count ?? body.recipients;

    if (!content) return res.status(400).json({ success: false, error: "content required" });

    let recipientCount = recipientCountRaw != null ? Number(recipientCountRaw) : 0;
    if (recipientCountRaw == null) {
      const [{ value }] = await db.select({ value: count() }).from(contactsTable);
      recipientCount = Number(value);
    }

    const [msg] = await db.insert(messagesTable).values({
      id: randomUUID(),
      message_content: content,
      message_channel: channel,
      recipient_count: recipientCount,
    }).returning();
    res.status(201).json({ success: true, data: formatMessage(msg) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function formatMessage(m: any) {
  return {
    ...m,
    created_at: m.created_at instanceof Date ? m.created_at.toISOString() : m.created_at,
    message_sent_at: m.message_sent_at instanceof Date ? m.message_sent_at.toISOString() : m.message_sent_at,
  };
}

export default router;
