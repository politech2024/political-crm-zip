import { Router, type IRouter } from "express";
import { db, contactsTable, issuesTable, messagesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/stats", async (req, res) => {
  try {
    const [contacts, issues, messages] = await Promise.all([
      db.select().from(contactsTable),
      db.select().from(issuesTable).orderBy(issuesTable.created_at),
      db.select().from(messagesTable),
    ]);

    const recentContacts = [...contacts]
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 5);
    const recentIssues = [...issues]
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 5);

    const data = {
      total_contacts: contacts.length,
      total_messages: messages.length,
      open_issues: issues.filter(i => i.issue_status !== "resolved").length,
      assembly_seats_covered: new Set(contacts.map(c => c.constituency).filter(Boolean)).size,
      districts_reached: new Set(contacts.map(c => c.district).filter(Boolean)).size,
      leader_network: contacts.filter(c => c.leader_group).length,
      volunteers: contacts.filter(c => c.volunteer === true).length,
      party_breakdown: {
        bjp: contacts.filter(c => c.political_party === "bjp").length,
        congress: contacts.filter(c => c.political_party === "congress").length,
        aap: contacts.filter(c => c.political_party === "aap").length,
        other: contacts.filter(c => c.political_party && !["bjp", "congress", "aap"].includes(c.political_party)).length,
      },
      caste_breakdown: {
        general: contacts.filter(c => c.caste === "general").length,
        obc: contacts.filter(c => c.caste === "obc").length,
        sc: contacts.filter(c => c.caste === "sc").length,
        st: contacts.filter(c => c.caste === "st").length,
      },
      recent_contacts: recentContacts.map(formatContact),
      recent_issues: recentIssues.map(formatIssue),
      today_birthdays: (() => {
        const now = new Date();
        const dd = String(now.getDate()).padStart(2, "0");
        const mm = String(now.getMonth() + 1).padStart(2, "0");
        return contacts.filter(c => {
          if (!c.birthday) return false;
          const parts = c.birthday.split("/");
          return parts.length >= 2 && parts[0] === dd && parts[1] === mm;
        }).map(formatContact);
      })(),
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function formatContact(c: any) {
  return {
    ...c,
    created_at: c.created_at instanceof Date ? c.created_at.toISOString() : c.created_at,
    updated_at: c.updated_at instanceof Date ? c.updated_at.toISOString() : c.updated_at,
  };
}

function formatIssue(i: any) {
  return {
    ...i,
    created_at: i.created_at instanceof Date ? i.created_at.toISOString() : i.created_at,
    updated_at: i.updated_at instanceof Date ? i.updated_at.toISOString() : i.updated_at,
  };
}

export default router;
