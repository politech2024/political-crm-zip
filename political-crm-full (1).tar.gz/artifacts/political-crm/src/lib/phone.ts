import { COUNTRIES } from "@/components/ui/phone-input";

const DEFAULT_CC = "91";

function parseStored(num: string): { cc: string; number: string } {
  if (!num) return { cc: DEFAULT_CC, number: "" };
  if (num.startsWith("+")) {
    const m = num.match(/^\+(\d+)-(.*)$/);
    if (m) return { cc: m[1], number: m[2].replace(/\D/g, "") };
  }
  const d = num.replace(/\D/g, "");
  for (const country of COUNTRIES.filter(c => c.code !== "1")) {
    if (d.startsWith(country.code) && d.length === country.code.length + country.maxLen) {
      return { cc: country.code, number: d.slice(country.code.length) };
    }
  }
  return { cc: DEFAULT_CC, number: d };
}

export function formatPhone(num: string | null | undefined): string {
  if (!num) return "";
  const { cc, number } = parseStored(num);
  if (!number) return "";
  if (cc === "91" && number.length === 10) {
    return `+91 ${number.slice(0, 5)} ${number.slice(5)}`;
  }
  return `+${cc} ${number}`;
}

export function waLink(num: string | null | undefined): string {
  if (!num) return "";
  const { cc, number } = parseStored(num);
  return `https://wa.me/${cc}${number}`;
}

export function telLink(num: string | null | undefined): string {
  if (!num) return "";
  const { cc, number } = parseStored(num);
  return `tel:+${cc}${number}`;
}
