/**
 * contact-enrichment.ts
 *
 * Smart-fill algorithm for existing contacts.
 * Scans name / notes for embedded party, designation, assembly, district info
 * and returns only the NEW fields that should be filled (never overwrites).
 */

import { CG_ASSEMBLIES, CG_DISTRICTS } from "@/data/cg-assemblies";

// ─── Party normalisation ──────────────────────────────────────────────────────
export function normParty(p: string): string {
  const l = (p ?? "").toLowerCase().replace(/\s+/g, "");
  if (l.includes("bjp") || l.includes("भाजपा") || l.includes("bharatiya")) return "bjp";
  if (l.includes("inc") || l.includes("congress") || l.includes("कांग्रेस") || l.includes("कॉंग्रेस")) return "inc";
  if (l.includes("aap") || l.includes("aamadmi") || l.includes("आम आदमी")) return "aap";
  if (l.includes("bsp") || l.includes("bahujan") || l.includes("बसपा")) return "bsp";
  if (l.includes("jcc") || l.includes("जनता")) return "jcc";
  if (l.includes("independent") || l.includes("निर्दलीय")) return "independent";
  return p ? "other" : "";
}

// ─── Designation → contact type mapping ──────────────────────────────────────
const DESIGNATION_PATTERNS: { pattern: RegExp; type: string; label: string }[] = [
  { pattern: /\b(ex[\-\s]?mla|पूर्व[\s]*विधायक)\b/i,          type: "leader",           label: "Ex-MLA" },
  { pattern: /\b(mla|विधायक)\b/i,                               type: "leader",           label: "MLA" },
  { pattern: /\b(ex[\-\s]?mp|पूर्व[\s]*सांसद)\b/i,             type: "leader",           label: "Ex-MP" },
  { pattern: /\b(mp|सांसद)\b/i,                                 type: "leader",           label: "MP" },
  { pattern: /\b(sarpanch|सरपंच)\b/i,                           type: "sarpanch",         label: "Sarpanch" },
  { pattern: /\b(up[\s-]?sarpanch|उप[\s]*सरपंच)\b/i,           type: "community_leader", label: "Up-Sarpanch" },
  { pattern: /\b(ward[\s]*member|पार्षद|parshad)\b/i,           type: "community_leader", label: "Ward Member" },
  { pattern: /\b(panch|पंच)\b/i,                                type: "community_leader", label: "Panch" },
  { pattern: /\b(parishad|परिषद)\b/i,                           type: "community_leader", label: "Parishad" },
  { pattern: /\b(booth[\s]*pramukh|बूथ[\s]*प्रमुख)\b/i,        type: "party_worker",     label: "Booth Pramukh" },
  { pattern: /\b(mandal[\s]*pramukh|मंडल[\s]*प्रमुख)\b/i,      type: "leader",           label: "Mandal Pramukh" },
  { pattern: /\b(president|अध्यक्ष|adhyaksh)\b/i,              type: "leader",           label: "President" },
  { pattern: /\b(secretary|सचिव|sachiv)\b/i,                    type: "party_worker",     label: "Secretary" },
  { pattern: /\b(treasurer|कोषाध्यक्ष)\b/i,                    type: "party_worker",     label: "Treasurer" },
  { pattern: /\b(youth[\s]*president|युवा[\s]*अध्यक्ष)\b/i,    type: "youth_leader",     label: "Youth President" },
  { pattern: /\b(youth[\s]*leader|युवा[\s]*नेता)\b/i,           type: "youth_leader",     label: "Youth Leader" },
  { pattern: /\b(mahila[\s]*president|महिला[\s]*अध्यक्ष)\b/i,  type: "women_leader",     label: "Mahila President" },
  { pattern: /\b(mahila|महिला)\b/i,                             type: "women_leader",     label: "Mahila" },
  { pattern: /\b(youth|yuva|युवा)\b/i,                          type: "youth_leader",     label: "Youth" },
  { pattern: /\b(pradhan|प्रधान)\b/i,                           type: "leader",           label: "Pradhan" },
  { pattern: /\b(neta|netaji|नेताजी|नेता)\b/i,                 type: "leader",           label: "Neta" },
  { pattern: /\b(volunteer|swayamsevak|स्वयंसेवक)\b/i,         type: "volunteer",        label: "Volunteer" },
  { pattern: /\b(journalist|patrakar|पत्रकार)\b/i,             type: "journalist",       label: "Journalist" },
  { pattern: /\b(donor|daani|दानी)\b/i,                         type: "donor",            label: "Donor" },
  { pattern: /\b(advocate|adv\.|अधिवक्ता|lawyer)\b/i,          type: "community_leader", label: "Advocate" },
  { pattern: /\b(doctor|dr\.|डॉक्टर|डॉ\.)\b/i,                 type: "community_leader", label: "Doctor" },
  { pattern: /\b(worker|karyakarta|कार्यकर्ता)\b/i,            type: "party_worker",     label: "Karyakarta" },
  { pattern: /\b(influencer|प्रभावशाली)\b/i,                   type: "influencer",       label: "Influencer" },
  { pattern: /\b(mandal|मंडल)\b/i,                              type: "party_worker",     label: "Mandal" },
];

const PARTY_PATTERNS: { pattern: RegExp; party: string }[] = [
  { pattern: /\b(bjp|भाजपा|bharatiya[\s]*janata)\b/i,      party: "bjp" },
  { pattern: /\b(inc|congress|कांग्रेस|कॉंग्रेस)\b/i,     party: "inc" },
  { pattern: /\b(aap|aam[\s]*aadmi|आम[\s]*आदमी)\b/i,      party: "aap" },
  { pattern: /\b(bsp|bahujan|बसपा|बहुजन)\b/i,             party: "bsp" },
  { pattern: /\b(jcc|जनता[\s]*congress|जनता[\s]*कांग्रेस)\b/i, party: "jcc" },
  { pattern: /\b(independent|निर्दलीय)\b/i,               party: "independent" },
];

// ─── Fuzzy assembly match ─────────────────────────────────────────────────────
export function fuzzyAssembly(name: string): typeof CG_ASSEMBLIES[0] | null {
  if (!name?.trim() || name.trim().length < 3) return null;
  const q = name.toLowerCase().replace(/[^a-z0-9\u0900-\u097F ]/gi, "").trim();

  const exact = CG_ASSEMBLIES.find(a => a.name.toLowerCase() === q);
  if (exact) return exact;

  const numMatch = q.match(/\b(\d{1,3})\b/);
  if (numMatch) {
    const n = parseInt(numMatch[1]);
    const byNum = CG_ASSEMBLIES.find(a => a.number === n);
    if (byNum) return byNum;
  }

  const startsWith = CG_ASSEMBLIES.find(a => a.name.toLowerCase().startsWith(q) && q.length >= 4);
  if (startsWith) return startsWith;

  const includes = CG_ASSEMBLIES.find(a => a.name.toLowerCase().includes(q) && q.length >= 4);
  if (includes) return includes;

  return null;
}

// ─── Fuzzy district match ─────────────────────────────────────────────────────
export function fuzzyDistrict(name: string): string {
  if (!name?.trim() || name.trim().length < 3) return "";
  const q = name.toLowerCase().trim();
  return CG_DISTRICTS.find(d =>
    d.toLowerCase() === q ||
    d.toLowerCase().startsWith(q) ||
    q.startsWith(d.toLowerCase().slice(0, 4))
  ) ?? "";
}

// ─── Result of enriching one contact ─────────────────────────────────────────
export interface EnrichResult {
  id: string;
  name: string;
  /** New values to write — only fields that are currently empty */
  updates: Record<string, string>;
  /** Human-readable summary of what was found */
  reasons: string[];
  /** Cleaned name (with embedded tokens removed) */
  cleanName?: string;
  /** True if AI was used to produce this result */
  usedAI?: boolean;
}

// ─── Core enrichment algorithm ────────────────────────────────────────────────
/**
 * Analyses name + notes for embedded info.
 * Returns only new values for fields that are currently blank.
 */
export function enrichContactLocally(contact: {
  id: string;
  name: string;
  notes?: string | null;
  political_party?: string | null;
  political_affiliation?: string | null;
  district?: string | null;
  constituency?: string | null;
  caste?: string | null;
  religion?: string | null;
  [key: string]: any;
}): EnrichResult {
  const result: EnrichResult = { id: contact.id, name: contact.name, updates: {}, reasons: [] };

  // Combine name + notes as source text to scan
  let text = (contact.name ?? "").trim();
  const notesText = (contact.notes ?? "").trim();

  // ── 1. Party ─────────────────────────────────────────────────────────────
  if (!contact.political_party) {
    const combined = `${text} ${notesText}`;
    for (const { pattern, party } of PARTY_PATTERNS) {
      if (pattern.test(combined)) {
        result.updates.political_party = party;
        result.reasons.push(`Party: ${party.toUpperCase()} found in name/notes`);
        text = text.replace(pattern, " ").trim();
        break;
      }
    }
  }

  // ── 2. Designation / type ─────────────────────────────────────────────────
  if (!contact.political_affiliation) {
    const combined = `${text} ${notesText}`;
    let foundLabel = "";
    let foundType = "";
    for (const { pattern, type, label } of DESIGNATION_PATTERNS) {
      if (pattern.test(combined)) {
        if (!foundType) { foundType = type; foundLabel = label; }
        text = text.replace(pattern, " ").trim();
      }
    }
    if (foundType) {
      result.updates.political_affiliation = foundType;
      result.reasons.push(`Type: ${foundLabel} found in name/notes`);
    }
  }

  // ── 3. Assembly (then district from it) ───────────────────────────────────
  if (!contact.constituency) {
    const words = text.split(/[\s,]+/).filter(Boolean);
    let found = false;
    for (let len = Math.min(words.length, 4); len >= 1 && !found; len--) {
      for (const startIdx of [words.length - len, 0]) {
        const phrase = words.slice(startIdx, startIdx + len).join(" ");
        if (phrase.length < 3) continue;
        const aMatch = fuzzyAssembly(phrase);
        if (aMatch) {
          result.updates.constituency = aMatch.name;
          result.reasons.push(`Assembly: ${aMatch.name} detected`);
          if (!contact.district) {
            result.updates.district = aMatch.district;
            result.reasons.push(`District: ${aMatch.district} (from assembly)`);
          }
          text = text.replace(new RegExp(phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), " ").trim();
          found = true;
          break;
        }
      }
    }
  }

  // ── 4. District (standalone, if no assembly matched) ──────────────────────
  if (!contact.district && !result.updates.district) {
    const combined = `${text} ${notesText}`;
    const words = combined.split(/[\s,]+/).filter(Boolean);
    for (let len = Math.min(words.length, 3); len >= 1; len--) {
      const phrase = words.slice(-len).join(" ");
      if (phrase.length < 3) continue;
      const d = fuzzyDistrict(phrase);
      if (d) {
        result.updates.district = d;
        result.reasons.push(`District: ${d} detected`);
        text = text.replace(new RegExp(phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), " ").trim();
        break;
      }
    }
  }

  // ── 5. Cleaned name (with embedded tokens stripped) ───────────────────────
  const cleaned = text.replace(/[,\-_/|]+$/, "").replace(/\s{2,}/g, " ").trim();
  if (cleaned && cleaned !== contact.name && cleaned.length >= 3) {
    result.cleanName = cleaned;
  }

  return result;
}

// ─── AI-powered enrichment (calls the intake endpoint) ───────────────────────
const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export async function enrichContactWithAI(contact: {
  id: string;
  name: string;
  notes?: string | null;
  [key: string]: any;
}): Promise<EnrichResult> {
  const prompt = `You are a structured data extraction engine for a political CRM in Chhattisgarh, India.
Extract contact information from the input text.
The input may be in Hindi, English, or mixed Hinglish.
Return ONLY valid JSON. No explanation. No markdown backticks.

JSON schema:
{"full_name":"","primary_mobile":"","district":"","assembly_name":"","type":"","party":"","political_affiliation":"","caste_community":"","religion":"","occupation":"","notes":"","confidence":0}

Rules:
- full_name: ONLY the actual person name. Remove party names, designations, place names.
- district/assembly_name: only Chhattisgarh geography
- party: bjp, inc, aap, bsp, jcc, independent, other
- type: party_worker, leader, influencer, sarpanch, volunteer, youth_leader, women_leader, journalist, donor, community_leader, voter
- confidence: 0–100`;

  const inputText = [contact.name, contact.notes].filter(Boolean).join(". ");

  try {
    const r = await fetch(`${BASE}/api/ai-intake`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ system_prompt: prompt, user_input: inputText }),
    });
    const j = await r.json();
    if (!j.success || !j.data) throw new Error("AI failed");

    const d = j.data;
    const result: EnrichResult = {
      id: contact.id, name: contact.name, updates: {}, reasons: [], usedAI: true,
    };

    if (d.full_name?.trim() && d.full_name !== contact.name) {
      result.cleanName = d.full_name.trim();
    }
    if (d.party?.trim() && !contact.political_party) {
      result.updates.political_party = d.party;
      result.reasons.push(`Party: ${d.party.toUpperCase()} (AI)`);
    }
    if (d.type?.trim() && !contact.political_affiliation) {
      result.updates.political_affiliation = d.type;
      result.reasons.push(`Type: ${d.type} (AI)`);
    }
    if (d.assembly_name?.trim() && !contact.constituency) {
      result.updates.constituency = d.assembly_name;
      result.reasons.push(`Assembly: ${d.assembly_name} (AI)`);
    }
    if (d.district?.trim() && !contact.district) {
      result.updates.district = d.district;
      result.reasons.push(`District: ${d.district} (AI)`);
    }
    if (d.caste_community?.trim() && !contact.caste) {
      result.updates.caste = d.caste_community;
      result.reasons.push(`Caste: ${d.caste_community} (AI)`);
    }
    if (d.religion?.trim() && !contact.religion) {
      result.updates.religion = d.religion;
      result.reasons.push(`Religion: ${d.religion} (AI)`);
    }

    return result;
  } catch {
    return enrichContactLocally(contact);
  }
}
