import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { enrichContactLocally, enrichContactWithAI, EnrichResult } from "@/lib/contact-enrichment";
import {
  Wand2, Sparkles, CheckCircle, Loader2, AlertTriangle, X, ChevronRight,
  RefreshCw, Brain
} from "lucide-react";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const PARTY_LABELS: Record<string, string> = {
  bjp: "BJP", inc: "INC", aap: "AAP", bsp: "BSP", jcc: "JCC",
  independent: "Independent", other: "Other",
};

const TYPE_LABELS: Record<string, string> = {
  leader: "Leader", sarpanch: "Sarpanch", party_worker: "Worker",
  community_leader: "Community Leader", youth_leader: "Youth Leader",
  women_leader: "Women Leader", volunteer: "Volunteer", journalist: "Journalist",
  donor: "Donor", influencer: "Influencer", voter: "Voter",
};

const FIELD_LABELS: Record<string, string> = {
  political_party: "Party",
  political_affiliation: "Type/Role",
  district: "District",
  constituency: "Assembly",
  caste: "Caste",
  religion: "Religion",
  name: "Name (cleaned)",
};

function formatValue(key: string, val: string): string {
  if (key === "political_party") return PARTY_LABELS[val] ?? val.toUpperCase();
  if (key === "political_affiliation") return TYPE_LABELS[val] ?? val;
  return val;
}

interface SmartFillDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  contacts: any[];
  onApplied: () => void;
}

type RowStatus = "pending" | "enriching" | "done" | "ai" | "saved" | "error" | "skipped";

interface EnrichRow {
  result: EnrichResult;
  status: RowStatus;
  selected: boolean;
  error?: string;
}

export function SmartFillDialog({ open, onOpenChange, contacts, onApplied }: SmartFillDialogProps) {
  const { toast } = useToast();
  const [rows, setRows] = useState<EnrichRow[]>([]);
  const [analysing, setAnalysing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveCount, setSaveCount] = useState(0);
  const [phase, setPhase] = useState<"analyse" | "review">("analyse");

  const runLocalAnalysis = useCallback(() => {
    setAnalysing(true);
    const enriched: EnrichRow[] = contacts
      .map(c => ({ result: enrichContactLocally(c), status: "pending" as RowStatus, selected: true }))
      .filter(r => r.result.reasons.length > 0 || r.result.cleanName);
    setRows(enriched);
    setAnalysing(false);
    setPhase("review");
  }, [contacts]);

  useEffect(() => {
    if (open && contacts.length > 0) {
      runLocalAnalysis();
    }
  }, [open]);

  const enrichRowWithAI = async (idx: number) => {
    const row = rows[idx];
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, status: "enriching" } : r));
    const contact = contacts.find(c => c.id === row.result.id);
    if (!contact) return;
    const aiResult = await enrichContactWithAI(contact);
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, result: aiResult, status: "ai", selected: Object.keys(aiResult.updates).length > 0 || !!aiResult.cleanName } : r));
  };

  const enrichAllWithAI = async () => {
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].status === "saved") continue;
      await enrichRowWithAI(i);
    }
  };

  const toggleRow = (idx: number) =>
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, selected: !r.selected } : r));

  const toggleAll = (v: boolean) =>
    setRows(prev => prev.map(r => r.status !== "saved" ? { ...r, selected: v } : r));

  const applySelected = async () => {
    const toSave = rows.filter(r => r.selected && r.status !== "saved" && (Object.keys(r.result.updates).length > 0 || r.result.cleanName));
    if (toSave.length === 0) {
      toast({ title: "Nothing selected to apply" }); return;
    }
    setSaving(true);
    setSaveCount(0);
    let saved = 0;

    for (const row of toSave) {
      const updates: Record<string, any> = { ...row.result.updates };
      if (row.result.cleanName) updates.name = row.result.cleanName;

      try {
        const r = await fetch(`${BASE}/api/contacts/${row.result.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(updates),
        });
        const j = await r.json();
        if (j.success) {
          setRows(prev => prev.map(rr => rr.result.id === row.result.id ? { ...rr, status: "saved" } : rr));
          saved++;
          setSaveCount(saved);
        } else {
          setRows(prev => prev.map(rr => rr.result.id === row.result.id ? { ...rr, status: "error", error: j.error } : rr));
        }
      } catch (e: any) {
        setRows(prev => prev.map(rr => rr.result.id === row.result.id ? { ...rr, status: "error", error: e.message } : rr));
      }
    }

    setSaving(false);
    toast({ title: `${saved} contact${saved !== 1 ? "s" : ""} updated` });
    onApplied();
  };

  const pendingCount = rows.filter(r => r.selected && r.status !== "saved").length;
  const savedCount = rows.filter(r => r.status === "saved").length;
  const allSelected = rows.length > 0 && rows.filter(r => r.status !== "saved").every(r => r.selected);

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col p-0 gap-0">
        {/* Header */}
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Wand2 className="h-4 w-4 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-base font-bold font-serif">Smart Fill Empty Fields</DialogTitle>
              <DialogDescription className="text-xs">
                Algorithm scans names and notes to detect party, designation, assembly, and district.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 min-h-0">
          {analysing && (
            <div className="flex items-center gap-3 py-8 justify-center text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              <span className="text-sm">Analysing {contacts.length} contacts…</span>
            </div>
          )}

          {!analysing && rows.length === 0 && (
            <div className="py-10 text-center text-muted-foreground space-y-2">
              <CheckCircle className="h-10 w-10 mx-auto text-green-500/40" />
              <p className="text-sm font-medium">All good! No hidden data detected in names or notes.</p>
              <p className="text-xs">Try the AI Enrich button below to run a deeper AI analysis.</p>
            </div>
          )}

          {!analysing && rows.length > 0 && (
            <>
              {/* Toolbar */}
              <div className="flex items-center justify-between pb-1">
                <div className="flex items-center gap-2">
                  <Checkbox checked={allSelected} onCheckedChange={(v) => toggleAll(Boolean(v))} />
                  <span className="text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">{rows.length}</span> contact{rows.length !== 1 ? "s" : ""} to update
                    {savedCount > 0 && <span className="text-green-600 ml-2">· {savedCount} saved</span>}
                  </span>
                </div>
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={enrichAllWithAI} disabled={saving}>
                  <Brain className="h-3 w-3" /> AI Enrich All
                </Button>
              </div>

              {/* Rows */}
              <div className="space-y-2">
                {rows.map((row, idx) => {
                  const hasUpdates = Object.keys(row.result.updates).length > 0 || !!row.result.cleanName;
                  return (
                    <div key={row.result.id}
                      className={cn(
                        "rounded-xl border p-3 transition-colors",
                        row.status === "saved" ? "border-green-200 bg-green-50/60" :
                        row.status === "error" ? "border-red-200 bg-red-50/60" :
                        row.status === "enriching" ? "border-primary/30 bg-primary/5" :
                        row.selected ? "border-primary/20 bg-card" : "border-border bg-secondary/20"
                      )}>
                      <div className="flex items-start gap-3">
                        {/* Checkbox */}
                        <div className="pt-0.5">
                          {row.status === "saved" ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : row.status === "error" ? (
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                          ) : row.status === "enriching" ? (
                            <Loader2 className="h-4 w-4 animate-spin text-primary" />
                          ) : (
                            <Checkbox checked={row.selected} onCheckedChange={() => toggleRow(idx)} />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          {/* Name row */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-semibold truncate">{row.result.name}</span>
                            {row.result.cleanName && (
                              <>
                                <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
                                <span className="text-sm font-semibold text-primary truncate">{row.result.cleanName}</span>
                                <Badge variant="outline" className="text-[9px] h-4 border-primary/30 text-primary">Name cleaned</Badge>
                              </>
                            )}
                            {row.result.usedAI && (
                              <Badge variant="outline" className="text-[9px] h-4 border-violet-300 text-violet-600">
                                <Sparkles className="h-2.5 w-2.5 mr-0.5" /> AI
                              </Badge>
                            )}
                            {row.status === "saved" && <Badge className="text-[9px] h-4 bg-green-600">Saved</Badge>}
                            {row.status === "error" && <Badge variant="destructive" className="text-[9px] h-4">{row.error}</Badge>}
                          </div>

                          {/* Fields to fill */}
                          {hasUpdates && (
                            <div className="flex flex-wrap gap-1.5 mt-1.5">
                              {Object.entries(row.result.updates).map(([key, val]) => (
                                <div key={key} className="flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5">
                                  <span className="text-[10px] text-muted-foreground">{FIELD_LABELS[key] ?? key}:</span>
                                  <span className="text-[10px] font-semibold text-foreground">{formatValue(key, val)}</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Reasons */}
                          {row.result.reasons.length > 0 && (
                            <p className="text-[10px] text-muted-foreground mt-1">
                              {row.result.reasons.join(" · ")}
                            </p>
                          )}
                        </div>

                        {/* Per-row AI button */}
                        {row.status !== "saved" && row.status !== "enriching" && (
                          <button
                            className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                            title="Enrich this contact with AI"
                            onClick={() => enrichRowWithAI(idx)}>
                            <Brain className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border shrink-0 flex items-center gap-3">
          {saving && (
            <div className="flex-1 flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Saving {saveCount} / {pendingCount}…
            </div>
          )}
          {!saving && (
            <div className="flex-1 text-xs text-muted-foreground">
              {pendingCount > 0
                ? `${pendingCount} contact${pendingCount !== 1 ? "s" : ""} selected — only empty fields will be filled`
                : "Select contacts above to apply"}
            </div>
          )}
          <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => { setPhase("analyse"); runLocalAnalysis(); }} disabled={saving}>
            <RefreshCw className="h-3.5 w-3.5 mr-1" /> Re-scan
          </Button>
          <Button size="sm" className="h-8 text-xs font-semibold gap-1.5" onClick={applySelected} disabled={saving || pendingCount === 0}>
            <Wand2 className="h-3.5 w-3.5" />
            Apply {pendingCount > 0 ? `(${pendingCount})` : ""}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
