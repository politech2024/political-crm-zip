import { useState, useCallback, useRef } from "react";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  useGetContacts,
  useImportContacts,
  useUpdateContact,
  getGetContactsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { UploadCloud, ChevronRight, ChevronLeft, Check, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImportContactsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// ── CRM field schema ──────────────────────────────────────────────────────────
const CRM_FIELDS = [
  { key: "name",                   label: "Full Name",                 required: true,  group: "Personal" },
  { key: "mobile",                 label: "Mobile Number",             required: true,  group: "Personal" },
  { key: "whatsapp",               label: "WhatsApp Number",           required: false, group: "Personal" },
  { key: "email",                  label: "Email",                     required: false, group: "Personal" },
  { key: "birthday",               label: "Birthday (dd/mm/yyyy)",     required: false, group: "Personal" },
  { key: "gender",                 label: "Gender",                    required: false, group: "Personal" },
  { key: "caste",                  label: "Caste",                     required: false, group: "Demographics" },
  { key: "religion",               label: "Religion",                  required: false, group: "Demographics" },
  { key: "political_party",        label: "Political Party",           required: false, group: "Political" },
  { key: "leader_group",           label: "Party Leader / Group",      required: false, group: "Political" },
  { key: "second_leader_group",    label: "Second Leader / Group",     required: false, group: "Political" },
  { key: "non_political_org",      label: "Non-Political Organization",required: false, group: "Political" },
  { key: "village",                label: "Village / Ward",            required: false, group: "Location" },
  { key: "booth",                  label: "Booth Number",              required: false, group: "Location" },
  { key: "district",               label: "District",                  required: false, group: "Location" },
  { key: "constituency",           label: "Assembly Constituency",     required: false, group: "Location" },
  { key: "state",                  label: "Lok Sabha Constituency",    required: false, group: "Location" },
  { key: "social_media_facebook",  label: "Facebook",                  required: false, group: "Social" },
  { key: "social_media_instagram", label: "Instagram",                 required: false, group: "Social" },
  { key: "social_media_twitter",   label: "Twitter / X",              required: false, group: "Social" },
];

const GROUPS = ["Personal", "Demographics", "Political", "Location", "Social"];

const ALIAS_MAP: Record<string, string[]> = {
  name:                   ["name","fullname","full name","contact name","supporter","constituent"],
  mobile:                 ["mobile","phone","mobileno","phoneno","cell","contact","mobile number","phone number"],
  whatsapp:               ["whatsapp","wp","wa","whatsappno","whatsapp number"],
  email:                  ["email","emailid","mail","email address","e-mail"],
  birthday:               ["birthday","dob","dateofbirth","birth date","date of birth","bday"],
  gender:                 ["gender","sex"],
  caste:                  ["caste","cast"],
  religion:               ["religion","faith"],
  political_party:        ["political_party","party","politicalparty","political party"],
  leader_group:           ["leader_group","leader","group","partygroup","party leader","party group"],
  second_leader_group:    ["second_leader_group","secondleader","2nd leader","second leader"],
  non_political_org:      ["non_political_org","ngo","org","organization","social group"],
  village:                ["village","ward","village/ward","area"],
  booth:                  ["booth","boothnumber","booth no","booth number"],
  district:               ["district"],
  constituency:           ["constituency","assembly","vidhansabha","assembly constituency","ac"],
  state:                  ["state","loksabha","lok sabha","ls","lok sabha constituency"],
  social_media_facebook:  ["facebook","fb","social_media_facebook"],
  social_media_instagram: ["instagram","insta","ig","social_media_instagram"],
  social_media_twitter:   ["twitter","x","twitterx","social_media_twitter"],
};

const DUP_STRATEGIES = [
  { value: "skip",      icon: "⏭",  label: "Skip Duplicates",  desc: "Keep existing record, ignore the incoming one." },
  { value: "overwrite", icon: "♻",  label: "Overwrite",         desc: "Replace existing record entirely with new data." },
  { value: "merge",     icon: "🔀", label: "Merge Fields",       desc: "Fill only blank fields in the existing record." },
  { value: "create",    icon: "➕", label: "Always Create",      desc: "Create regardless — may result in duplicates." },
];

const DUP_DETECT_BY = [
  { value: "mobile", label: "Mobile Number" },
  { value: "email",  label: "Email Address" },
  { value: "name",   label: "Full Name" },
];

const STEP_LABELS = ["Upload", "Map Fields", "Duplicates", "Preview", "Done"];

function norm(s: string) {
  return String(s).toLowerCase().replace(/[\s_\-\/\.]+/g, "");
}

function autoMap(headers: string[]): Record<string, string> {
  const mapping: Record<string, string> = {};
  headers.forEach((h) => {
    const hn = norm(h);
    for (const [field, aliases] of Object.entries(ALIAS_MAP)) {
      if (aliases.map(norm).includes(hn)) { mapping[h] = field; break; }
    }
  });
  return mapping;
}

// Map from CRM import keys → DB field names
function toDbRecord(rec: Record<string, string>, importBatch?: string) {
  return {
    name: rec.name || "",
    mobile: rec.mobile || "",
    whatsapp_number: rec.whatsapp || undefined,
    email: rec.email || undefined,
    birthday: rec.birthday || undefined,
    gender: rec.gender || undefined,
    caste: rec.caste || undefined,
    religion: rec.religion || undefined,
    political_party: rec.political_party || undefined,
    leader_group: rec.leader_group || undefined,
    second_leader: rec.second_leader_group || undefined,
    non_political_org: rec.non_political_org || undefined,
    village_ward: rec.village || undefined,
    booth_number: rec.booth || undefined,
    district: rec.district || undefined,
    constituency: rec.constituency || undefined,
    lok_sabha_constituency: rec.state || undefined,
    facebook: rec.social_media_facebook || undefined,
    instagram: rec.social_media_instagram || undefined,
    twitter: rec.social_media_twitter || undefined,
    source: "bulk_import",
    import_batch: importBatch,
  };
}

export function ImportContactsDialog({ open, onOpenChange }: ImportContactsDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [headers, setHeaders] = useState<string[]>([]);
  const [rows, setRows] = useState<string[][]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [dupStrategy, setDupStrategy] = useState("skip");
  const [dupDetectBy, setDupDetectBy] = useState("mobile");
  const [dragOver, setDragOver] = useState(false);
  const [parseError, setParseError] = useState("");
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    total: number; imported: number; duplicates: number; errors: number;
  } | null>(null);

  const { data: existingContacts } = useGetContacts({}, { query: { enabled: open } });
  const importMutation = useImportContacts();
  const updateMutation = useUpdateContact();

  const parseFile = useCallback(async (f: File) => {
    setParseError("");
    const ext = f.name.split(".").pop()?.toLowerCase();
    try {
      let hdrs: string[] = [];
      let rawRows: string[][] = [];

      if (ext === "json") {
        const text = await f.text();
        const json = JSON.parse(text);
        const arr = Array.isArray(json) ? json : (json.data || json.records || Object.values(json)[0]);
        if (!arr?.length) throw new Error("No records found in JSON");
        hdrs = Object.keys(arr[0]);
        rawRows = arr.map((r: Record<string, unknown>) => hdrs.map((h) => String(r[h] ?? "")));
      } else if (ext === "csv") {
        await new Promise<void>((resolve, reject) => {
          Papa.parse(f, {
            header: false,
            skipEmptyLines: true,
            complete: (results) => {
              const data = results.data as string[][];
              if (!data.length) { reject(new Error("Empty CSV file")); return; }
              hdrs = data[0].map(String);
              rawRows = data.slice(1);
              resolve();
            },
            error: (err) => reject(new Error(err.message)),
          });
        });
      } else {
        const buf = await f.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) as string[][];
        if (!data.length) throw new Error("Empty file");
        hdrs = data[0].map(String);
        rawRows = data.slice(1).filter((r) => r.some((c) => String(c).trim() !== ""));
      }

      setHeaders(hdrs);
      setRows(rawRows);
      setMapping(autoMap(hdrs));
      setFile(f);
      setStep(1);
    } catch (e: any) {
      setParseError("Could not parse file: " + e.message);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) parseFile(f);
  }, [parseFile]);

  const updateMapping = (crmKey: string, csvHeader: string) => {
    setMapping((m) => {
      const updated = { ...m };
      Object.keys(updated).forEach((h) => { if (updated[h] === crmKey) delete updated[h]; });
      if (csvHeader) updated[csvHeader] = crmKey;
      return updated;
    });
  };

  const reset = () => {
    setStep(0); setFile(null); setHeaders([]); setRows([]);
    setMapping({}); setParseError(""); setImportResult(null); setImporting(false);
  };

  const handleClose = (val: boolean) => {
    if (!val) reset();
    onOpenChange(val);
  };

  const mappedEntries = Object.entries(mapping).filter(([, v]) => v);
  const mappedCount = mappedEntries.length;
  const requiredMapped = CRM_FIELDS.filter((f) => f.required).every((f) =>
    Object.values(mapping).includes(f.key)
  );

  const runImport = async () => {
    if (importing) return;
    setImporting(true);

    // Generate one batch ID for the entire import session
    const importBatchId = crypto.randomUUID();

    const existing = existingContacts?.data ?? [];

    // Build dedup index
    const existingIndex: Record<string, (typeof existing)[0]> = {};
    existing.forEach((c) => {
      if (dupDetectBy === "mobile" && c.mobile) existingIndex[String(c.mobile).trim()] = c;
      if (dupDetectBy === "email" && c.email) existingIndex[String(c.email).trim().toLowerCase()] = c;
      if (dupDetectBy === "name" && c.name) existingIndex[String(c.name).trim().toLowerCase()] = c;
    });

    let imported = 0, duplicates = 0, errors = 0;
    const toCreate: ReturnType<typeof toDbRecord>[] = [];

    for (const row of rows) {
      // Build mapped record
      const rec: Record<string, string> = {};
      mappedEntries.forEach(([h, k]) => {
        const idx = headers.indexOf(h);
        rec[k] = String(row[idx] ?? "").trim();
      });

      // Determine dup key
      let dupKey = "";
      if (dupDetectBy === "mobile") dupKey = rec.mobile || "";
      else if (dupDetectBy === "email") dupKey = (rec.email || "").toLowerCase();
      else if (dupDetectBy === "name") dupKey = (rec.name || "").toLowerCase();

      const existingRec = dupKey ? existingIndex[dupKey] : null;

      if (existingRec) {
        duplicates++;
        if (dupStrategy === "skip") continue;
        if (dupStrategy === "merge") {
          // PUT only fills truly missing fields
          const updates: Record<string, string | undefined> = {};
          const dbRec = toDbRecord(rec, importBatchId);
          (Object.keys(dbRec) as (keyof typeof dbRec)[]).forEach((k) => {
            if (dbRec[k] && !(existingRec as any)[k]) updates[k] = dbRec[k] as string;
          });
          if (Object.keys(updates).length > 0) {
            try {
              await updateMutation.mutateAsync({ id: existingRec.id, data: updates });
              imported++;
            } catch { errors++; }
          }
          continue;
        }
        if (dupStrategy === "overwrite") {
          try {
            await updateMutation.mutateAsync({ id: existingRec.id, data: toDbRecord(rec, importBatchId) });
            imported++;
          } catch { errors++; }
          continue;
        }
        // "create" — fall through to batch insert
      }

      const dbRec = toDbRecord(rec, importBatchId);
      if (dbRec.name && dbRec.mobile) toCreate.push(dbRec);
    }

    // Batch-create non-duplicate records
    if (toCreate.length > 0) {
      try {
        const result = await importMutation.mutateAsync({ data: { records: toCreate, import_batch: importBatchId } });
        imported += result.imported ?? toCreate.length;
      } catch {
        errors += toCreate.length;
      }
    }

    await queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });

    setImportResult({ total: rows.length, imported, duplicates, errors });
    setStep(4);
    setImporting(false);
  };

  const canNext = () => {
    if (step === 0) return !!file && rows.length > 0;
    if (step === 1) return requiredMapped;
    return true;
  };

  const handleNext = () => {
    if (step === 3) { runImport(); return; }
    if (canNext()) setStep((s) => s + 1);
  };

  return (
    <Sheet open={open} onOpenChange={handleClose}>
      <SheetContent side="right" className="w-full sm:max-w-2xl overflow-hidden flex flex-col p-0">
        {/* Sticky header */}
        <SheetHeader className="px-6 py-4 border-b border-border bg-background shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shrink-0">
                <UploadCloud className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <SheetTitle className="text-base font-bold leading-tight">Import Constituents</SheetTitle>
                <p className="text-xs text-muted-foreground font-mono">CSV · Excel (.xlsx/.xls) · JSON</p>
              </div>
            </div>
            <span className="text-xs text-muted-foreground font-mono">Step {step + 1} / {STEP_LABELS.length}</span>
          </div>

          {/* Stepper */}
          <div className="flex items-center mt-4 gap-0">
            {STEP_LABELS.map((label, i) => {
              const done = step > i;
              const active = step === i;
              return (
                <div key={i} className={cn("flex items-center", i < STEP_LABELS.length - 1 && "flex-1")}>
                  <div className="flex flex-col items-center gap-1 shrink-0">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all",
                      done  ? "bg-green-600 border-green-600 text-white" :
                      active ? "border-primary text-primary bg-background" :
                               "border-border text-muted-foreground bg-background"
                    )}>
                      {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
                    </div>
                    <span className={cn("text-[10px] font-mono whitespace-nowrap",
                      active ? "text-primary" : done ? "text-green-600" : "text-muted-foreground"
                    )}>{label}</span>
                  </div>
                  {i < STEP_LABELS.length - 1 && (
                    <div className={cn("flex-1 h-0.5 mx-1 mb-4 transition-colors",
                      done ? "bg-green-600" : active ? "bg-primary/30" : "bg-border"
                    )} />
                  )}
                </div>
              );
            })}
          </div>
        </SheetHeader>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-6 py-5">

          {/* STEP 0: Upload */}
          {step === 0 && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Upload your constituent data file. Supported formats: <strong className="text-foreground">CSV, Excel (.xlsx/.xls), JSON</strong></p>

              <div
                onDrop={handleDrop}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onClick={() => fileRef.current?.click()}
                className={cn(
                  "border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all",
                  dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-secondary/30"
                )}
              >
                <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mx-auto mb-3">
                  <UploadCloud className="h-7 w-7 text-muted-foreground" />
                </div>
                <p className="font-semibold text-foreground text-sm mb-1">Drop file here or click to browse</p>
                <p className="text-xs text-muted-foreground">.csv · .xlsx · .xls · .json · Max 20MB</p>
                <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls,.json"
                  onChange={(e) => e.target.files?.[0] && parseFile(e.target.files[0])} className="hidden" />
              </div>

              {file && (
                <div className="flex items-center gap-3 p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center text-green-600 shrink-0">
                    <Check className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{rows.length} rows detected · {headers.length} columns</p>
                  </div>
                </div>
              )}

              {parseError && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                  ⚠️ {parseError}
                </div>
              )}

              <div className="p-4 rounded-xl bg-secondary/30 border border-border space-y-2">
                <p className="text-xs font-semibold text-primary">Required columns:</p>
                <div className="flex flex-wrap gap-2">
                  {CRM_FIELDS.filter((f) => f.required).map((f) => (
                    <span key={f.key} className="text-xs bg-primary/10 text-primary border border-primary/20 rounded px-2 py-0.5 font-mono">{f.key}</span>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">Column names are auto-detected — no exact match required.</p>
              </div>
            </div>
          )}

          {/* STEP 1: Map Fields */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  {headers.length} columns in <strong className="text-foreground">{file?.name}</strong> · {rows.length} rows
                </p>
                <Badge variant="secondary" className="font-mono text-xs">{mappedCount}/{headers.length} mapped</Badge>
              </div>

              <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full transition-all"
                  style={{ width: `${(mappedCount / Math.max(headers.length, 1)) * 100}%` }} />
              </div>

              {!requiredMapped && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-xs">
                  ⚠ Map all required fields before continuing: {CRM_FIELDS.filter((f) => f.required).map((f) => f.label).join(", ")}
                </div>
              )}

              <div className="space-y-5">
                {GROUPS.map((group) => {
                  const groupFields = CRM_FIELDS.filter((f) => f.group === group);
                  return (
                    <div key={group}>
                      <p className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground mb-2">{group}</p>
                      <div className="space-y-1">
                        {groupFields.map((field) => {
                          const mappedHeader = Object.entries(mapping).find(([, v]) => v === field.key)?.[0] || "";
                          return (
                            <div key={field.key} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-secondary/30 transition-colors">
                              <div className="flex items-center gap-2 w-52 shrink-0">
                                <span className={cn("w-1.5 h-1.5 rounded-full shrink-0",
                                  field.required ? "bg-primary" : "bg-muted"
                                )} />
                                <span className="text-sm text-foreground">{field.label}</span>
                                {field.required && <span className="text-[10px] text-primary font-medium">req</span>}
                              </div>
                              <ChevronRight className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                              <div className="flex items-center gap-2 flex-1">
                                <select
                                  value={mappedHeader}
                                  onChange={(e) => updateMapping(field.key, e.target.value)}
                                  className="flex-1 h-8 px-3 text-sm rounded-md border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                                >
                                  <option value="">— not mapped —</option>
                                  {headers.map((h) => (
                                    <option key={h} value={h}
                                      disabled={!!mapping[h] && mapping[h] !== field.key}>
                                      {h}
                                    </option>
                                  ))}
                                </select>
                                {mappedHeader
                                  ? <span className="text-green-600 text-xs shrink-0">✓</span>
                                  : <span className="text-muted-foreground/40 text-xs shrink-0">–</span>}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: Duplicate Handling */}
          {step === 2 && (
            <div className="space-y-6">
              <div>
                <p className="text-sm font-semibold text-foreground mb-1">Detect duplicates by</p>
                <p className="text-xs text-muted-foreground mb-3">How to identify if a constituent already exists in the database.</p>
                <div className="flex gap-2 flex-wrap">
                  {DUP_DETECT_BY.map((d) => (
                    <button key={d.value} onClick={() => setDupDetectBy(d.value)}
                      className={cn("px-4 py-2 rounded-lg border text-sm font-medium transition-all",
                        dupDetectBy === d.value
                          ? "bg-primary/10 border-primary text-primary"
                          : "bg-background border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      )}>
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold text-foreground mb-1">When a duplicate is found</p>
                <p className="text-xs text-muted-foreground mb-3">Choose what happens when an incoming record matches an existing one.</p>
                <div className="grid grid-cols-2 gap-3">
                  {DUP_STRATEGIES.map((s) => (
                    <button key={s.value} onClick={() => setDupStrategy(s.value)}
                      className={cn("text-left p-4 rounded-xl border transition-all",
                        dupStrategy === s.value
                          ? "border-primary bg-primary/10"
                          : "bg-background border-border hover:border-primary/40"
                      )}>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-xl">{s.icon}</span>
                        <span className="text-sm font-semibold text-foreground">{s.label}</span>
                        {dupStrategy === s.value && (
                          <span className="ml-auto w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                            <Check className="h-2.5 w-2.5 text-primary-foreground" />
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{s.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Preview */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: "Total Rows",     value: rows.length,        color: "text-foreground",  bg: "bg-secondary/30" },
                  { label: "Fields Mapped",  value: mappedEntries.length, color: "text-primary",   bg: "bg-primary/10" },
                  { label: "Dup Strategy",   value: DUP_STRATEGIES.find((s) => s.value === dupStrategy)?.label, color: "text-blue-600", bg: "bg-blue-500/10" },
                  { label: "Detect By",      value: DUP_DETECT_BY.find((d) => d.value === dupDetectBy)?.label,  color: "text-purple-600", bg: "bg-purple-500/10" },
                ].map((c) => (
                  <div key={c.label} className={cn("p-3 rounded-xl border border-border text-center", c.bg)}>
                    <p className="text-[10px] text-muted-foreground mb-0.5 font-mono">{c.label}</p>
                    <p className={cn("text-xs font-bold leading-tight", c.color)}>{c.value}</p>
                  </div>
                ))}
              </div>

              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-secondary/40">
                      {mappedEntries.slice(0, 7).map(([h, k]) => (
                        <th key={h} className="text-left px-3 py-2.5 text-muted-foreground font-semibold whitespace-nowrap border-b border-border">
                          {CRM_FIELDS.find((f) => f.key === k)?.label || k}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.slice(0, 8).map((row, ri) => (
                      <tr key={ri} className="border-t border-border/50 hover:bg-secondary/20 transition-colors">
                        {mappedEntries.slice(0, 7).map(([h]) => {
                          const idx = headers.indexOf(h);
                          const val = String(row[idx] ?? "").trim();
                          return (
                            <td key={h} className="px-3 py-2 text-foreground whitespace-nowrap max-w-[120px] overflow-hidden text-ellipsis" title={val}>
                              {val || <span className="text-muted-foreground/40">—</span>}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {rows.length > 8 && <p className="text-xs text-muted-foreground font-mono">Showing 8 of {rows.length} records</p>}

              <div className="p-3 bg-primary/10 border border-primary/30 rounded-lg text-xs text-primary">
                ⚡ Ready to import <strong>{rows.length} record{rows.length !== 1 ? "s" : ""}</strong> into your Political CRM database. This action cannot be undone.
              </div>

              {importing && (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/30 border border-border">
                  <Loader2 className="h-5 w-5 animate-spin text-primary shrink-0" />
                  <span className="text-sm text-muted-foreground">Processing records, checking duplicates…</span>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: Done */}
          {step === 4 && importResult && (
            <div className="flex flex-col items-center text-center space-y-6 py-4">
              <div className="w-20 h-20 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center text-3xl shadow-lg">
                ✅
              </div>
              <div>
                <h2 className="text-xl font-bold text-foreground">Import Complete!</h2>
                <p className="text-muted-foreground text-sm mt-1">Your constituent records have been processed.</p>
              </div>

              <div className="grid grid-cols-4 gap-3 w-full">
                {[
                  { label: "Total",      value: importResult.total,      icon: "📋", color: "text-foreground",   bg: "bg-secondary/30" },
                  { label: "Imported",   value: importResult.imported,   icon: "✅", color: "text-green-600",    bg: "bg-green-500/10" },
                  { label: "Duplicates", value: importResult.duplicates, icon: "🔁", color: "text-amber-600",    bg: "bg-amber-500/10" },
                  { label: "Errors",     value: importResult.errors,     icon: "❌", color: "text-destructive",  bg: "bg-destructive/10" },
                ].map((s) => (
                  <div key={s.label} className={cn("p-4 rounded-xl border border-border", s.bg)}>
                    <div className="text-2xl mb-1">{s.icon}</div>
                    <p className={cn("text-2xl font-bold", s.color)}>{s.value}</p>
                    <p className="text-xs text-muted-foreground font-mono">{s.label}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 w-full">
                <Button variant="outline" className="flex-1" onClick={reset}>
                  Import Another File
                </Button>
                <Button className="flex-1" onClick={() => handleClose(false)}>
                  View Contacts
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Sticky footer nav */}
        {step < 4 && (
          <div className="px-6 py-4 border-t border-border bg-background shrink-0 flex items-center justify-between">
            <Button variant="outline" onClick={() => step === 0 ? handleClose(false) : setStep((s) => s - 1)}
              disabled={importing} className="flex items-center gap-1">
              {step === 0 ? "Cancel" : <><ChevronLeft className="h-4 w-4" /> Back</>}
            </Button>
            <Button onClick={handleNext} disabled={!canNext() || importing}
              className="flex items-center gap-1">
              {importing && <Loader2 className="h-4 w-4 animate-spin" />}
              {step === 3
                ? importing ? "Importing…" : `⬆ Import ${rows.length} Records`
                : <>Continue <ChevronRight className="h-4 w-4" /></>}
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
