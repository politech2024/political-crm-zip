import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useCreateContact, useUpdateContact, getGetContactsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Contact } from "@workspace/api-client-react/src/generated/api.schemas";
import { Loader2, User, MapPin, Flag, Users, Share2, ChevronsUpDown, Check, Wand2, Plus, X, Heart, Phone } from "lucide-react";
import { PhoneInput } from "@/components/ui/phone-input";
import { cn } from "@/lib/utils";
import { CG_ASSEMBLIES, CG_DISTRICTS, CG_LOK_SABHA, getAssemblyByName } from "@/data/cg-assemblies";
import { getPartyOrg } from "@/data/party-organizations";

const contactSchema = z.object({
  first_name: z.string().min(1, "First name is required"),
  middle_name: z.string().optional(),
  last_name: z.string().optional(),
  mobile: z.string().min(10, "Valid mobile number is required"),
  whatsapp_number: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  birthday: z.string().optional(),
  gender: z.string().optional(),
  voter_id: z.string().optional(),
  village_ward: z.string().optional(),
  booth_number: z.string().optional(),
  constituency: z.string().optional(),
  lok_sabha_constituency: z.string().optional(),
  district: z.string().optional(),
  political_party: z.string().optional(),
  party_frontal: z.string().optional(),
  party_department: z.string().optional(),
  political_affiliation: z.string().optional(),
  leader_group: z.string().optional(),
  second_leader: z.string().optional(),
  caste: z.string().optional(),
  religion: z.string().optional(),
  non_political_org: z.string().optional(),
  facebook: z.string().optional(),
  instagram: z.string().optional(),
  twitter: z.string().optional(),
  volunteer: z.boolean().default(false),
  source: z.string().optional(),
  notes: z.string().optional(),
});

interface FamilyMember {
  name: string;
  relation: string;
  mobile: string;
  voter_id: string;
}

type FormValues = z.infer<typeof contactSchema>;

function buildFullName(first: string, middle?: string, last?: string) {
  return [first, middle, last].filter(Boolean).join(" ");
}

function parseNameParts(name: string) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return { first_name: parts[0], middle_name: "", last_name: "" };
  if (parts.length === 2) return { first_name: parts[0], middle_name: "", last_name: parts[1] };
  return { first_name: parts[0], middle_name: parts.slice(1, -1).join(" "), last_name: parts[parts.length - 1] };
}

const TABS = [
  { id: "basic",    label: "Personal",  icon: User },
  { id: "location", label: "Location",  icon: MapPin },
  { id: "political",label: "Political", icon: Flag },
  { id: "family",   label: "Family",    icon: Heart },
  { id: "social",   label: "Social",    icon: Users },
  { id: "media",    label: "Online",    icon: Share2 },
];

const RELATION_OPTIONS = [
  "Father", "Mother", "Spouse", "Husband", "Wife", "Son", "Daughter",
  "Brother", "Sister", "Uncle", "Aunt", "Grandfather", "Grandmother",
  "Father-in-law", "Mother-in-law", "Brother-in-law", "Sister-in-law",
  "Nephew", "Niece", "Cousin", "Guardian", "Other",
];

interface ContactFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contact?: Contact | null;
}

function AssemblyCombobox({ value, onChange }: { value: string; onChange: (val: string) => void }) {
  const [open, setOpen] = useState(false);
  const selected = CG_ASSEMBLIES.find(a => a.name === value);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open}
          className="w-full justify-between font-normal h-10 text-sm">
          {selected ? (
            <span className="flex items-center gap-2">
              <span className="font-medium">{selected.name}</span>
              <span className="text-muted-foreground text-xs">#{selected.number}</span>
            </span>
          ) : (
            <span className="text-muted-foreground">Search assembly constituency…</span>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[420px] p-0" align="start">
        <Command>
          <CommandInput placeholder="Type constituency name or district…" />
          <CommandList className="max-h-64">
            <CommandEmpty>No assembly found.</CommandEmpty>
            <CommandGroup>
              {CG_ASSEMBLIES.map(a => (
                <CommandItem key={a.number} value={`${a.name} ${a.district} ${a.lok_sabha}`}
                  onSelect={() => { onChange(a.name); setOpen(false); }}
                  className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Check className={cn("h-4 w-4 shrink-0", value === a.name ? "opacity-100 text-primary" : "opacity-0")} />
                    <span className="font-medium">{a.name}</span>
                    <span className="text-xs text-muted-foreground">#{a.number}</span>
                  </div>
                  <div className="text-right text-xs text-muted-foreground leading-tight">
                    <div>{a.district}</div>
                    <div className="text-[10px]">{a.lok_sabha} LS</div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function SimpleCombobox({ value, onChange, options, placeholder }: {
  value: string; onChange: (v: string) => void; options: string[]; placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open}
          className="w-full justify-between font-normal h-10 text-sm">
          {value || <span className="text-muted-foreground">{placeholder}</span>}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[320px] p-0" align="start">
        <Command>
          <CommandInput placeholder={`Search…`} />
          <CommandList className="max-h-56">
            <CommandEmpty>Not found.</CommandEmpty>
            <CommandGroup>
              {options.map(opt => (
                <CommandItem key={opt} value={opt}
                  onSelect={() => { onChange(opt); setOpen(false); }}>
                  <Check className={cn("mr-2 h-4 w-4", value === opt ? "opacity-100 text-primary" : "opacity-0")} />
                  {opt}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export function ContactFormDialog({ open, onOpenChange, contact }: ContactFormDialogProps) {
  const [activeTab, setActiveTab] = useState("basic");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const nameParts = contact?.name ? parseNameParts(contact.name) : { first_name: "", middle_name: "", last_name: "" };

  // Parse existing JSON-stored fields
  const existingAdditionalMobiles: string[] = (() => {
    try { const v = (contact as any)?.additional_mobiles; return Array.isArray(v) ? v : []; } catch { return []; }
  })();
  const existingFamilyMembers: FamilyMember[] = (() => {
    try { const v = (contact as any)?.family_members; return Array.isArray(v) ? v : []; } catch { return []; }
  })();

  const [additionalMobiles, setAdditionalMobiles] = useState<string[]>(existingAdditionalMobiles);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(existingFamilyMembers);

  const form = useForm<FormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      first_name: (contact as any)?.first_name || nameParts.first_name || "",
      middle_name: (contact as any)?.middle_name || nameParts.middle_name || "",
      last_name: (contact as any)?.last_name || nameParts.last_name || "",
      mobile: contact?.mobile || "",
      whatsapp_number: contact?.whatsapp_number || "",
      email: contact?.email || "",
      birthday: contact?.birthday || "",
      gender: contact?.gender || "",
      voter_id: (contact as any)?.voter_id || "",
      village_ward: contact?.village_ward || "",
      booth_number: contact?.booth_number || "",
      constituency: contact?.constituency || "",
      lok_sabha_constituency: contact?.lok_sabha_constituency || "",
      district: contact?.district || "",
      political_party: contact?.political_party || "",
      party_frontal: (contact as any)?.party_frontal || "",
      party_department: (contact as any)?.party_department || "",
      political_affiliation: contact?.political_affiliation || "",
      leader_group: contact?.leader_group || "",
      second_leader: contact?.second_leader || "",
      caste: contact?.caste || "",
      religion: contact?.religion || "",
      non_political_org: contact?.non_political_org || "",
      facebook: contact?.facebook || "",
      instagram: contact?.instagram || "",
      twitter: contact?.twitter || "",
      volunteer: contact?.volunteer || false,
      source: contact?.source || "manual",
      notes: contact?.notes || "",
    },
  });

  // Watch mobile to show placeholder hint in WhatsApp field
  const mobileValue = form.watch("mobile");
  const whatsappValue = form.watch("whatsapp_number");

  const selectedParty = form.watch("political_party") ?? "";
  const partyOrg = getPartyOrg(selectedParty);

  const createMutation = useCreateContact({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
        toast({ title: "Contact added successfully" });
        onOpenChange(false);
        form.reset();
        setActiveTab("basic");
      },
      onError: () => toast({ title: "Failed to add contact", variant: "destructive" }),
    },
  });

  const updateMutation = useUpdateContact({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
        toast({ title: "Contact updated successfully" });
        onOpenChange(false);
      },
      onError: () => toast({ title: "Failed to update contact", variant: "destructive" }),
    },
  });

  const isPending = createMutation.isPending || updateMutation.isPending;

  function onSubmit(values: FormValues) {
    const fullName = buildFullName(values.first_name, values.middle_name, values.last_name);
    const payload: Record<string, any> = {
      name: fullName,
      first_name: values.first_name || undefined,
      middle_name: values.middle_name || undefined,
      last_name: values.last_name || undefined,
    };
    for (const [k, v] of Object.entries(values)) {
      if (k === "first_name" || k === "middle_name" || k === "last_name") continue;
      payload[k] = v === "" ? undefined : v;
    }
    // Default WhatsApp to primary mobile if not filled
    if (!payload.whatsapp_number && payload.mobile) {
      payload.whatsapp_number = payload.mobile;
    }
    // Include additional mobiles and family members
    payload.additional_mobiles = additionalMobiles.filter(Boolean);
    payload.family_members = familyMembers.filter(m => m.name.trim());
    if (contact) {
      updateMutation.mutate({ id: contact.id, data: payload });
    } else {
      createMutation.mutate({ data: payload });
    }
  }

  function handleAssemblySelect(assemblyName: string) {
    form.setValue("constituency", assemblyName);
    const asm = getAssemblyByName(assemblyName);
    if (asm) {
      form.setValue("district", asm.district);
      form.setValue("lok_sabha_constituency", asm.lok_sabha);
    }
  }

  function handlePartyChange(party: string) {
    form.setValue("political_party", party);
    form.setValue("party_frontal", "");
    form.setValue("party_department", "");
  }

  const F = ({ name, label, placeholder, type = "text" }: { name: keyof FormValues; label: string; placeholder?: string; type?: string }) => (
    <FormField control={form.control} name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...field} value={field.value as string ?? ""} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  const S = ({ name, label, options }: { name: keyof FormValues; label: string; options: { value: string; label: string }[] }) => (
    <FormField control={form.control} name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</FormLabel>
          <Select onValueChange={field.onChange} value={field.value as string ?? ""}>
            <FormControl>
              <SelectTrigger><SelectValue placeholder={`Select ${label.toLowerCase()}`} /></SelectTrigger>
            </FormControl>
            <SelectContent>
              {options.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={(val) => { if (!val) { form.reset(); setActiveTab("basic"); } onOpenChange(val); }}>
      <DialogContent className="sm:max-w-[680px] bg-card max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-0 shrink-0">
          <DialogTitle className="text-xl font-serif">{contact ? "Edit Contact" : "Add New Contact"}</DialogTitle>
          <DialogDescription className="text-xs">
            {contact ? "Update contact details across all sections." : "Fill in the contact's details. Only First Name and Mobile are required."}
          </DialogDescription>
        </DialogHeader>

        {/* Tab nav */}
        <div className="flex gap-0 border-b border-border px-6 mt-4 shrink-0 overflow-x-auto">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={cn(
                "flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap",
                activeTab === id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
              )}>
              <Icon className="h-3.5 w-3.5" /> {label}
            </button>
          ))}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col flex-1 min-h-0">
            <div className="flex-1 overflow-y-auto px-6 py-5">

              {/* ── PERSONAL ── */}
              {activeTab === "basic" && (
                <div className="space-y-4">
                  {/* Name — three parts */}
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                      Full Name <span className="text-destructive">*</span>
                    </p>
                    <div className="grid grid-cols-3 gap-3">
                      <FormField control={form.control} name="first_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[10px] text-muted-foreground">First Name <span className="text-destructive">*</span></FormLabel>
                            <FormControl><Input placeholder="e.g. Raju" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField control={form.control} name="middle_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[10px] text-muted-foreground">Middle Name</FormLabel>
                            <FormControl><Input placeholder="e.g. Kumar" {...field} value={field.value ?? ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField control={form.control} name="last_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[10px] text-muted-foreground">Last Name</FormLabel>
                            <FormControl><Input placeholder="e.g. Netam" {...field} value={field.value ?? ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Primary mobile + WhatsApp */}
                  <div className="rounded-xl border border-border bg-secondary/10 p-4 space-y-3">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                      <Phone className="h-3 w-3" /> Contact Numbers
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      <FormField control={form.control} name="mobile"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Primary Mobile <span className="text-destructive">*</span></FormLabel>
                            <FormControl>
                              <PhoneInput value={field.value ?? ""} onChange={field.onChange} placeholder="98765 43210" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField control={form.control} name="whatsapp_number"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                              WhatsApp
                              {mobileValue && !whatsappValue && (
                                <span className="ml-2 text-[10px] font-normal text-green-600 normal-case">← defaults to mobile</span>
                              )}
                            </FormLabel>
                            <FormControl>
                              <PhoneInput value={field.value ?? ""} onChange={field.onChange}
                                placeholder={mobileValue ? `Default: ${mobileValue}` : "Same as or different from mobile"} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Additional mobile numbers */}
                    <div className="space-y-2">
                      <p className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">Additional Numbers</p>
                      {additionalMobiles.map((mob, idx) => (
                        <div key={idx} className="flex gap-2">
                          <PhoneInput
                            value={mob}
                            onChange={v => setAdditionalMobiles(prev => prev.map((m, i) => i === idx ? v : m))}
                            placeholder="Additional mobile"
                          />
                          <button type="button" onClick={() => setAdditionalMobiles(prev => prev.filter((_, i) => i !== idx))}
                            className="shrink-0 text-muted-foreground hover:text-destructive transition-colors">
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                      <Button type="button" variant="outline" size="sm" className="w-full h-8 text-xs gap-1.5 border-dashed"
                        onClick={() => setAdditionalMobiles(prev => [...prev, ""])}>
                        <Plus className="h-3.5 w-3.5" /> Add Another Number
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <F name="email" label="Email" placeholder="name@example.com" type="email" />
                    <F name="voter_id" label="Voter ID (EPIC)" placeholder="e.g. ABC1234567" />
                    <F name="birthday" label="Date of Birth" placeholder="dd/mm/yyyy" />
                    <S name="gender" label="Gender" options={[
                      { value: "male", label: "Male" },
                      { value: "female", label: "Female" },
                      { value: "other", label: "Other" },
                    ]} />
                  </div>

                  <FormField control={form.control} name="volunteer"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-xl border border-border p-4 bg-secondary/20">
                        <div>
                          <FormLabel className="text-sm font-semibold">Campaign Volunteer</FormLabel>
                          <p className="text-xs text-muted-foreground mt-0.5">Is this contact willing to volunteer for the campaign?</p>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* ── LOCATION ── */}
              {activeTab === "location" && (
                <div className="space-y-5">
                  <FormField control={form.control} name="constituency"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between">
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                            Assembly Constituency
                          </FormLabel>
                          <span className="flex items-center gap-1 text-[10px] text-amber-600 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5">
                            <Wand2 className="h-2.5 w-2.5" /> Auto-fills District & Lok Sabha
                          </span>
                        </div>
                        <AssemblyCombobox value={field.value ?? ""} onChange={handleAssemblySelect} />
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="district"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">District</FormLabel>
                          <SimpleCombobox value={field.value ?? ""} onChange={field.onChange} options={CG_DISTRICTS} placeholder="Select district" />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField control={form.control} name="lok_sabha_constituency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Lok Sabha Constituency</FormLabel>
                          <SimpleCombobox value={field.value ?? ""} onChange={field.onChange} options={CG_LOK_SABHA} placeholder="Select Lok Sabha" />
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <F name="village_ward" label="Village / Ward" placeholder="e.g. Jamgaon" />
                    <F name="booth_number" label="Booth Number" placeholder="e.g. 44" />
                  </div>
                </div>
              )}

              {/* ── POLITICAL ── */}
              {activeTab === "political" && (
                <div className="space-y-5">
                  {/* Party selection */}
                  <FormField control={form.control} name="political_party"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Political Party</FormLabel>
                        <Select onValueChange={handlePartyChange} value={field.value ?? ""}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select party" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="bjp">BJP — Bharatiya Janata Party</SelectItem>
                            <SelectItem value="inc">INC — Indian National Congress</SelectItem>
                            <SelectItem value="aap">AAP — Aam Aadmi Party</SelectItem>
                            <SelectItem value="bsp">BSP — Bahujan Samaj Party</SelectItem>
                            <SelectItem value="sp">SP — Samajwadi Party</SelectItem>
                            <SelectItem value="jcc">JCC (J) — Janata Congress Chhattisgarh</SelectItem>
                            <SelectItem value="independent">Independent</SelectItem>
                            <SelectItem value="other">Other / Undecided</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Frontals — shown only when party has frontals */}
                  {partyOrg.frontals.length > 0 && (
                    <div className="rounded-xl border border-border bg-secondary/10 p-4 space-y-4">
                      <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                        {selectedParty.toUpperCase()} Frontals & Wings
                      </p>
                      <FormField control={form.control} name="party_frontal"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Frontal Organisation / Wing</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value ?? ""}>
                              <FormControl>
                                <SelectTrigger><SelectValue placeholder="Select frontal or wing" /></SelectTrigger>
                              </FormControl>
                              <SelectContent className="max-h-56">
                                {partyOrg.frontals.map(f => (
                                  <SelectItem key={f} value={f}>{f}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Departments — shown only when party has departments */}
                      {partyOrg.departments.length > 0 && (
                        <FormField control={form.control} name="party_department"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Department / Cell</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value ?? ""}>
                                <FormControl>
                                  <SelectTrigger><SelectValue placeholder="Select department or cell" /></SelectTrigger>
                                </FormControl>
                                <SelectContent className="max-h-56">
                                  {partyOrg.departments.map(d => (
                                    <SelectItem key={d} value={d}>{d}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  )}

                  {/* Designation */}
                  <div className="grid grid-cols-2 gap-4">
                    <F name="political_affiliation" label="Designation / Role" placeholder="e.g. Mandal President" />
                    <F name="leader_group" label="Leader Group" placeholder="Leader this contact reports to" />
                    <F name="second_leader" label="Second Leader" placeholder="Alternate leader contact" />
                    <F name="non_political_org" label="Non-Political Organisation" placeholder="e.g. Self-Help Group, Union" />
                  </div>
                </div>
              )}

              {/* ── FAMILY TREE ── */}
              {activeTab === "family" && (
                <div className="space-y-4">
                  <div className="rounded-xl border border-border bg-secondary/10 p-4 space-y-1">
                    <p className="text-sm font-semibold flex items-center gap-2"><Heart className="h-4 w-4 text-rose-500" /> Family Members</p>
                    <p className="text-xs text-muted-foreground">Track family members linked to this contact. Useful for household voter outreach.</p>
                  </div>

                  <div className="space-y-3">
                    {familyMembers.map((member, idx) => (
                      <div key={idx} className="rounded-xl border border-border bg-card p-4 space-y-3 relative">
                        <button type="button" onClick={() => setFamilyMembers(prev => prev.filter((_, i) => i !== idx))}
                          className="absolute top-3 right-3 text-muted-foreground hover:text-destructive transition-colors">
                          <X className="h-3.5 w-3.5" />
                        </button>
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Member #{idx + 1}</p>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Name <span className="text-destructive">*</span></label>
                            <Input value={member.name} onChange={e => setFamilyMembers(prev => prev.map((m, i) => i === idx ? { ...m, name: e.target.value } : m))}
                              placeholder="Full name" />
                          </div>
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Relation</label>
                            <select value={member.relation}
                              onChange={e => setFamilyMembers(prev => prev.map((m, i) => i === idx ? { ...m, relation: e.target.value } : m))}
                              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                              <option value="">Select relation</option>
                              {RELATION_OPTIONS.map(r => <option key={r} value={r.toLowerCase()}>{r}</option>)}
                            </select>
                          </div>
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Mobile</label>
                            <PhoneInput value={member.mobile}
                              onChange={v => setFamilyMembers(prev => prev.map((m, i) => i === idx ? { ...m, mobile: v } : m))}
                              placeholder="Mobile number" />
                          </div>
                          <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Voter ID (EPIC)</label>
                            <Input value={member.voter_id} onChange={e => setFamilyMembers(prev => prev.map((m, i) => i === idx ? { ...m, voter_id: e.target.value } : m))}
                              placeholder="e.g. ABC1234567" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button type="button" variant="outline" className="w-full gap-2 border-dashed"
                    onClick={() => setFamilyMembers(prev => [...prev, { name: "", relation: "", mobile: "", voter_id: "" }])}>
                    <Plus className="h-4 w-4" /> Add Family Member
                  </Button>
                </div>
              )}

              {/* ── SOCIAL PROFILE ── */}
              {activeTab === "social" && (
                <div className="grid grid-cols-2 gap-4">
                  <S name="caste" label="Caste Category" options={[
                    { value: "general", label: "General" },
                    { value: "obc", label: "OBC" },
                    { value: "sc", label: "SC" },
                    { value: "st", label: "ST" },
                  ]} />
                  <S name="religion" label="Religion" options={[
                    { value: "hindu", label: "Hindu" },
                    { value: "muslim", label: "Muslim" },
                    { value: "christian", label: "Christian" },
                    { value: "sikh", label: "Sikh" },
                    { value: "other", label: "Other" },
                  ]} />
                  <S name="source" label="Contact Source" options={[
                    { value: "manual", label: "Manual Entry" },
                    { value: "ai_intake", label: "AI Intake" },
                    { value: "csv_import", label: "CSV Import" },
                    { value: "field_survey", label: "Field Survey" },
                    { value: "referral", label: "Referral" },
                    { value: "event", label: "Event / Rally" },
                  ]} />
                  <div className="col-span-2">
                    <FormField control={form.control} name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Internal Notes</FormLabel>
                          <FormControl>
                            <Textarea rows={4} placeholder="Any specific issues, requests, or observations about this contact..." className="resize-none" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}

              {/* ── ONLINE / MEDIA ── */}
              {activeTab === "media" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <FormField control={form.control} name="facebook"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Facebook</FormLabel>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground shrink-0">facebook.com/</span>
                            <FormControl><Input placeholder="username or profile URL" {...field} value={field.value ?? ""} /></FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField control={form.control} name="instagram"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Instagram</FormLabel>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground shrink-0">instagram.com/</span>
                            <FormControl><Input placeholder="@handle" {...field} value={field.value ?? ""} /></FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField control={form.control} name="twitter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Twitter / X</FormLabel>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground shrink-0">x.com/</span>
                            <FormControl><Input placeholder="@handle" {...field} value={field.value ?? ""} /></FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-border shrink-0 flex items-center justify-between bg-secondary/20">
              <div className="text-xs text-muted-foreground">
                {activeTab !== "basic" && (
                  <button type="button" onClick={() => {
                    const idx = TABS.findIndex(t => t.id === activeTab);
                    if (idx > 0) setActiveTab(TABS[idx - 1].id);
                  }} className="hover:text-foreground transition-colors">← Previous</button>
                )}
              </div>
              <div className="flex items-center gap-3">
                <Button type="button" variant="ghost" size="sm" onClick={() => onOpenChange(false)}>Cancel</Button>
                {activeTab !== TABS[TABS.length - 1].id ? (
                  <Button type="button" size="sm" onClick={() => {
                    const idx = TABS.findIndex(t => t.id === activeTab);
                    setActiveTab(TABS[idx + 1].id);
                  }}>Next →</Button>
                ) : (
                  <Button type="submit" size="sm" disabled={isPending} className="font-semibold min-w-[100px]">
                    {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : (contact ? "Save Changes" : "Add Contact")}
                  </Button>
                )}
              </div>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
