import { ReactNode } from "react";
import { AppSidebar } from "./app-sidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AppLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const isDashboard = location === "/";

  const getPageTitle = () => {
    if (location === "/") return "Dashboard Overview";
    if (location.startsWith("/contacts/")) return "Contact Profile";
    if (location.startsWith("/contacts")) return "Contacts Directory";
    if (location.startsWith("/volunteers")) return "Volunteer Network";
    if (location.startsWith("/issues")) return "Issue Tracking";
    if (location.startsWith("/messages")) return "Campaign Messaging";
    if (location.startsWith("/campaigns")) return "Campaigns";
    if (location.startsWith("/calendar")) return "Calendar & Activity Planner";
    if (location.startsWith("/assembly")) return "Assembly Dashboard";
    if (location.startsWith("/ai-intake")) return "AI Intake Engine";
    return "Political CRM";
  };

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background/50 font-sans">
        <AppSidebar />
        <div className="flex w-full flex-col flex-1 overflow-hidden relative">
          
          {/* Subtle background gradient mesh for depth */}
          <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none -z-10" />

          <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-border/50 bg-card/80 backdrop-blur-md px-6 shadow-sm sticky top-0 z-20 transition-all">
            <div className="flex items-center gap-3">
              <SidebarTrigger className="text-muted-foreground hover:text-foreground hover:bg-secondary/50" />
              <div className="h-6 w-px bg-border/50 hidden sm:block" />

              {!isDashboard && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => window.history.back()}
                  className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground px-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span className="hidden sm:inline text-sm">Back</span>
                </Button>
              )}

              {!isDashboard && <div className="h-6 w-px bg-border/50 hidden sm:block" />}

              <motion.h1 
                key={location}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-base sm:text-xl font-bold font-serif text-foreground tracking-tight truncate max-w-[150px] sm:max-w-[300px] md:max-w-none"
              >
                {getPageTitle()}
              </motion.h1>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground bg-secondary/50 px-3 py-1.5 rounded-full border border-border/50">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                System Online
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-y-auto p-4 md:p-8 z-0">
            <motion.div
              key={location}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="mx-auto max-w-7xl"
            >
              {children}
            </motion.div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
