import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, Users, AlertTriangle, MessageSquare,
  Landmark, Heart, Megaphone, Building2, Calendar, Brain,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarHeader, SidebarFooter,
} from "@/components/ui/sidebar";

const mainNavItems = [
  { title: "Dashboard",   url: "/",            icon: LayoutDashboard },
  { title: "Contacts",    url: "/contacts",    icon: Users },
  { title: "Volunteers",  url: "/volunteers",  icon: Heart },
  { title: "Issues",      url: "/issues",      icon: AlertTriangle },
  { title: "Messages",    url: "/messages",    icon: MessageSquare },
  { title: "Campaigns",   url: "/campaigns",   icon: Megaphone },
  { title: "Calendar",    url: "/calendar",    icon: Calendar },
  { title: "Assembly",    url: "/assembly",    icon: Building2 },
];

const intelligenceNavItems = [
  { title: "AI Intake",   url: "/ai-intake",   icon: Brain },
];

function NavItem({ item, isActive }: { item: { title: string; url: string; icon: any }; isActive: boolean }) {
  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        asChild
        isActive={isActive}
        tooltip={item.title}
        className={`
          transition-all duration-200 py-5
          ${isActive
            ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
            : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"}
        `}
      >
        <Link href={item.url} className="flex items-center gap-3 w-full">
          <item.icon className={`h-5 w-5 ${isActive ? "text-primary-foreground" : "text-sidebar-foreground/50"}`} />
          <span>{item.title}</span>
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

export function AppSidebar() {
  const [location] = useLocation();

  const isActive = (url: string) =>
    url === "/" ? location === "/" : location.startsWith(url);

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border bg-sidebar h-16 flex items-center px-4">
        <div className="flex items-center gap-3 w-full">
          <div className="bg-primary/20 p-2 rounded-lg text-primary flex-shrink-0">
            <Landmark className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-serif font-bold text-lg text-sidebar-foreground truncate tracking-tight">
            Political CRM
          </span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-wider text-sidebar-foreground/50 mt-4 mb-2">
            Main Menu
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map(item => (
                <NavItem key={item.title} item={item} isActive={isActive(item.url)} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-wider text-sidebar-foreground/50 mb-2">
            Intelligence
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {intelligenceNavItems.map(item => (
                <NavItem key={item.title} item={item} isActive={isActive(item.url)} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-3">
        <div className="rounded-xl bg-primary/5 border border-primary/10 px-3 py-2.5 text-xs text-sidebar-foreground/60">
          <div className="flex items-center gap-1.5 mb-1">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500" />
            </span>
            <span className="text-green-600 font-semibold">Database Connected</span>
          </div>
          <span className="font-mono">PostgreSQL · Live</span>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
