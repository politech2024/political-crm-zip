import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export const COUNTRIES = [
  { code: "91",  flag: "🇮🇳", label: "India",       format: "XXXXX XXXXX", maxLen: 10 },
  { code: "977", flag: "🇳🇵", label: "Nepal",       format: "XXXXXXXXXX",  maxLen: 10 },
  { code: "880", flag: "🇧🇩", label: "Bangladesh",  format: "XXXXXXXXXX",  maxLen: 10 },
  { code: "92",  flag: "🇵🇰", label: "Pakistan",    format: "XXXXXXXXXX",  maxLen: 10 },
  { code: "94",  flag: "🇱🇰", label: "Sri Lanka",   format: "XXXXXXXXX",   maxLen: 9  },
  { code: "975", flag: "🇧🇹", label: "Bhutan",      format: "XXXXXXXX",    maxLen: 8  },
  { code: "960", flag: "🇲🇻", label: "Maldives",    format: "XXXXXXX",     maxLen: 7  },
  { code: "971", flag: "🇦🇪", label: "UAE",         format: "XXXXXXXXX",   maxLen: 9  },
  { code: "1",   flag: "🇺🇸", label: "USA/Canada",  format: "XXXXXXXXXX",  maxLen: 10 },
  { code: "44",  flag: "🇬🇧", label: "UK",          format: "XXXXXXXXXX",  maxLen: 10 },
  { code: "61",  flag: "🇦🇺", label: "Australia",   format: "XXXXXXXXX",   maxLen: 9  },
];

const DEFAULT_CODE = "91";

function parsePhoneValue(val: string): { cc: string; number: string } {
  if (!val) return { cc: DEFAULT_CODE, number: "" };
  if (val.startsWith("+")) {
    const m = val.match(/^\+(\d+)-(.*)$/);
    if (m) return { cc: m[1], number: m[2].replace(/\D/g, "") };
  }
  const d = val.replace(/\D/g, "");
  for (const country of COUNTRIES.filter(c => c.code !== "1")) {
    if (d.startsWith(country.code) && d.length === country.code.length + country.maxLen) {
      return { cc: country.code, number: d.slice(country.code.length) };
    }
  }
  return { cc: DEFAULT_CODE, number: d };
}

export function buildPhoneValue(cc: string, number: string): string {
  if (!number) return "";
  return `+${cc}-${number}`;
}

interface PhoneInputProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  className?: string;
  maxLength?: number;
}

export function PhoneInput({ value, onChange, placeholder, maxLength }: PhoneInputProps) {
  const { cc, number } = parsePhoneValue(value);
  const country = COUNTRIES.find(c => c.code === cc) ?? COUNTRIES[0];

  const handleCodeChange = (newCc: string) => {
    onChange(buildPhoneValue(newCc, number));
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const num = e.target.value.replace(/\D/g, "");
    onChange(buildPhoneValue(cc, num));
  };

  return (
    <div className="flex items-stretch">
      <Select value={cc} onValueChange={handleCodeChange}>
        <SelectTrigger className="w-[88px] rounded-r-none border-r-0 bg-secondary shrink-0 focus:ring-0 focus:ring-offset-0 focus-visible:ring-0">
          <SelectValue>
            <span className="flex items-center gap-1 text-sm">
              <span>{country.flag}</span>
              <span className="font-mono text-xs text-muted-foreground">+{cc}</span>
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {COUNTRIES.map(c => (
            <SelectItem key={c.code} value={c.code}>
              <span className="flex items-center gap-2">
                <span>{c.flag}</span>
                <span className="font-mono text-xs">+{c.code}</span>
                <span className="text-muted-foreground text-xs">{c.label}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Input
        value={number}
        onChange={handleNumberChange}
        placeholder={placeholder ?? country.format.replace(/X/g, "0")}
        className="rounded-l-none flex-1"
        maxLength={maxLength ?? country.maxLen}
      />
    </div>
  );
}
