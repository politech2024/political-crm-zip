import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateMessage, getGetMessagesQueryKey, useGetStats } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send, Users } from "lucide-react";

const messageSchema = z.object({
  content: z.string().min(10, "Message is too short").max(500, "Message is too long"),
  channel: z.string().default("sms"),
});

type FormValues = z.infer<typeof messageSchema>;

interface MessageFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MessageFormDialog({ open, onOpenChange }: MessageFormDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: statsData } = useGetStats();
  
  const totalContacts = statsData?.data.total_contacts || 0;

  const form = useForm<FormValues>({
    resolver: zodResolver(messageSchema),
    defaultValues: {
      content: "",
      channel: "sms",
    },
  });

  const createMutation = useCreateMessage({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMessagesQueryKey() });
        toast({ title: "Message campaign started successfully" });
        onOpenChange(false);
        form.reset();
      },
      onError: () => toast({ title: "Failed to send messages", variant: "destructive" })
    }
  });

  function onSubmit(values: FormValues) {
    createMutation.mutate({ 
      data: { 
        ...values,
        recipients: totalContacts 
      } 
    });
  }

  return (
    <Dialog open={open} onOpenChange={(val) => {
      if(!val) form.reset();
      onOpenChange(val);
    }}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif">Compose Broadcast</DialogTitle>
          <DialogDescription>
            Send a mass message to all registered constituents in your network.
          </DialogDescription>
        </DialogHeader>

        <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 my-2 flex items-center gap-4">
          <div className="bg-primary/20 p-3 rounded-full text-primary">
            <Users className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">Target Audience</p>
            <p className="text-2xl font-bold font-serif text-primary">{totalContacts.toLocaleString()} Contacts</p>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="channel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Communication Channel</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger><SelectValue placeholder="Select channel" /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="sms">SMS Text</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="email">Email Blast</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message Content</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Type your campaign message here..." 
                      className="resize-none min-h-[150px] font-sans text-base" 
                      {...field} 
                    />
                  </FormControl>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Keep it concise and clear.</span>
                    <span className={field.value.length > 500 ? "text-destructive font-medium" : ""}>
                      {field.value.length} / 500
                    </span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end pt-4 gap-3">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button 
                type="submit" 
                disabled={createMutation.isPending || totalContacts === 0} 
                className="min-w-[140px] shadow-lg shadow-primary/20 bg-gradient-to-r from-primary to-primary/90 hover:opacity-90"
              >
                {createMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Send className="mr-2 h-4 w-4" />
                )}
                Send Broadcast
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
