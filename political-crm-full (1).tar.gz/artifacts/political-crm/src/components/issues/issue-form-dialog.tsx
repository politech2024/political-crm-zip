import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateIssue, useUpdateIssue, getGetIssuesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Issue } from "@workspace/api-client-react/src/generated/api.schemas";
import { Loader2 } from "lucide-react";

const issueSchema = z.object({
  issue_title: z.string().min(3, "Title is required"),
  issue_description: z.string().optional(),
  issue_status: z.string().default("new"),
  issue_priority: z.string().optional(),
  contact_name: z.string().optional(),
  district: z.string().optional(),
  constituency: z.string().optional(),
});

type FormValues = z.infer<typeof issueSchema>;

interface IssueFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  issue?: Issue | null;
}

export function IssueFormDialog({ open, onOpenChange, issue }: IssueFormDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(issueSchema),
    defaultValues: {
      issue_title: issue?.issue_title || "",
      issue_description: issue?.issue_description || "",
      issue_status: issue?.issue_status || "new",
      issue_priority: issue?.issue_priority || "medium",
      contact_name: issue?.contact_name || "",
      district: issue?.district || "",
      constituency: issue?.constituency || "",
    },
  });

  const createMutation = useCreateIssue({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetIssuesQueryKey() });
        toast({ title: "Issue logged successfully" });
        onOpenChange(false);
        form.reset();
      }
    }
  });

  const updateMutation = useUpdateIssue({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetIssuesQueryKey() });
        toast({ title: "Issue updated successfully" });
        onOpenChange(false);
      }
    }
  });

  const isPending = createMutation.isPending || updateMutation.isPending;

  function onSubmit(values: FormValues) {
    if (issue) {
      updateMutation.mutate({ id: issue.id, data: values });
    } else {
      createMutation.mutate({ data: values });
    }
  }

  return (
    <Dialog open={open} onOpenChange={(val) => {
      if(!val) form.reset();
      onOpenChange(val);
    }}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif">{issue ? 'Edit Issue' : 'Log New Issue'}</DialogTitle>
          <DialogDescription>
            Record public grievances and track their resolution status.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="issue_title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Issue Title <span className="text-destructive">*</span></FormLabel>
                  <FormControl><Input placeholder="Road repair needed in Ward 4..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="issue_status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="in-progress">In Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="issue_priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select priority" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="district"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>District</FormLabel>
                    <FormControl><Input placeholder="E.g., North District" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="constituency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assembly / Constituency</FormLabel>
                    <FormControl><Input placeholder="E.g., Central Assembly" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contact_name"
                render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Reported By (Contact Name)</FormLabel>
                    <FormControl><Input placeholder="Name of the constituent who reported" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="issue_description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Provide full context, location details, and history..." 
                      className="resize-none min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end pt-4 gap-3">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={isPending} className="min-w-[120px] shadow-md shadow-primary/20">
                {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {issue ? 'Save Changes' : 'Log Issue'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
