import { useState, useRef, useCallback } from "react";
import { useGetContacts } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  Brain, Loader2, Sparkles, User, AlertTriangle, Calendar as CalIcon,
  CheckCircle, AlertCircle, Clock, History, Upload, FileText,
  Layers, ChevronRight, X, SkipForward, Play, Pause, Download,
  Plus, Heart, MapPin, Flag, Users, Share2, Phone,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CG_ASSEMBLIES, CG_DISTRICTS } from "@/data/cg-assemblies";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

// ─── Smart field normalizers ─────────────────────────────────────────────────

function normMobile(raw: string): string {
  const d = String(raw ?? "").replace(/\D/g, "");
  if (d.length === 10) return `+91-${d}`;
  if (d.length === 12 && d.startsWith("91")) return `+91-${d.slice(2)}`;
  if (d.length === 13 && d.startsWith("091")) return `+91-${d.slice(3)}`;
  if (d.length > 10) return `+91-${d.slice(-10)}`;
  return d.length >= 7 ? d : "";
}

function normGender(g: string): string {
  const l = (g ?? "").toLowerCase();
  if (/^m|male|पुरुष|boy|man|gents|gent/.test(l)) return "male";
  if (/^f|female|महिला|women|woman|girl|lady|ladies/.test(l)) return "female";
  return l ? "other" : "";
}

function normParty(p: string): string {
  const l = (p ?? "").toLowerCase().replace(/\s+/g, "");
  if (l.includes("bjp") || l.includes("भाजपा") || l.includes("bharatiya")) return "bjp";
  if (l.includes("inc") || l.includes("congress") || l.includes("कांग्रेस")) return "inc";
  if (l.includes("aap") || l.includes("aamadmi")) return "aap";
  if (l.includes("bsp") || l.includes("bahujan")) return "bsp";
  if (l.includes("jcc") || l.includes("जनता")) return "jcc";
  if (l.includes("independent") || l.includes("निर्दलीय")) return "independent";
  return p ? "other" : "";
}

function normCaste(c: string): string {
  const l = (c ?? "").toLowerCase();
  if (/general|gen\b|ur\b|open|सामान्य/.test(l)) return "general";
  if (/\bobc\b|backward|पिछड़/.test(l)) return "obc";
  if (/\bsc\b|scheduled caste|dalit|हरिजन/.test(l)) return "sc";
  if (/\bst\b|scheduled tribe|tribal|आदिवासी|adivasi/.test(l)) return "st";
  return "";
}

function normReligion(r: string): string {
  const l = (r ?? "").toLowerCase();
  if (/hindu|हिंदू|हिन्दू/.test(l)) return "hindu";
  if (/muslim|islam|मुस्लिम|मुसलमान/.test(l)) return "muslim";
  if (/christian|ईसाई/.test(l)) return "christian";
  if (/sikh|सिख/.test(l)) return "sikh";
  return l ? "other" : "";
}

// ─── Extract first valid mobile from any string ───────────────────────────────
function extractFirstMobile(text: string): string {
  if (!text) return "";
  // Strip formatting characters but keep digits in order
  const cleaned = text.replace(/[\s\-().+]/g, "");
  // Find a run of 10+ digits
  const match = cleaned.match(/(?:91)?([6-9]\d{9})/);
  if (match) return normMobile(match[1]);
  // Fallback: look for digit groups that total 10 digits starting with 6-9
  const allDigits = text.replace(/\D/g, "");
  const m2 = allDigits.match(/([6-9]\d{9})/);
  if (m2) return normMobile(m2[1]);
  return "";
}

// ─── Designation / contact-type keyword table ─────────────────────────────────
const DESIGNATION_PATTERNS: { pattern: RegExp; type: string }[] = [
  { pattern: /\b(ex[\-\s]?mla|पूर्व[\s]*विधायक)\b/i,         type: "leader" },
  { pattern: /\b(mla|विधायक)\b/i,                              type: "leader" },
  { pattern: /\b(ex[\-\s]?mp|पूर्व[\s]*सांसद)\b/i,            type: "leader" },
  { pattern: /\b(mp|सांसद)\b/i,                                type: "leader" },
  { pattern: /\b(sarpanch|सरपंच)\b/i,                          type: "sarpanch" },
  { pattern: /\b(up[\s-]?sarpanch|उप[\s]*सरपंच)\b/i,          type: "community_leader" },
  { pattern: /\b(parishad|परिषद)\b/i,                          type: "community_leader" },
  { pattern: /\b(panchayat[\s]*president)\b/i,                 type: "community_leader" },
  { pattern: /\b(ward[\s]*member|पार्षद|parshad)\b/i,          type: "community_leader" },
  { pattern: /\b(councillor|councilor|काउंसलर)\b/i,            type: "community_leader" },
  { pattern: /\b(panch|पंच)\b/i,                               type: "community_leader" },
  { pattern: /\b(booth[\s]*pramukh|बूथ[\s]*प्रमुख)\b/i,       type: "party_worker" },
  { pattern: /\b(mandal[\s]*pramukh|मंडल[\s]*प्रमुख)\b/i,     type: "leader" },
  { pattern: /\b(mandal|मंडल)\b/i,                             type: "party_worker" },
  { pattern: /\b(pradhan|प्रधान)\b/i,                          type: "leader" },
  { pattern: /\b(president|अध्यक्ष|adhyaksh)\b/i,             type: "leader" },
  { pattern: /\b(secretary|सचिव|sachiv)\b/i,                   type: "party_worker" },
  { pattern: /\b(treasurer|कोषाध्यक्ष)\b/i,                   type: "party_worker" },
  { pattern: /\b(youth[\s]*leader|युवा[\s]*नेता)\b/i,          type: "youth_leader" },
  { pattern: /\b(youth[\s]*president|युवा[\s]*अध्यक्ष)\b/i,   type: "youth_leader" },
  { pattern: /\b(youth|yuva|युवा)\b/i,                         type: "youth_leader" },
  { pattern: /\b(mahila[\s]*president|महिला[\s]*अध्यक्ष)\b/i, type: "women_leader" },
  { pattern: /\b(mahila|महिला)\b/i,                            type: "women_leader" },
  { pattern: /\b(neta|netaji|नेताजी|नेता)\b/i,                type: "leader" },
  { pattern: /\b(volunteer|swayamsevak|स्वयंसेवक)\b/i,        type: "volunteer" },
  { pattern: /\b(journalist|patrakar|पत्रकार)\b/i,            type: "journalist" },
  { pattern: /\b(donor|daani|दानी)\b/i,                        type: "donor" },
  { pattern: /\b(dr\.|doctor|डॉक्टर)\b/i,                      type: "community_leader" },
  { pattern: /\b(adv\.|advocate|advocate|अधिवक्ता)\b/i,        type: "community_leader" },
  { pattern: /\b(worker|karyakarta|कार्यकर्ता)\b/i,           type: "party_worker" },
  { pattern: /\b(influencer|प्रभावशाली)\b/i,                  type: "influencer" },
];

// Party keywords embedded in a name field
const PARTY_NAME_PATTERNS: { pattern: RegExp; party: string }[] = [
  { pattern: /\b(bjp|भाजपा|bharatiya[\s]*janata)\b/i,     party: "bjp" },
  { pattern: /\b(inc|congress|कांग्रेस|कॉंग्रेस)\b/i,    party: "inc" },
  { pattern: /\b(aap|aam[\s]*aadmi|आम[\s]*आदमी)\b/i,     party: "aap" },
  { pattern: /\b(bsp|bahujan|बसपा|बहुजन)\b/i,            party: "bsp" },
  { pattern: /\b(jcc|जनता[\s]*congress|जनता[\s]*कांग्रेस)\b/i, party: "jcc" },
  { pattern: /\b(independent|निर्दलीय|nirdaliya)\b/i,    party: "independent" },
];

/**
 * Scans full_name for embedded party / designation / assembly / district tokens.
 * Returns cleaned name + discovered fields.
 */
function parseNameField(raw: string, existingFields: Record<string, any> = {}): {
  cleanName: string;
  party?: string;
  type?: string;
  assembly?: typeof CG_ASSEMBLIES[0] | null;
  district?: string;
  mobileFound?: string;
} {
  if (!raw?.trim()) return { cleanName: raw || "" };

  let text = raw.trim();
  const result: ReturnType<typeof parseNameField> = { cleanName: text };

  // ── 1. Extract any mobile number embedded in the name ──────────────────────
  const embeddedMobile = extractFirstMobile(text);
  if (embeddedMobile && !existingFields.primary_mobile && !existingFields.mobile) {
    result.mobileFound = embeddedMobile;
    text = text.replace(/[\d\s\-().+]{10,}/g, " ").trim();
  }

  // ── 2. Party detection ─────────────────────────────────────────────────────
  if (!existingFields.party) {
    for (const { pattern, party } of PARTY_NAME_PATTERNS) {
      if (pattern.test(text)) {
        result.party = party;
        text = text.replace(pattern, " ").trim();
        break;
      }
    }
  }

  // ── 3. Designation / type detection ───────────────────────────────────────
  if (!existingFields.type) {
    for (const { pattern, type } of DESIGNATION_PATTERNS) {
      if (pattern.test(text)) {
        result.type = type;
        text = text.replace(pattern, " ").trim();
        // Don't break — strip all found designations from name
      }
    }
  }

  // ── 4. Assembly detection (fuzzy, word-by-word) ───────────────────────────
  if (!existingFields.assembly_name && !existingFields.assembly) {
    // Try progressively shorter trailing/leading substrings to detect an assembly name
    const words = text.split(/[\s,]+/).filter(Boolean);
    for (let len = Math.min(words.length, 4); len >= 1; len--) {
      // Try suffix (e.g. "Raju Netam Raipur" → try "Raipur")
      const suffix = words.slice(-len).join(" ");
      const aMatch = fuzzyAssembly(suffix);
      if (aMatch && suffix.length > 2) {
        result.assembly = aMatch;
        if (!existingFields.district) result.district = aMatch.district;
        // Remove matched tokens from name
        text = words.slice(0, words.length - len).join(" ").trim();
        break;
      }
      // Try prefix
      const prefix = words.slice(0, len).join(" ");
      const aMatch2 = fuzzyAssembly(prefix);
      if (aMatch2 && prefix.length > 2) {
        result.assembly = aMatch2;
        if (!existingFields.district) result.district = aMatch2.district;
        text = words.slice(len).join(" ").trim();
        break;
      }
    }
  }

  // ── 5. District detection (if no assembly matched) ─────────────────────────
  if (!result.assembly && !existingFields.district) {
    const words = text.split(/[\s,]+/).filter(Boolean);
    for (let len = Math.min(words.length, 3); len >= 1; len--) {
      const suffix = words.slice(-len).join(" ");
      const d = CG_DISTRICTS.find(d =>
        d.toLowerCase() === suffix.toLowerCase() ||
        d.toLowerCase().includes(suffix.toLowerCase()) ||
        suffix.toLowerCase().includes(d.toLowerCase())
      );
      if (d && suffix.length > 3) {
        result.district = d;
        text = words.slice(0, words.length - len).join(" ").trim();
        break;
      }
    }
  }

  // ── 6. Clean up punctuation / extra whitespace from name ─────────────────
  result.cleanName = text.replace(/[,\-_/|]+$/, "").replace(/\s{2,}/g, " ").trim() || raw.trim();

  return result;
}

// ─── Fuzzy geography matching ─────────────────────────────────────────────────

function fuzzyAssembly(name: string): typeof CG_ASSEMBLIES[0] | null {
  if (!name?.trim()) return null;
  const q = name.toLowerCase().replace(/[^a-z0-9\u0900-\u097F ]/gi, "").trim();

  // 1. Exact (case-insensitive)
  const exact = CG_ASSEMBLIES.find(a => a.name.toLowerCase() === q);
  if (exact) return exact;

  // 2. By assembly number prefix (e.g. "AC 12", "No 12")
  const numMatch = q.match(/\b(\d{1,3})\b/);
  if (numMatch) {
    const n = parseInt(numMatch[1]);
    const byNum = CG_ASSEMBLIES.find(a => a.number === n);
    if (byNum) return byNum;
  }

  // 3. One string contains the other
  const contains = CG_ASSEMBLIES.find(a =>
    a.name.toLowerCase().includes(q) || q.includes(a.name.toLowerCase())
  );
  if (contains) return contains;

  // 4. All query words appear in assembly name
  const words = q.split(/\s+/).filter(w => w.length > 2);
  const allWords = CG_ASSEMBLIES.find(a =>
    words.length > 0 && words.every(w => a.name.toLowerCase().includes(w))
  );
  if (allWords) return allWords;

  // 5. Any word match (at least one significant word)
  const anyWord = CG_ASSEMBLIES.find(a => {
    const aWords = a.name.toLowerCase().split(/\s+/);
    return words.some(w => w.length > 3 && aWords.some(aw => aw.includes(w) || w.includes(aw)));
  });
  return anyWord || null;
}

function fuzzyDistrict(name: string): string {
  if (!name?.trim()) return "";
  const q = name.toLowerCase().trim();
  const exact = CG_DISTRICTS.find(d => d.toLowerCase() === q);
  if (exact) return exact;
  const contains = CG_DISTRICTS.find(d =>
    d.toLowerCase().includes(q) || q.includes(d.toLowerCase())
  );
  return contains || name;
}

// ─── Smart contact payload builder ───────────────────────────────────────────

function buildContactPayload(data: Record<string, any>): Record<string, any> {
  // ── Step 1: Parse the name field for embedded info ──────────────────────────
  const rawName = (data.full_name || data.name || "").trim();
  const parsed = parseNameField(rawName, data);

  // ── Step 2: Mobile — multi-source cascade ──────────────────────────────────
  // Priority: explicit mobile fields > extracted from name > scanned from notes/raw text
  let mobile = normMobile(data.primary_mobile || data.mobile || data.phone || "");
  if (!mobile && parsed.mobileFound) mobile = parsed.mobileFound;
  if (!mobile) {
    // Last resort: scan notes and any other string field
    for (const k of ["notes", "occupation", "village_ward", "type"]) {
      const m = extractFirstMobile(String(data[k] || ""));
      if (m) { mobile = m; break; }
    }
  }
  if (!mobile) mobile = "0000000000"; // sentinel — indicates no mobile known

  const whatsapp = normMobile(data.whatsapp_mobile || data.whatsapp || "");

  // ── Step 3: Geography — use AI fields, fall back to name-parsed fields ─────
  const assemblyHint = data.assembly_name || data.assembly || data.constituency || data.vidhansabha || "";
  const aMatch = fuzzyAssembly(assemblyHint) || parsed.assembly || null;
  const constituency = aMatch?.name || (assemblyHint.trim() || null);
  const district = aMatch?.district || fuzzyDistrict(data.district || "") || parsed.district || null;
  const lokSabha = aMatch?.lok_sabha || null;

  // ── Step 4: Party / type — use AI fields, fall back to name-parsed fields ──
  const party = normParty(data.party || data.political_party || "") || parsed.party || "";
  const affiliation = (data.type || data.political_affiliation || parsed.type || "").trim();

  // ── Step 5: Supplementary notes ────────────────────────────────────────────
  const notesParts = [
    data.notes,
    data.occupation ? `Occupation: ${data.occupation}` : "",
    data.influence_score_hint ? `Influence: ${data.influence_score_hint}` : "",
    Array.isArray(data.tags) && data.tags.length ? `Tags: ${data.tags.join(", ")}` : "",
    // Unmapped CSV columns (from direct parse) preserved as additional context
    data.__extra ? `Additional info: ${data.__extra}` : "",
  ].filter(Boolean);

  // ── Build payload ───────────────────────────────────────────────────────────
  const payload: Record<string, any> = {
    name: parsed.cleanName || rawName || "Unknown",
    mobile,
    source: "ai_intake",
  };

  if (whatsapp && whatsapp !== mobile) payload.whatsapp_number = whatsapp;
  if (data.email?.trim()) payload.email = data.email.trim();
  const bday = data.date_of_birth || data.birthday || data.dob || "";
  if (bday) payload.birthday = bday;
  const gender = normGender(data.gender || "");
  if (gender) payload.gender = gender;
  if (district) payload.district = district;
  if (constituency) payload.constituency = constituency;
  if (lokSabha) payload.lok_sabha_constituency = lokSabha;
  const booth = String(data.booth_number || data.booth || "").trim();
  if (booth) payload.booth_number = booth;
  const village = (data.village_ward || data.village || data.ward || "").trim();
  if (village) payload.village_ward = village;
  if (party) payload.political_party = party;
  if (data.party_frontal?.trim()) payload.party_frontal = data.party_frontal.trim();
  if (data.party_department?.trim()) payload.party_department = data.party_department.trim();
  const caste = normCaste(data.caste_community || data.caste || "");
  if (caste) payload.caste = caste;
  const religion = normReligion(data.religion || "");
  if (religion) payload.religion = religion;
  if (data.leader_group?.trim()) payload.leader_group = data.leader_group.trim();
  if (data.second_leader?.trim()) payload.second_leader = data.second_leader.trim();
  if (data.non_political_org?.trim()) payload.non_political_org = data.non_political_org.trim();
  if (affiliation) payload.political_affiliation = affiliation;
  if (data.voter_id?.trim()) payload.voter_id = data.voter_id.trim();
  if (data.facebook?.trim()) payload.facebook = data.facebook.trim();
  if (data.instagram?.trim()) payload.instagram = data.instagram.trim();
  if (data.twitter?.trim()) payload.twitter = data.twitter.trim();
  if (Array.isArray(data.family_members) && data.family_members.length > 0) {
    payload.family_members = data.family_members.filter((m: any) => m?.name?.trim());
  }
  if (notesParts.length) payload.notes = notesParts.join(". ");

  return payload;
}

type Mode = "contact" | "issue" | "activity";
type InputTab = "single" | "bulk";

// ─── System prompts ─────────────────────────────────────────────────────────
const PROMPTS: Record<Mode, string> = {
  contact: `You are a structured data extraction engine for a political CRM in Chhattisgarh, India.
Extract contact information from the input text.
The input may be in Hindi, English, or mixed Hinglish.
The input may also be structured CSV-row data in the format "ColumnName: Value, ColumnName: Value, ..." — treat each ColumnName as a hint to what the value represents. Column headers may be in Hindi (e.g. "नाम" = name, "मोबाइल" = mobile, "बूथ" = booth, "जाति" = caste, "गांव" = village, "जिला" = district, "विधानसभा" = assembly, "पार्टी" = party).
Return ONLY valid JSON. No explanation. No markdown backticks.

JSON schema:
{"full_name":"","primary_mobile":"","whatsapp_mobile":"","email":"","gender":"","date_of_birth":"","voter_id":"","village_ward":"","booth_number":"","assembly_name":"","lok_sabha_constituency":"","district":"","type":"","party":"","party_frontal":"","party_department":"","political_affiliation":"","leader_group":"","second_leader":"","non_political_org":"","caste_community":"","religion":"","facebook":"","instagram":"","twitter":"","occupation":"","notes":"","family_members":[],"confidence":0}

Rules:
- Do not invent data. Leave unclear fields blank.
- full_name: ONLY the person's actual name — NO party names, NO designations, NO place names embedded in it.
  If the input has something like "Raju Netam BJP Raipur" — full_name = "Raju Netam", party = "bjp", district = "Raipur".
  If the input has "Sarpanch Meena Devi" — full_name = "Meena Devi", political_affiliation = "sarpanch".
  If the input has "Dr. Rahul Singh MLA" — full_name = "Dr. Rahul Singh", political_affiliation = "leader".
- primary_mobile: ANY 10-digit Indian mobile number found anywhere in the text (starting with 6, 7, 8, or 9). Output digits ONLY, no spaces/dashes/+91.
  If number appears as "98765 43210" or "9876-543210" or "+91 9876543210" — strip formatting, output "9876543210".
- gender: male / female / other
- date_of_birth: dd/mm/yyyy format
- voter_id: Voter ID / EPIC card number if mentioned (e.g. ABC1234567)
- assembly_name: Vidhan Sabha constituency name (Chhattisgarh) — check if any word/phrase in input matches a CG constituency
- lok_sabha_constituency: Lok Sabha constituency name if mentioned
- district: district name in Chhattisgarh — check if any word/phrase matches a CG district
- type: party_worker, leader, influencer, sarpanch, volunteer, youth_leader, women_leader, journalist, donor, community_leader, voter
  Detect from role/designation keywords: MLA/विधायक=leader, Sarpanch/सरपंच=sarpanch, Ward Member/पार्षद=community_leader,
  President/अध्यक्ष=leader, Youth/युवा=youth_leader, Mahila/महिला=women_leader, Worker/Karyakarta=party_worker
- party: bjp, inc, aap, bsp, jcc, independent, other — detect from text including variations like "भाजपा", "कांग्रेस", "Congress"
- party_frontal: frontal organization or wing of the party (e.g. Youth Congress, NSUI, Mahila Morcha, BJP Yuva Morcha)
- party_department: department or cell within the party (e.g. IT Cell, Legal Cell, Media Cell)
- political_affiliation: designation or role (e.g. Mandal President, Block Secretary, District Vice President)
- caste_community: general, obc, sc, st, or specific caste name
- religion: hindu, muslim, christian, sikh, other
- leader_group: name of the local leader or group this person belongs to
- second_leader: secondary leader association
- non_political_org: NGO, social org, cooperative, union, self-help group, etc.
- facebook / instagram / twitter: social media handles or URLs if mentioned
- family_members: array of family members if mentioned. Each item: {"name":"","relation":"","mobile":"","voter_id":""}
- confidence: 0–100 (how confident you are in the extraction)`,

  issue: `You are an issue extraction engine for a political CRM in Chhattisgarh, India.
Extract issue/complaint information from the input text.
The input may be in Hindi, English, or mixed Hinglish.
Return ONLY valid JSON. No explanation. No markdown backticks.

JSON schema:
{"title":"","description":"","category":"","subcategory":"","priority":"","reported_by":"","reporter_mobile":"","location_text":"","village_ward":"","booth_number":"","assembly":"","district":"","sentiment":"","due_date_suggestion":"","assigned_to":"","confidence":0}

Rules:
- category: water, roads, electricity, health, education, agriculture, employment, ration, pension, forest, law, other
- priority: low, medium, high, urgent
- sentiment: positive, negative, neutral
- confidence: 0–100`,

  activity: `You are a calendar event extraction engine for a political CRM in Chhattisgarh, India.
Extract event or activity information from the input text.
The input may be in Hindi, English, or mixed Hinglish.
Return ONLY valid JSON. No explanation. No markdown backticks.

JSON schema:
{"title":"","activity_type":"","date":"","start_time":"","end_time":"","location_name":"","assembly_name":"","district":"","booth_number":"","linked_issue":"","expected_attendance":"","participants":[],"reminder_required":true,"notes":"","confidence":0}

Rules:
- activity_type: rally, padyatra, meeting, booth_visit, d2d, sampark, review_call, issue_followup, birthday_visit, other
- date: yyyy-mm-dd
- time: HH:MM 24h
- confidence: 0–100`,
};

const EXAMPLES: { mode: Mode; text: string; label: string }[] = [
  { mode: "contact", label: "Contact", text: "Raju Netam booth 44, village Jamgaon, mob 9876543210, youth congress, born 12 june, good local influence" },
  { mode: "issue",   label: "Issue",   text: "Road broken in ward 7 near school, people very angry, complaint raised by Meena didi, urgent fix needed before rains start, booth 23" },
  { mode: "activity",label: "Activity",text: "Kal ward 12 me paani ki bahut problem hai. Sita didi ne bataya. Booth 56. Shaam ko 5 baje meeting rakhni hai sector 3 office mein." },
];

const CONTACT_FIELDS = [
  // Personal
  { key: "full_name",             label: "Full Name",                  required: true },
  { key: "primary_mobile",        label: "Mobile Number",              required: true },
  { key: "whatsapp_mobile",       label: "WhatsApp Number" },
  { key: "email",                 label: "Email" },
  { key: "date_of_birth",         label: "Birthday (dd/mm/yyyy)" },
  { key: "gender",                label: "Gender" },
  { key: "voter_id",              label: "Voter ID (EPIC)" },
  // Location
  { key: "village_ward",          label: "Village / Ward" },
  { key: "booth_number",          label: "Booth Number" },
  { key: "district",              label: "District" },
  { key: "assembly_name",         label: "Assembly Constituency" },
  { key: "lok_sabha_constituency",label: "Lok Sabha Constituency" },
  // Political
  { key: "party",                 label: "Political Party" },
  { key: "party_frontal",         label: "Frontal Organisation / Wing" },
  { key: "party_department",      label: "Department / Cell" },
  { key: "political_affiliation", label: "Designation / Role" },
  { key: "leader_group",          label: "Leader Group" },
  { key: "second_leader",         label: "Second Leader / Group" },
  { key: "non_political_org",     label: "Non-Political Organisation" },
  // Social
  { key: "caste_community",       label: "Caste" },
  { key: "religion",              label: "Religion" },
  // Online
  { key: "facebook",              label: "Facebook" },
  { key: "instagram",             label: "Instagram" },
  { key: "twitter",               label: "Twitter / X" },
  // Notes
  { key: "notes",                 label: "Notes" },
];

const CONTACT_FIELD_GROUPS = [
  { id: "personal",  label: "Personal",  icon: "user",   fields: ["full_name","primary_mobile","whatsapp_mobile","email","date_of_birth","gender","voter_id"] },
  { id: "location",  label: "Location",  icon: "map",    fields: ["village_ward","booth_number","district","assembly_name","lok_sabha_constituency"] },
  { id: "political", label: "Political", icon: "flag",   fields: ["party","party_frontal","party_department","political_affiliation","leader_group","second_leader","non_political_org"] },
  { id: "social",    label: "Social",    icon: "users",  fields: ["caste_community","religion"] },
  { id: "online",    label: "Online",    icon: "share",  fields: ["facebook","instagram","twitter"] },
  { id: "notes",     label: "Notes",     icon: "text",   fields: ["notes"] },
];
const ISSUE_FIELDS = [
  { key: "title", label: "Title" }, { key: "description", label: "Description" },
  { key: "category", label: "Category" }, { key: "subcategory", label: "Sub-category" },
  { key: "priority", label: "Priority" }, { key: "reported_by", label: "Reported By" },
  { key: "reporter_mobile", label: "Reporter Mobile" }, { key: "location_text", label: "Location" },
  { key: "village_ward", label: "Village/Ward" }, { key: "booth_number", label: "Booth No." },
  { key: "assembly", label: "Assembly" }, { key: "district", label: "District" },
  { key: "sentiment", label: "Sentiment" }, { key: "due_date_suggestion", label: "Due Date" },
  { key: "assigned_to", label: "Assign To" },
];
const ACTIVITY_FIELDS = [
  { key: "title", label: "Title" }, { key: "activity_type", label: "Activity Type" },
  { key: "date", label: "Date" }, { key: "start_time", label: "Start Time" },
  { key: "end_time", label: "End Time" }, { key: "location_name", label: "Location" },
  { key: "assembly_name", label: "Assembly" }, { key: "district", label: "District" },
  { key: "booth_number", label: "Booth No." }, { key: "linked_issue", label: "Linked Issue" },
  { key: "expected_attendance", label: "Expected Attendance" }, { key: "notes", label: "Notes" },
];
const FIELD_SETS: Record<Mode, { key: string; label: string }[]> = {
  contact: CONTACT_FIELDS, issue: ISSUE_FIELDS, activity: ACTIVITY_FIELDS,
};

function fallbackExtract(text: string, mode: Mode): Record<string, any> {
  const mobileMatch = text.match(/[6-9]\d{9}/);
  const boothMatch  = text.match(/booth\s*(?:no\.?\s*)?(\d+)/i);
  const villageMatch = text.match(/village\s+(\w+)|gram\s+(\w+)|ward\s+(\w+)/i);
  const nameMatch   = text.match(/^([A-Za-z\u0900-\u097F]+(?:\s+[A-Za-z\u0900-\u097F]+){0,2})/);
  if (mode === "contact") return { full_name: nameMatch?.[0]?.trim() ?? "", primary_mobile: mobileMatch?.[0] ?? "", booth_number: boothMatch?.[1] ?? "", village_ward: villageMatch?.[1] ?? villageMatch?.[2] ?? villageMatch?.[3] ?? "", notes: text, confidence: 25 };
  if (mode === "issue")   return { title: text.slice(0, 60), description: text, booth_number: boothMatch?.[1] ?? "", priority: "medium", confidence: 25 };
  return { title: text.slice(0, 60), activity_type: "meeting", notes: text, confidence: 25 };
}

const modeIcon = (m: Mode) => m === "contact" ? <User className="h-4 w-4" /> : m === "issue" ? <AlertTriangle className="h-4 w-4" /> : <CalIcon className="h-4 w-4" />;

interface HistoryItem { id: string; mode: Mode; summary: string; confidence: number; saved: boolean; timestamp: Date; }

// ─── Bulk queue item ─────────────────────────────────────────────────────────
type BulkStatus = "pending" | "extracting" | "done" | "error" | "saved" | "skipped";
interface BulkItem {
  id: string;
  raw: string;
  status: BulkStatus;
  extracted?: Record<string, any>;
  edits?: Record<string, any>;
  error?: string;
  usedFallback?: boolean;
}

// ─── API helpers ─────────────────────────────────────────────────────────────
async function callExtract(text: string, mode: Mode): Promise<{ data: Record<string, any>; fallback: boolean }> {
  try {
    const r = await fetch(`${BASE}/api/ai-intake`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ system_prompt: PROMPTS[mode], user_input: text }),
    });
    const j = await r.json();
    if (j.success) return { data: j.data, fallback: false };
    return { data: fallbackExtract(text, mode), fallback: true };
  } catch {
    return { data: fallbackExtract(text, mode), fallback: true };
  }
}

async function saveRecord(mode: Mode, data: Record<string, any>, _existingContacts: any[]): Promise<{ ok: boolean; error?: string }> {
  if (mode === "contact") {
    const payload = buildContactPayload(data);
    const r = await fetch(`${BASE}/api/contacts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    return j.success ? { ok: true } : { ok: false, error: j.error };
  }

  if (mode === "issue") {
    const aMatch = fuzzyAssembly(data.assembly || data.assembly_name || "");
    const r = await fetch(`${BASE}/api/issues`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        issue_title: data.title || "Untitled Issue",
        issue_description: data.description || null,
        issue_status: "new",
        issue_priority: data.priority || "medium",
        contact_name: data.reported_by || null,
        district: aMatch?.district || fuzzyDistrict(data.district || "") || null,
        constituency: aMatch?.name || data.assembly || data.assembly_name || null,
        village_ward: data.village_ward || null,
        booth_number: String(data.booth_number || "").trim() || null,
        sentiment: data.sentiment || null,
        source: "ai_intake",
      }),
    });
    const j = await r.json();
    return j.success ? { ok: true } : { ok: false, error: j.error };
  }

  // activity
  const aMatch = fuzzyAssembly(data.assembly_name || "");
  const r = await fetch(`${BASE}/api/events`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      title: data.title || "Untitled Event",
      activity_type: data.activity_type || "meeting",
      event_date: data.date || format(new Date(), "yyyy-MM-dd"),
      start_time: data.start_time || null,
      end_time: data.end_time || null,
      location: data.location_name || null,
      district: aMatch?.district || fuzzyDistrict(data.district || "") || null,
      constituency: aMatch?.name || data.assembly_name || null,
      booth_number: String(data.booth_number || "").trim() || null,
      expected_attendance: data.expected_attendance ? Number(data.expected_attendance) : null,
      linked_issue: data.linked_issue || null,
      notes: data.notes || null,
      source: "ai_intake",
    }),
  });
  const j = await r.json();
  return j.success ? { ok: true } : { ok: false, error: j.error };
}

// ─── CSV export helper ────────────────────────────────────────────────────────
function exportToCSV(rows: Record<string, any>[], fields: { key: string; label: string }[], filename: string) {
  if (!rows.length) return;
  const headers = ["#", "Status", ...fields.map(f => f.label)];
  const csvRows = rows.map((row, i) => [
    String(i + 1),
    row.__status ?? "",
    ...fields.map(f => {
      const v = row[f.key];
      const str = Array.isArray(v) ? v.join("; ") : String(v ?? "");
      return `"${str.replace(/"/g, '""')}"`;
    }),
  ].join(","));
  const csv = "\uFEFF" + [headers.join(","), ...csvRows].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ─── Split text into chunks ───────────────────────────────────────────────────
function splitChunks(text: string, delimiter: string): string[] {
  let parts: string[];
  if (delimiter === "blank_line") {
    parts = text.split(/\n\s*\n/);
  } else if (delimiter === "dashes") {
    parts = text.split(/\n?---+\n?/);
  } else if (delimiter === "newline") {
    parts = text.split(/\n/);
  } else if (delimiter === "semicolon") {
    parts = text.split(/;/);
  } else {
    parts = text.split(/\n\s*\n/);
  }
  return parts.map(p => p.trim()).filter(p => p.length > 5);
}

// ─── Column alias map (English + Hindi/Hinglish) ─────────────────────────────
const CSV_COLUMN_MAP: Record<string, string> = {
  // ── Name ──
  name: "full_name", "full name": "full_name", fullname: "full_name", "full_name": "full_name",
  "first name": "full_name", firstname: "full_name", "contact name": "full_name",
  "person name": "full_name", "candidate name": "full_name", "member name": "full_name",
  "voter name": "full_name", "नाम": "full_name", "पूरा नाम": "full_name", naam: "full_name",
  "applicant name": "full_name", "contact person": "full_name",
  // ── Mobile ──
  mobile: "primary_mobile", "mobile number": "primary_mobile", phone: "primary_mobile",
  "phone number": "primary_mobile", "primary mobile": "primary_mobile", "mob no": "primary_mobile",
  mob: "primary_mobile", "contact number": "primary_mobile", number: "primary_mobile",
  "mobile no": "primary_mobile", "ph no": "primary_mobile", "ph": "primary_mobile",
  "cell": "primary_mobile", "cell number": "primary_mobile", "contact no": "primary_mobile",
  "मोबाइल": "primary_mobile", "मोबाईल": "primary_mobile", "मोबाइल नंबर": "primary_mobile",
  "मोबाईल नंबर": "primary_mobile", "फोन": "primary_mobile", "फ़ोन": "primary_mobile",
  "फोन नंबर": "primary_mobile", "संपर्क नंबर": "primary_mobile", "नंबर": "primary_mobile",
  "mobile 1": "primary_mobile", "mobile1": "primary_mobile", "primary phone": "primary_mobile",
  // ── WhatsApp ──
  whatsapp: "whatsapp_mobile", "whatsapp number": "whatsapp_mobile", wp: "whatsapp_mobile",
  "whatsapp no": "whatsapp_mobile", "व्हाट्सएप": "whatsapp_mobile", "whatsapp mobile": "whatsapp_mobile",
  // ── Email ──
  email: "email", "email address": "email", "email id": "email", "ईमेल": "email",
  // ── Gender ──
  gender: "gender", sex: "gender", "लिंग": "gender",
  // ── DOB ──
  dob: "date_of_birth", birthday: "date_of_birth", "date of birth": "date_of_birth",
  "birth date": "date_of_birth", "date_of_birth": "date_of_birth", "जन्म तिथि": "date_of_birth",
  // ── Age ──
  age: "age", "उम्र": "age", "आयु": "age",
  // ── Village/Ward ──
  village: "village_ward", ward: "village_ward", "village/ward": "village_ward",
  "village ward": "village_ward", gram: "village_ward", mohalla: "village_ward",
  "गांव": "village_ward", "ग्राम": "village_ward", "गाँव": "village_ward",
  "मोहल्ला": "village_ward", "पता": "village_ward", "address": "village_ward",
  "टोला": "village_ward", "para": "village_ward", "पारा": "village_ward",
  // ── Booth ──
  booth: "booth_number", "booth no": "booth_number", "booth number": "booth_number",
  "booth_number": "booth_number", "booth no.": "booth_number", "booth#": "booth_number",
  "बूथ": "booth_number", "बूथ नंबर": "booth_number", "booth num": "booth_number",
  "polling booth": "booth_number",
  // ── Voter ID ──
  "voter id": "voter_id", "voter id no": "voter_id", "voter card": "voter_id",
  "epic": "voter_id", "epic no": "voter_id", "voter_id": "voter_id",
  "मतदाता पहचान पत्र": "voter_id", "मतदाता आईडी": "voter_id",
  // ── Assembly ──
  assembly: "assembly_name", constituency: "assembly_name", vidhansabha: "assembly_name",
  "assembly name": "assembly_name", "assembly_name": "assembly_name",
  "vidhan sabha": "assembly_name", "ac name": "assembly_name", ac: "assembly_name",
  "विधानसभा": "assembly_name", "विधान सभा": "assembly_name", "क्षेत्र": "assembly_name",
  "segment": "assembly_name", "ac no": "assembly_name",
  // ── District ──
  district: "district", "district name": "district", zila: "district", jila: "district",
  "जिला": "district", "ज़िला": "district", "जिला नाम": "district",
  // ── Party ──
  party: "party", "political party": "party", "party name": "party",
  "पार्टी": "party", "दल": "party",
  // ── Caste ──
  caste: "caste_community", "caste/community": "caste_community", "caste community": "caste_community",
  community: "caste_community", "caste_community": "caste_community",
  "जाति": "caste_community", "समुदाय": "caste_community", "varg": "caste_community",
  "वर्ग": "caste_community", "जाती": "caste_community",
  // ── Religion ──
  religion: "religion", dharma: "religion", "धर्म": "religion",
  // ── Type / Designation ──
  type: "type", "contact type": "type", role: "type", designation: "type",
  "political affiliation": "type", affiliation: "type", "पद": "type",
  "पदनाम": "type", "designation/role": "type",
  // ── Occupation ──
  occupation: "occupation", job: "occupation", profession: "occupation",
  "व्यवसाय": "occupation", "कार्य": "occupation",
  // ── Leader group ──
  "leader group": "leader_group", "leader_group": "leader_group", prabhari: "leader_group",
  "area leader": "leader_group", "प्रभारी": "leader_group", "नेता": "leader_group",
  // ── Second leader ──
  "second leader": "second_leader", "second_leader": "second_leader",
  // ── Non-political org ──
  ngo: "non_political_org", organisation: "non_political_org", organization: "non_political_org",
  "non political org": "non_political_org", "non_political_org": "non_political_org",
  "संगठन": "non_political_org",
  // ── Notes ──
  notes: "notes", remarks: "notes", comments: "notes", "टिप्पणी": "notes",
  "नोट्स": "notes", "विवरण": "notes", "remark": "notes",
};

// Columns to skip (sequence numbers, row IDs, etc.)
const SKIP_COLUMNS = new Set([
  "s.no", "sno", "sl no", "sl.no", "sr no", "sr.no", "serial", "serial no",
  "#", "no", "क्र.सं", "क्र सं", "क्रमांक", "क्र.", "id", "row", "index",
]);

function normHeader(raw: string): string {
  return raw.toLowerCase().trim().replace(/[_\-]/g, " ").replace(/[\*\.]/g, "").replace(/\s+/g, " ");
}

/** Detect delimiter by counting occurrences in first line */
function detectCsvDelimiter(csv: string): string {
  const firstLine = csv.split(/\r?\n/)[0] ?? "";
  const counts: Record<string, number> = {
    "\t": (firstLine.match(/\t/g) ?? []).length,
    ";": (firstLine.match(/;/g) ?? []).length,
    "|": (firstLine.match(/\|/g) ?? []).length,
    ",": (firstLine.match(/,/g) ?? []).length,
  };
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}

/** Proper CSV line parser — handles quoted fields with embedded delimiters/newlines */
function parseCsvLine(line: string, delim: string): string[] {
  const cells: string[] = [];
  let cur = "", inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQ && line[i + 1] === '"') { cur += '"'; i++; } // escaped quote
      else inQ = !inQ;
    } else if (ch === delim && !inQ) {
      cells.push(cur.trim());
      cur = "";
    } else {
      cur += ch;
    }
  }
  cells.push(cur.trim());
  return cells;
}

/**
 * Try direct structured parse.
 * Returns records if ≥1 recognised column found; unmapped columns kept as raw text in notes.
 */
function tryDirectCsvParse(csv: string): Record<string, any>[] | null {
  const lines = csv.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return null;

  const delim = detectCsvDelimiter(csv);
  const rawHeaders = parseCsvLine(lines[0], delim);
  const mappedHeaders = rawHeaders.map(h => {
    const norm = normHeader(h);
    if (SKIP_COLUMNS.has(norm)) return "__skip__";
    return CSV_COLUMN_MAP[norm] || `__raw__:${h.trim()}`;
  });

  const recognized = mappedHeaders.filter(h => h && !h.startsWith("__")).length;
  if (recognized < 1) return null; // nothing recognized — let AI handle it

  return lines.slice(1)
    .map(line => {
      const vals = parseCsvLine(line, delim);
      if (vals.every(v => !v)) return null;
      const rec: Record<string, any> = {};
      const rawParts: string[] = [];
      mappedHeaders.forEach((mapped, i) => {
        const val = vals[i]?.trim();
        if (!val || mapped === "__skip__") return;
        if (mapped && !mapped.startsWith("__raw__")) {
          rec[mapped] = val;
        } else if (mapped.startsWith("__raw__")) {
          rawParts.push(`${mapped.slice(7)}: ${val}`);
        }
      });
      // Attach unmapped columns as extra notes for AI to optionally use
      if (rawParts.length > 0) rec.__extra = rawParts.join(", ");
      return Object.keys(rec).length ? rec : null;
    })
    .filter(Boolean) as Record<string, any>[];
}

/**
 * Convert CSV to natural-language text chunks for AI extraction.
 * Each row → "ColA: ValA, ColB: ValB, ..." so AI can extract any field.
 */
function parseCsvToChunks(csv: string): string[] {
  const lines = csv.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return lines.filter(l => l.trim().length > 5);

  const delim = detectCsvDelimiter(csv);
  const headers = parseCsvLine(lines[0], delim).map(h => h.trim());

  return lines.slice(1)
    .map(line => {
      const vals = parseCsvLine(line, delim);
      const parts: string[] = [];
      headers.forEach((h, i) => {
        const val = vals[i]?.trim();
        const norm = normHeader(h);
        if (!val || SKIP_COLUMNS.has(norm)) return;
        parts.push(`${h}: ${val}`);
      });
      return parts.join(", ");
    })
    .filter(r => r.length > 5);
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function AiIntake() {
  // Shared
  const [mode, setMode] = useState<Mode>("contact");
  const [inputTab, setInputTab] = useState<InputTab>("single");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const { toast } = useToast();
  const { data: contactsData } = useGetContacts({});
  const allContacts = contactsData?.data ?? [];

  // Single mode
  const [inputText, setInputText] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [extracted, setExtracted] = useState<Record<string, any> | null>(null);
  const [editedFields, setEditedFields] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [usedFallback, setUsedFallback] = useState(false);

  // Bulk mode
  const [bulkText, setBulkText] = useState("");
  const [delimiter, setDelimiter] = useState("blank_line");
  const [bulkQueue, setBulkQueue] = useState<BulkItem[]>([]);
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkPaused, setBulkPaused] = useState(false);
  const [bulkSaving, setBulkSaving] = useState(false);
  const [bulkSaveCount, setBulkSaveCount] = useState(0);
  const [bulkExpanded, setBulkExpanded] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pauseRef = useRef(false);
  const stopSaveRef = useRef(false);

  const addHistory = useCallback((data: Record<string, any>, m: Mode, input: string, saved: boolean) => {
    const summary = data.full_name || data.title || data.primary_mobile || input.slice(0, 40);
    setHistory(h => [
      { id: Math.random().toString(36).slice(2), mode: m, summary, confidence: data.confidence ?? 0, saved, timestamp: new Date() },
      ...h.slice(0, 14),
    ]);
  }, []);

  // ── Single extract ──────────────────────────────────────────────────────────
  const handleExtract = async () => {
    if (!inputText.trim()) return;
    setExtracting(true); setExtracted(null); setEditedFields({}); setUsedFallback(false);
    const { data, fallback } = await callExtract(inputText, mode);
    setExtracted(data); setUsedFallback(fallback);
    if (fallback) toast({ title: "AI unavailable — using basic extraction", description: "AI service is temporarily unavailable. Basic extraction applied.", variant: "destructive" });
    setExtracting(false);
  };

  const handleSave = async () => {
    if (!extracted) return;
    const merged = { ...extracted, ...editedFields };
    setSaving(true);
    const result = await saveRecord(mode, merged, allContacts);
    if (result.ok) {
      toast({ title: mode === "contact" ? "Contact saved" : mode === "issue" ? "Issue saved" : "Event saved" });
      addHistory(merged, mode, inputText, true);
      setExtracted(null); setInputText("");
    } else {
      toast({ title: "Error saving", description: result.error, variant: "destructive" });
    }
    setSaving(false);
  };

  const fieldValue = (key: string) => {
    if (key in editedFields) return editedFields[key];
    if (extracted && key in extracted) return extracted[key];
    return "";
  };

  // ── File upload ─────────────────────────────────────────────────────────────
  const readFile = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = e => {
      const content = e.target?.result as string ?? "";
      if (file.name.toLowerCase().endsWith(".csv")) {
        // Try smart direct parse first — structured CSV with recognisable columns
        const direct = mode === "contact" ? tryDirectCsvParse(content) : null;
        if (direct && direct.length > 0) {
          const items: BulkItem[] = direct.map(rec => ({
            id: Math.random().toString(36).slice(2),
            raw: Object.entries(rec).map(([k, v]) => `${k}: ${v}`).join(", "),
            status: "done" as BulkStatus,
            extracted: rec,
            usedFallback: false,
          }));
          setBulkQueue(items);
          setBulkExpanded(null);
          setBulkText("");
          toast({ title: `${items.length} records loaded from CSV`, description: "Columns auto-matched. Review and save." });
          return;
        }
        // Unstructured CSV — convert rows to text chunks and auto-trigger AI extraction
        const chunks = parseCsvToChunks(content);
        if (chunks.length === 0) {
          toast({ title: "Could not parse CSV", description: "No usable rows found. Try pasting text manually.", variant: "destructive" });
          return;
        }
        toast({ title: `${chunks.length} rows found — starting AI extraction…` });
        const items = chunks.map(raw => ({ id: Math.random().toString(36).slice(2), raw, status: "pending" as BulkStatus }));
        startBulkExtractionFrom(items);
      } else {
        // TXT / other text file — auto-detect split heuristic and trigger AI extraction
        const heuristic: string = content.includes("\n\n") ? "blank_line" : "newline";
        const chunks = splitChunks(content, heuristic);
        if (chunks.length === 0) {
          toast({ title: "No records found in file", description: "Try a different file or paste text manually.", variant: "destructive" });
          return;
        }
        toast({ title: `${chunks.length} records found — starting AI extraction…` });
        const items = chunks.map(raw => ({ id: Math.random().toString(36).slice(2), raw, status: "pending" as BulkStatus }));
        startBulkExtractionFrom(items);
      }
    };
    reader.readAsText(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) readFile(file);
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) readFile(file);
  };

  // ── Bulk split & preview ────────────────────────────────────────────────────
  const previewChunks = bulkText ? splitChunks(bulkText, delimiter) : [];

  const initQueue = () => {
    const chunks = splitChunks(bulkText, delimiter);
    if (chunks.length === 0) { toast({ title: "No records found. Adjust delimiter.", variant: "destructive" }); return; }
    setBulkQueue(chunks.map(raw => ({ id: Math.random().toString(36).slice(2), raw, status: "pending" as BulkStatus })));
    setBulkExpanded(null);
  };

  // ── Core extraction engine: accepts items directly, sets queue and runs AI ──
  const startBulkExtractionFrom = async (items: BulkItem[]) => {
    if (items.length === 0) {
      toast({ title: "No records found in file", description: "Try a different file or paste text manually.", variant: "destructive" });
      return;
    }
    setBulkQueue(items);
    setBulkExpanded(null);
    setBulkText("");
    setFileName(prev => prev); // keep file name shown
    setBulkRunning(true); setBulkPaused(false); pauseRef.current = false;
    for (const item of items) {
      while (pauseRef.current) { await new Promise(r => setTimeout(r, 300)); }
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "extracting" } : it));
      const { data, fallback } = await callExtract(item.raw, mode);
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "done", extracted: data, usedFallback: fallback } : it));
    }
    setBulkRunning(false);
  };

  // ── Bulk run ────────────────────────────────────────────────────────────────
  const runBulk = async () => {
    if (bulkQueue.length === 0) {
      const chunks = splitChunks(bulkText, delimiter);
      const items = chunks.map(raw => ({ id: Math.random().toString(36).slice(2), raw, status: "pending" as BulkStatus }));
      await startBulkExtractionFrom(items);
      return;
    }
    setBulkRunning(true); setBulkPaused(false); pauseRef.current = false;
    for (let i = 0; i < bulkQueue.length; i++) {
      while (pauseRef.current) { await new Promise(r => setTimeout(r, 300)); }
      const item = bulkQueue[i];
      if (item.status === "saved" || item.status === "skipped" || item.status === "done") continue;
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "extracting" } : it));
      const { data, fallback } = await callExtract(item.raw, mode);
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "done", extracted: data, usedFallback: fallback } : it));
    }
    setBulkRunning(false);
  };

  const pauseBulk = () => { pauseRef.current = true; setBulkPaused(true); };
  const resumeBulk = () => { pauseRef.current = false; setBulkPaused(false); runBulk(); };

  const saveBulkItem = async (item: BulkItem) => {
    if (!item.extracted) return;
    const merged = { ...item.extracted, ...(item.edits ?? {}) };
    setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "extracting" } : it));
    const res = await saveRecord(mode, merged, allContacts);
    if (res.ok) {
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "saved" } : it));
      addHistory(merged, mode, item.raw, true);
      toast({ title: "Saved" });
    } else {
      setBulkQueue(q => q.map(it => it.id === item.id ? { ...it, status: "done", error: res.error } : it));
      toast({ title: "Error", description: res.error, variant: "destructive" });
    }
  };

  const updateBulkItemField = (id: string, key: string, value: any) =>
    setBulkQueue(q => q.map(it => it.id === id ? { ...it, edits: { ...(it.edits ?? {}), [key]: value } } : it));

  const skipBulkItem = (id: string) =>
    setBulkQueue(q => q.map(it => it.id === id ? { ...it, status: "skipped" } : it));

  const stopSave = () => {
    stopSaveRef.current = true;
    setBulkSaving(false);
  };

  const runBulkSave = async (eligible: BulkItem[], label: string) => {
    if (eligible.length === 0) { toast({ title: `No ${label} records to save` }); return; }
    stopSaveRef.current = false;
    setBulkSaving(true);
    setBulkSaveCount(0);
    let saved = 0;
    for (const item of eligible) {
      if (stopSaveRef.current) break;
      await saveBulkItem(item);
      saved++;
      setBulkSaveCount(saved);
    }
    setBulkSaving(false);
    if (stopSaveRef.current) {
      toast({ title: `Stopped — saved ${saved} of ${eligible.length} record${eligible.length !== 1 ? "s" : ""}` });
    } else {
      toast({ title: `Saved ${saved} ${label} record${saved !== 1 ? "s" : ""}` });
    }
  };

  const saveAllHighConfidence = () => {
    const eligible = bulkQueue.filter(it => it.status === "done" && it.extracted && (it.extracted.confidence ?? 0) >= 60);
    return runBulkSave(eligible, "high-confidence (≥60%)");
  };

  const saveAllExtracted = () => {
    const eligible = bulkQueue.filter(it => it.status === "done" && it.extracted);
    return runBulkSave(eligible, "extracted");
  };

  const bulkStats = {
    total: bulkQueue.length,
    done: bulkQueue.filter(i => i.status === "done").length,
    saved: bulkQueue.filter(i => i.status === "saved").length,
    skipped: bulkQueue.filter(i => i.status === "skipped").length,
    extracting: bulkQueue.filter(i => i.status === "extracting").length,
  };

  const confidence = extracted ? (extracted.confidence ?? 0) : 0;
  const confColor = confidence >= 70 ? "bg-green-100 text-green-700 border-green-200" : confidence >= 40 ? "bg-yellow-100 text-yellow-700 border-yellow-200" : "bg-red-100 text-red-700 border-red-200";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold font-serif tracking-tight">AI Intake Engine</h2>
        <p className="text-muted-foreground text-sm mt-1">Extract structured data from messy Hindi, English, or Hinglish text.</p>
      </div>

      {/* ── Top controls: Mode + Tab ──────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Mode */}
        <Card className="shadow-sm flex-1">
          <CardContent className="pt-3 pb-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Extraction Mode</p>
            <div className="flex gap-2">
              {(["contact","issue","activity"] as Mode[]).map(m => (
                <button key={m} onClick={() => { setMode(m); setExtracted(null); setEditedFields({}); setBulkQueue([]); }}
                  className={cn("flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold border transition-all capitalize",
                    mode === m ? "bg-primary text-primary-foreground border-primary shadow-sm" : "bg-background border-border text-muted-foreground hover:border-primary/40 hover:text-foreground")}>
                  {modeIcon(m)} {m}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
        {/* Input tab */}
        <Card className="shadow-sm">
          <CardContent className="pt-3 pb-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Import Mode</p>
            <div className="flex gap-2">
              {([["single","Single Entry"],["bulk","Bulk Import"]] as [InputTab, string][]).map(([t, lbl]) => (
                <button key={t} onClick={() => setInputTab(t)}
                  className={cn("flex items-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold border transition-all whitespace-nowrap",
                    inputTab === t ? "bg-primary text-primary-foreground border-primary shadow-sm" : "bg-background border-border text-muted-foreground hover:border-primary/40 hover:text-foreground")}>
                  {t === "single" ? <Sparkles className="h-3.5 w-3.5" /> : <Layers className="h-3.5 w-3.5" />} {lbl}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  SINGLE MODE                                                          */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {inputTab === "single" && (
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
          {/* Left */}
          <div className="xl:col-span-2 space-y-4">
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-serif">Input Text</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <textarea rows={8} value={inputText} onChange={e => setInputText(e.target.value)}
                  placeholder={mode === "contact" ? 'e.g. "Raju Netam booth 44, mob 9876543210, youth congress"' : mode === "issue" ? 'e.g. "Road broken in ward 7, urgent fix needed before rains"' : 'e.g. "Kal 5 baje meeting sector 3 office, water issue review"'}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
                <Button onClick={handleExtract} disabled={!inputText.trim() || extracting} className="w-full font-semibold">
                  {extracting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Extracting…</> : <><Sparkles className="h-4 w-4 mr-2" />Extract with AI</>}
                </Button>
              </CardContent>
            </Card>

            {/* Example cards */}
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Example Prompts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {EXAMPLES.map(ex => (
                  <button key={ex.label} onClick={() => { setMode(ex.mode); setInputText(ex.text); }}
                    className="w-full text-left p-3 rounded-lg border border-border hover:bg-secondary/50 hover:border-primary/30 transition-all">
                    <p className="text-[10px] font-semibold text-primary uppercase tracking-wider mb-1">{ex.label}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{ex.text}</p>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* History */}
            {history.length > 0 && (
              <Card className="shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <History className="h-3.5 w-3.5" /> Recent Extractions
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-border/40 max-h-48 overflow-y-auto">
                    {history.map(h => (
                      <div key={h.id} className="px-4 py-2.5 flex items-center gap-2 hover:bg-secondary/30">
                        <span className="text-muted-foreground">{modeIcon(h.mode)}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-foreground truncate">{h.summary}</p>
                          <p className="text-[10px] text-muted-foreground">{format(h.timestamp, "h:mm a")}</p>
                        </div>
                        <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded", h.confidence >= 70 ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700")}>
                          {h.confidence}%
                        </span>
                        {h.saved ? <CheckCircle className="h-3.5 w-3.5 text-green-500 shrink-0" /> : <Clock className="h-3.5 w-3.5 text-muted-foreground shrink-0" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right — result */}
          <div className="xl:col-span-3">
            {!extracted ? (
              <Card className="shadow-sm h-full">
                <CardContent className="flex flex-col items-center justify-center h-72 text-center">
                  <Brain className="h-16 w-16 text-muted-foreground/20 mb-4" />
                  <p className="text-base font-medium text-foreground">Ready to Extract</p>
                  <p className="text-sm text-muted-foreground mt-1 max-w-xs">Paste any text on the left and click Extract.</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-sm">
                <CardHeader className="border-b border-border/50 pb-3">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <CardTitle className="font-serif text-base flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" /> Extracted Data
                      <span className="text-xs font-normal text-muted-foreground capitalize">({mode})</span>
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {usedFallback && <span className="flex items-center gap-1 text-[10px] bg-orange-100 text-orange-700 border border-orange-200 px-2 py-1 rounded-full"><AlertCircle className="h-3 w-3" /> Fallback</span>}
                      <span className={cn("text-xs font-semibold px-3 py-1 rounded-full border", confColor)}>{confidence}% confidence</span>
                    </div>
                  </div>
                  <CardDescription>Review and edit fields before saving.</CardDescription>
                </CardHeader>
                <CardContent className="pt-4 max-h-[60vh] overflow-y-auto pr-1">
                  {mode === "contact" ? (
                    <div className="space-y-5 mb-4">
                      {/* ── Grouped sections ── */}
                      {CONTACT_FIELD_GROUPS.map(group => {
                        const groupIcon = group.icon === "user" ? <User className="h-3.5 w-3.5" /> : group.icon === "map" ? <MapPin className="h-3.5 w-3.5" /> : group.icon === "flag" ? <Flag className="h-3.5 w-3.5" /> : group.icon === "users" ? <Users className="h-3.5 w-3.5" /> : group.icon === "share" ? <Share2 className="h-3.5 w-3.5" /> : <FileText className="h-3.5 w-3.5" />;
                        const fieldDefs = CONTACT_FIELDS.filter(f => group.fields.includes(f.key));
                        return (
                          <div key={group.id} className="rounded-xl border border-border bg-secondary/10 overflow-hidden">
                            <div className="flex items-center gap-1.5 px-3 py-2 bg-secondary/30 border-b border-border/50">
                              {groupIcon}
                              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{group.label}</p>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3">
                              {fieldDefs.map(({ key, label, required }) => {
                                const val = fieldValue(key) ?? "";
                                const isNotes = key === "notes";
                                return (
                                  <div key={key} className={cn("space-y-1", isNotes ? "sm:col-span-2" : "")}>
                                    <Label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                                      {label}{required && <span className="text-destructive ml-0.5">*</span>}
                                    </Label>
                                    {isNotes ? (
                                      <textarea rows={2} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" value={val} onChange={e => setEditedFields(f => ({ ...f, [key]: e.target.value }))} />
                                    ) : (
                                      <Input value={val} placeholder={required ? `Enter ${label.toLowerCase()}` : "—"} onChange={e => setEditedFields(f => ({ ...f, [key]: e.target.value }))} className={cn("h-8 text-sm", val ? "bg-primary/5 border-primary/20" : "")} />
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}

                      {/* ── Family Members ── */}
                      <div className="rounded-xl border border-border bg-secondary/10 overflow-hidden">
                        <div className="flex items-center gap-1.5 px-3 py-2 bg-secondary/30 border-b border-border/50">
                          <Heart className="h-3.5 w-3.5 text-rose-500" />
                          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Family Members</p>
                        </div>
                        <div className="p-3 space-y-3">
                          {(() => {
                            const members: any[] = Array.isArray(fieldValue("family_members")) ? fieldValue("family_members") : [];
                            return (
                              <>
                                {members.map((member: any, idx: number) => (
                                  <div key={idx} className="rounded-lg border border-border bg-card p-3 space-y-2 relative">
                                    <button type="button" className="absolute top-2 right-2 text-muted-foreground hover:text-destructive transition-colors"
                                      onClick={() => {
                                        const updated = members.filter((_, i) => i !== idx);
                                        setEditedFields(f => ({ ...f, family_members: updated }));
                                      }}>
                                      <X className="h-3.5 w-3.5" />
                                    </button>
                                    <p className="text-[10px] font-semibold text-muted-foreground uppercase">Member #{idx + 1}</p>
                                    <div className="grid grid-cols-2 gap-2">
                                      {[["name","Name"],["relation","Relation"],["mobile","Mobile"],["voter_id","Voter ID"]].map(([k, lbl]) => (
                                        <div key={k} className="space-y-1">
                                          <Label className="text-[10px] uppercase tracking-wide text-muted-foreground">{lbl}</Label>
                                          <Input className="h-7 text-xs" value={member[k] ?? ""}
                                            onChange={e => {
                                              const updated = members.map((m, i) => i === idx ? { ...m, [k]: e.target.value } : m);
                                              setEditedFields(f => ({ ...f, family_members: updated }));
                                            }} />
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                                <button type="button"
                                  className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-dashed border-border text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground transition-colors"
                                  onClick={() => {
                                    const updated = [...members, { name: "", relation: "", mobile: "", voter_id: "" }];
                                    setEditedFields(f => ({ ...f, family_members: updated }));
                                  }}>
                                  <Plus className="h-3.5 w-3.5" /> Add Family Member
                                </button>
                              </>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      {FIELD_SETS[mode].map(({ key, label }) => {
                        const val = fieldValue(key);
                        if (Array.isArray(val)) return (
                          <div key={key} className="sm:col-span-2 space-y-1.5">
                            <Label className="text-xs">{label}</Label>
                            <Input value={val.join(", ")} onChange={e => setEditedFields(f => ({ ...f, [key]: e.target.value.split(",").map(s => s.trim()) }))} />
                          </div>
                        );
                        return (
                          <div key={key} className={cn("space-y-1.5", (key === "notes" || key === "description") ? "sm:col-span-2" : "")}>
                            <Label className="text-xs">{label}</Label>
                            {(key === "notes" || key === "description") ? (
                              <textarea rows={2} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" value={val} onChange={e => setEditedFields(f => ({ ...f, [key]: e.target.value }))} />
                            ) : (
                              <Input value={val} onChange={e => setEditedFields(f => ({ ...f, [key]: e.target.value }))} className={cn(val ? "bg-primary/5 border-primary/20" : "")} />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  <div className="flex justify-between gap-3 pt-3 border-t border-border/50">
                    <Button variant="outline" size="sm"
                      onClick={() => {
                        const row = { ...extracted, ...editedFields, __status: "preview" };
                        exportToCSV([row], FIELD_SETS[mode], `intake-preview-${Date.now()}.csv`);
                      }}
                      title="Export this record as CSV to verify before saving">
                      <Download className="h-4 w-4 mr-1.5" /> Export CSV
                    </Button>
                    <div className="flex gap-3">
                      <Button variant="outline" onClick={() => { setExtracted(null); setEditedFields({}); }}>Discard</Button>
                      <Button variant="outline" onClick={() => { addHistory({ ...extracted, ...editedFields }, mode, inputText, false); setExtracted(null); setEditedFields({}); }}>Skip Save</Button>
                      <Button onClick={handleSave} disabled={saving} className="font-semibold">
                        {saving ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Saving…</> : "Save to Database"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  BULK MODE                                                             */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {inputTab === "bulk" && (
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
          {/* Left — upload + paste */}
          <div className="xl:col-span-2 space-y-4">
            {/* File upload zone */}
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-serif flex items-center gap-2"><Upload className="h-4 w-4 text-primary" /> Upload File</CardTitle>
                <CardDescription>Drop a .txt or .csv file — AI extraction starts automatically</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all",
                    isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-secondary/30"
                  )}>
                  <FileText className="h-10 w-10 mx-auto text-muted-foreground/40 mb-3" />
                  {fileName ? (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-sm font-medium text-foreground">{fileName}</span>
                      <button onClick={e => { e.stopPropagation(); setFileName(null); setBulkText(""); }}
                        className="text-muted-foreground hover:text-destructive">
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm font-medium text-foreground">Drop file here or click to browse</p>
                      <p className="text-xs text-muted-foreground mt-1">.txt · .csv supported</p>
                    </>
                  )}
                </div>
                <input ref={fileInputRef} type="file" accept=".txt,.csv" className="hidden" onChange={handleFileChange} />
              </CardContent>
            </Card>

            {/* Paste area */}
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-serif flex items-center gap-2"><Layers className="h-4 w-4 text-primary" /> Paste Multiple Records</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Label className="text-xs shrink-0">Split by</Label>
                  <select className="flex-1 h-8 rounded-md border border-input bg-background px-2 text-xs"
                    value={delimiter} onChange={e => setDelimiter(e.target.value)}>
                    <option value="blank_line">Blank Line (paragraph)</option>
                    <option value="dashes">--- separator</option>
                    <option value="newline">Each Line</option>
                    <option value="semicolon">Semicolon ;</option>
                  </select>
                </div>
                <textarea rows={10} value={bulkText} onChange={e => { setBulkText(e.target.value); setBulkQueue([]); }}
                  placeholder={`Paste multiple records here, separated by blank lines.\n\nExample:\nRaju Netam mob 9876543210 booth 44\n\nMeena didi sarpanch village Bamhani, OBC\n\nRajesh ji mandal president Durg 9712345678`}
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring font-mono" />
                {bulkText && (
                  <p className="text-xs text-muted-foreground">
                    <span className="font-semibold text-primary">{previewChunks.length}</span> record{previewChunks.length !== 1 ? "s" : ""} detected
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Bulk action buttons */}
            <Card className="shadow-sm">
              <CardContent className="pt-4 space-y-3">
                {bulkQueue.length === 0 ? (
                  <Button onClick={initQueue} disabled={!bulkText.trim()} className="w-full font-semibold">
                    <Layers className="h-4 w-4 mr-2" /> Split into Queue ({previewChunks.length})
                  </Button>
                ) : (
                  <>
                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      {[
                        { label: "Total", value: bulkStats.total, color: "text-foreground" },
                        { label: "Done", value: bulkStats.done, color: "text-blue-600" },
                        { label: "Saved", value: bulkStats.saved, color: "text-green-600" },
                        { label: "Skipped", value: bulkStats.skipped, color: "text-muted-foreground" },
                      ].map(s => (
                        <div key={s.label} className="bg-secondary/40 rounded-lg py-2">
                          <p className={cn("text-lg font-bold", s.color)}>{s.value}</p>
                          <p className="text-[10px] text-muted-foreground">{s.label}</p>
                        </div>
                      ))}
                    </div>
                    {/* Progress bar */}
                    <div>
                      <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                        <div className="h-full bg-primary rounded-full transition-all"
                          style={{ width: `${bulkStats.total ? ((bulkStats.done + bulkStats.saved + bulkStats.skipped) / bulkStats.total) * 100 : 0}%` }} />
                      </div>
                    </div>
                    {/* Pause banner — shown when stopped mid-queue with extracted records waiting */}
                    {bulkPaused && bulkStats.done > 0 && (
                      <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 space-y-2">
                        <div className="flex items-start gap-2">
                          <Pause className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                          <div>
                            <p className="text-xs font-semibold text-amber-800">Queue paused — {bulkStats.done} record{bulkStats.done !== 1 ? "s" : ""} extracted</p>
                            <p className="text-[10px] text-amber-700 mt-0.5">{bulkStats.total - bulkStats.done - bulkStats.saved - bulkStats.skipped} still pending. Save extracted records now or resume to continue.</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1 h-7 text-xs bg-amber-600 hover:bg-amber-700 text-white"
                            onClick={saveAllExtracted} disabled={bulkSaving}>
                            <CheckCircle className="h-3.5 w-3.5 mr-1" /> Save All Extracted ({bulkStats.done})
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1 h-7 text-xs border-amber-300 text-amber-700 hover:bg-amber-100"
                            onClick={saveAllHighConfidence} disabled={bulkSaving || !bulkQueue.some(i => i.status === "done" && (i.extracted?.confidence ?? 0) >= 60)}>
                            Save ≥60% Only
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* Saving progress banner */}
                    {bulkSaving && (
                      <div className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 flex items-center gap-3">
                        <Loader2 className="h-4 w-4 text-blue-600 animate-spin shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-blue-800">Saving records… {bulkSaveCount} saved so far</p>
                          <div className="h-1 rounded-full bg-blue-200 mt-1 overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full transition-all"
                              style={{ width: `${bulkStats.saved + bulkSaveCount > 0 ? Math.min(((bulkStats.saved + bulkSaveCount) / bulkStats.total) * 100, 100) : 0}%` }} />
                          </div>
                        </div>
                        <Button size="sm" variant="destructive" className="h-7 px-3 text-xs shrink-0" onClick={stopSave}>
                          <X className="h-3.5 w-3.5 mr-1" /> Stop
                        </Button>
                      </div>
                    )}

                    <div className="flex gap-2">
                      {!bulkRunning ? (
                        <Button onClick={bulkPaused ? resumeBulk : runBulk} className="flex-1 font-semibold"
                          disabled={bulkSaving || bulkStats.done + bulkStats.saved + bulkStats.skipped >= bulkStats.total}>
                          <Play className="h-4 w-4 mr-2" /> {bulkPaused ? "Resume Extraction" : "Extract All"}
                        </Button>
                      ) : (
                        <Button onClick={pauseBulk} variant="outline" className="flex-1" disabled={bulkSaving}>
                          <Pause className="h-4 w-4 mr-2" /> Pause
                        </Button>
                      )}
                      <Button variant="outline" onClick={saveAllExtracted}
                        disabled={bulkSaving || !bulkQueue.some(i => i.status === "done")}
                        title="Save all extracted records regardless of confidence">
                        {bulkSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Save All"}
                      </Button>
                      <Button variant="outline" onClick={saveAllHighConfidence}
                        disabled={bulkSaving || !bulkQueue.some(i => i.status === "done" && (i.extracted?.confidence ?? 0) >= 60)}
                        title="Save only records with ≥60% confidence">
                        ≥60%
                      </Button>
                    </div>
                    {/* Export CSV for verification */}
                    <Button variant="outline" className="w-full text-xs gap-1.5"
                      disabled={!bulkQueue.some(i => i.extracted)}
                      onClick={() => {
                        const rows = bulkQueue
                          .filter(i => i.extracted)
                          .map(i => ({ ...i.extracted!, __status: i.status }));
                        exportToCSV(rows, FIELD_SETS[mode], `intake-queue-${mode}-${Date.now()}.csv`);
                      }}
                      title="Download extracted queue as CSV to verify before saving">
                      <Download className="h-3.5 w-3.5" /> Export Extracted as CSV
                    </Button>
                    <Button variant="ghost" className="w-full text-xs text-muted-foreground" disabled={bulkSaving} onClick={() => { setBulkQueue([]); }}>
                      Reset Queue
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right — bulk queue */}
          <div className="xl:col-span-3">
            {bulkQueue.length === 0 ? (
              <Card className="shadow-sm h-full">
                <CardContent className="flex flex-col items-center justify-center h-72 text-center">
                  <Layers className="h-16 w-16 text-muted-foreground/20 mb-4" />
                  <p className="text-base font-medium text-foreground">Bulk Queue Empty</p>
                  <p className="text-sm text-muted-foreground mt-1 max-w-xs">Upload a file or paste multiple records on the left, then click Split into Queue.</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-sm">
                <CardHeader className="border-b border-border/50 pb-3">
                  <CardTitle className="font-serif text-base flex items-center gap-2">
                    <Layers className="h-4 w-4 text-primary" /> Extraction Queue
                  </CardTitle>
                  <CardDescription>{bulkStats.total} records · {bulkStats.done} extracted · {bulkStats.saved} saved</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-border/40 max-h-[600px] overflow-y-auto">
                    {bulkQueue.map((item, idx) => {
                      const conf = item.extracted?.confidence ?? 0;
                      const statusMeta: Record<BulkStatus, { color: string; label: string }> = {
                        pending:    { color: "bg-gray-100 text-gray-500",   label: "Pending" },
                        extracting: { color: "bg-blue-100 text-blue-600",   label: "Extracting…" },
                        done:       { color: "bg-yellow-100 text-yellow-700",label: "Review" },
                        error:      { color: "bg-red-100 text-red-600",     label: "Error" },
                        saved:      { color: "bg-green-100 text-green-700", label: "Saved" },
                        skipped:    { color: "bg-gray-100 text-gray-400",   label: "Skipped" },
                      };
                      const meta = statusMeta[item.status];
                      const isExpanded = bulkExpanded === item.id;
                      const summaryText = item.extracted
                        ? (item.extracted.full_name || item.extracted.title || item.extracted.primary_mobile || item.raw.slice(0, 40))
                        : item.raw.slice(0, 50);

                      return (
                        <div key={item.id}>
                          <div className={cn("flex items-center gap-3 px-4 py-3 hover:bg-secondary/20 transition-colors",
                              item.status === "saved" ? "opacity-60" : "", item.status === "skipped" ? "opacity-40" : "")}>
                            <span className="text-[10px] font-mono text-muted-foreground w-5 text-right shrink-0">{idx + 1}</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-foreground truncate">{summaryText}</p>
                              {item.status === "extracting" && (
                                <p className="text-[10px] text-blue-600 flex items-center gap-1"><Loader2 className="h-2.5 w-2.5 animate-spin" /> Extracting…</p>
                              )}
                            </div>
                            {item.extracted && item.status !== "pending" && item.status !== "extracting" && (
                              <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded border", conf >= 70 ? "bg-green-100 text-green-700 border-green-200" : conf >= 40 ? "bg-yellow-100 text-yellow-700 border-yellow-200" : "bg-red-100 text-red-700 border-red-200")}>
                                {conf}%
                              </span>
                            )}
                            <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full", meta.color)}>{meta.label}</span>
                            {item.status === "done" && (
                              <div className="flex gap-1 shrink-0">
                                <button onClick={() => setBulkExpanded(isExpanded ? null : item.id)}
                                  className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors" title="Review">
                                  <ChevronRight className={cn("h-3.5 w-3.5 transition-transform", isExpanded ? "rotate-90" : "")} />
                                </button>
                                <button onClick={() => saveBulkItem(item)}
                                  className="p-1 rounded hover:bg-green-100 text-muted-foreground hover:text-green-700 transition-colors" title="Save">
                                  <CheckCircle className="h-3.5 w-3.5" />
                                </button>
                                <button onClick={() => skipBulkItem(item.id)}
                                  className="p-1 rounded hover:bg-red-100 text-muted-foreground hover:text-red-600 transition-colors" title="Skip">
                                  <SkipForward className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            )}
                          </div>

                          {/* Expanded review panel — same form as single mode */}
                          {isExpanded && item.extracted && (
                            <div className="px-4 pb-4 pt-3 bg-secondary/10 border-t border-border/30 space-y-4">
                              {/* Raw text */}
                              <div className="rounded-lg border border-border bg-card p-3">
                                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1.5">Raw Input</p>
                                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">{item.raw}</p>
                              </div>

                              {mode === "contact" ? (
                                <div className="space-y-4">
                                  {CONTACT_FIELD_GROUPS.map(group => {
                                    const groupIcon = group.icon === "user" ? <User className="h-3 w-3" /> : group.icon === "map" ? <MapPin className="h-3 w-3" /> : group.icon === "flag" ? <Flag className="h-3 w-3" /> : group.icon === "users" ? <Users className="h-3 w-3" /> : group.icon === "share" ? <Share2 className="h-3 w-3" /> : <FileText className="h-3 w-3" />;
                                    const fieldDefs = CONTACT_FIELDS.filter(f => group.fields.includes(f.key));
                                    return (
                                      <div key={group.id} className="rounded-xl border border-border bg-card overflow-hidden">
                                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary/30 border-b border-border/50">
                                          {groupIcon}
                                          <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{group.label}</p>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2 p-3">
                                          {fieldDefs.map(({ key, label, required }) => {
                                            const val = (item.edits?.[key] !== undefined ? item.edits[key] : item.extracted![key]) ?? "";
                                            const isNotes = key === "notes";
                                            return (
                                              <div key={key} className={cn("space-y-0.5", isNotes ? "col-span-2" : "")}>
                                                <label className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider block">
                                                  {label}{required && <span className="text-destructive ml-0.5">*</span>}
                                                </label>
                                                {isNotes ? (
                                                  <textarea rows={2} className="w-full rounded border border-input bg-background px-2 py-1 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                                                    value={val} onChange={e => updateBulkItemField(item.id, key, e.target.value)} />
                                                ) : (
                                                  <Input className={cn("h-7 text-xs", val ? "bg-primary/5 border-primary/20" : "")}
                                                    value={val} placeholder="—"
                                                    onChange={e => updateBulkItemField(item.id, key, e.target.value)} />
                                                )}
                                              </div>
                                            );
                                          })}
                                        </div>
                                      </div>
                                    );
                                  })}

                                  {/* Family Members */}
                                  <div className="rounded-xl border border-border bg-card overflow-hidden">
                                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary/30 border-b border-border/50">
                                      <Heart className="h-3 w-3 text-rose-500" />
                                      <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Family Members</p>
                                    </div>
                                    <div className="p-3 space-y-2">
                                      {(() => {
                                        const members: any[] = Array.isArray(item.edits?.family_members) ? item.edits!.family_members :
                                          Array.isArray(item.extracted!.family_members) ? item.extracted!.family_members : [];
                                        return (
                                          <>
                                            {members.map((member: any, midx: number) => (
                                              <div key={midx} className="rounded-lg border border-border bg-background p-2 space-y-1.5 relative">
                                                <button type="button" className="absolute top-1.5 right-1.5 text-muted-foreground hover:text-destructive"
                                                  onClick={() => updateBulkItemField(item.id, "family_members", members.filter((_, i) => i !== midx))}>
                                                  <X className="h-3 w-3" />
                                                </button>
                                                <p className="text-[9px] font-semibold text-muted-foreground uppercase">Member #{midx + 1}</p>
                                                <div className="grid grid-cols-2 gap-1.5">
                                                  {[["name","Name"],["relation","Relation"],["mobile","Mobile"],["voter_id","Voter ID"]].map(([k, lbl]) => (
                                                    <div key={k} className="space-y-0.5">
                                                      <label className="text-[9px] uppercase tracking-wide text-muted-foreground">{lbl}</label>
                                                      <Input className="h-6 text-xs" value={member[k] ?? ""}
                                                        onChange={e => updateBulkItemField(item.id, "family_members", members.map((m, i) => i === midx ? { ...m, [k]: e.target.value } : m))} />
                                                    </div>
                                                  ))}
                                                </div>
                                              </div>
                                            ))}
                                            <button type="button"
                                              className="w-full flex items-center justify-center gap-1 py-1.5 rounded-lg border border-dashed border-border text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground transition-colors"
                                              onClick={() => updateBulkItemField(item.id, "family_members", [...members, { name: "", relation: "", mobile: "", voter_id: "" }])}>
                                              <Plus className="h-3 w-3" /> Add Family Member
                                            </button>
                                          </>
                                        );
                                      })()}
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="grid grid-cols-2 gap-2">
                                  {FIELD_SETS[mode].map(({ key, label }) => {
                                    const val = (item.edits?.[key] !== undefined ? item.edits[key] : item.extracted![key]) ?? "";
                                    if (Array.isArray(val) && val.length === 0) return null;
                                    return (
                                      <div key={key} className={cn("space-y-0.5", (key === "notes" || key === "description") ? "col-span-2" : "")}>
                                        <label className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider block">{label}</label>
                                        {(key === "notes" || key === "description") ? (
                                          <textarea rows={2} className="w-full rounded border border-input bg-background px-2 py-1 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                                            value={val} onChange={e => updateBulkItemField(item.id, key, e.target.value)} />
                                        ) : (
                                          <Input className={cn("h-7 text-xs", val ? "bg-primary/5 border-primary/20" : "")}
                                            value={Array.isArray(val) ? val.join(", ") : val}
                                            onChange={e => updateBulkItemField(item.id, key, e.target.value)} />
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}

                              <div className="flex gap-2 pt-1 border-t border-border/40">
                                <Button size="sm" className="h-7 text-xs font-semibold" onClick={() => saveBulkItem(item)}>
                                  <CheckCircle className="h-3.5 w-3.5 mr-1" /> Save to Database
                                </Button>
                                <Button size="sm" variant="ghost" className="h-7 text-xs text-muted-foreground" onClick={() => skipBulkItem(item.id)}>
                                  <SkipForward className="h-3.5 w-3.5 mr-1" /> Skip
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
