import { useState } from "react";
import { useGetContacts } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, MapPin, Users, Star, Loader2, Phone, Search, SlidersHorizontal, X } from "lucide-react";
import { formatPhone, waLink } from "@/lib/phone";
import { cn } from "@/lib/utils";
import { CG_DISTRICTS, CG_ASSEMBLIES } from "@/data/cg-assemblies";

const PARTY_OPTIONS = [
  { value: "bjp", label: "BJP" }, { value: "inc", label: "INC" },
  { value: "aap", label: "AAP" }, { value: "bsp", label: "BSP" },
  { value: "jcc", label: "JCC" }, { value: "independent", label: "Independent" },
  { value: "other", label: "Other" },
];

export default function Volunteers() {
  const [search, setSearch] = useState("");
  const [districtFilter, setDistrictFilter] = useState("");
  const [assemblyFilter, setAssemblyFilter] = useState("");
  const [partyFilter, setPartyFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const { data, isLoading } = useGetContacts({ volunteers: "true" });
  const { data: allData } = useGetContacts({});

  const allContacts = allData?.data ?? [];
  const rawVolunteers = data?.data ?? [];

  const volunteers = rawVolunteers.filter(v => {
    if (search) {
      const s = search.toLowerCase();
      if (
        !v.name?.toLowerCase().includes(s) &&
        !v.mobile?.includes(s) &&
        !v.village_ward?.toLowerCase().includes(s) &&
        !v.constituency?.toLowerCase().includes(s)
      ) return false;
    }
    if (districtFilter && districtFilter !== "all") {
      if (!v.district?.toLowerCase().includes(districtFilter.toLowerCase())) return false;
    }
    if (assemblyFilter && assemblyFilter !== "all") {
      if (!v.constituency?.toLowerCase().includes(assemblyFilter.toLowerCase())) return false;
    }
    if (partyFilter && partyFilter !== "all") {
      if (v.political_party !== partyFilter) return false;
    }
    if (genderFilter && genderFilter !== "all") {
      if (v.gender !== genderFilter) return false;
    }
    return true;
  });

  const assemblyOptions = districtFilter && districtFilter !== "all"
    ? CG_ASSEMBLIES.filter(a => a.district === districtFilter)
    : CG_ASSEMBLIES;

  const activeFilterCount = [districtFilter, assemblyFilter, partyFilter, genderFilter].filter(v => v && v !== "all").length;

  const clearFilters = () => {
    setSearch(""); setDistrictFilter(""); setAssemblyFilter("");
    setPartyFilter(""); setGenderFilter("");
  };

  const coordinators = allContacts.filter(c => c.leader_group).length;
  const boothsCovered = new Set(volunteers.map(v => v.booth_number).filter(Boolean)).size;
  const seatsCovered = new Set(volunteers.map(v => v.constituency).filter(Boolean)).size;
  const districtsCovered = new Set(volunteers.map(v => v.district).filter(Boolean)).size;

  const stats = [
    { label: "Volunteers Shown", value: volunteers.length, color: "text-violet-500", bg: "bg-violet-500/10" },
    { label: "Coordinators", value: coordinators, color: "text-orange-500", bg: "bg-orange-500/10" },
    { label: "Booths Covered", value: boothsCovered, color: "text-green-500", bg: "bg-green-500/10" },
    { label: "Seats Covered", value: seatsCovered, color: "text-teal-500", bg: "bg-teal-500/10" },
    { label: "Districts", value: districtsCovered, color: "text-blue-500", bg: "bg-blue-500/10" },
  ];

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold font-serif tracking-tight">Volunteer Network</h2>
        <p className="text-muted-foreground text-sm mt-1">Contacts who are active volunteers in the field.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        {stats.map(s => (
          <Card key={s.label} className="border-border shadow-sm">
            <CardContent className="p-5 text-center">
              <p className={cn("text-3xl font-bold font-serif", s.color)}>{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1 font-medium">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filter bar */}
      <div className="bg-card p-4 rounded-xl border border-border shadow-sm space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search name, mobile, village…"
              className="pl-9 bg-secondary/50"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            className="shrink-0 relative"
            onClick={() => setShowFilters(v => !v)}
          >
            <SlidersHorizontal className="h-4 w-4 mr-2" /> Filters
            {activeFilterCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </Button>
          {(activeFilterCount > 0 || search) && (
            <Button variant="ghost" size="icon" onClick={clearFilters}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showFilters && (
          <div className="space-y-2 pt-1">
            {/* Geography */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Geography</p>
              <div className="grid grid-cols-2 gap-2">
                <Select value={districtFilter} onValueChange={v => { setDistrictFilter(v === "all" ? "" : v); setAssemblyFilter(""); }}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="District" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Districts</SelectItem>
                    {CG_DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={assemblyFilter} onValueChange={v => setAssemblyFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Assembly" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Assemblies</SelectItem>
                    {assemblyOptions.map(a => <SelectItem key={a.number} value={a.name}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {/* Personal */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Profile</p>
              <div className="grid grid-cols-2 gap-2">
                <Select value={partyFilter} onValueChange={v => setPartyFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Party" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Parties</SelectItem>
                    {PARTY_OPTIONS.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={genderFilter} onValueChange={v => setGenderFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Gender" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Genders</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Volunteer cards grid */}
      {volunteers.length === 0 ? (
        <Card className="border-border shadow-sm">
          <CardContent className="py-16 text-center text-muted-foreground">
            <Heart className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
            <p className="text-lg font-medium text-foreground">No volunteers found</p>
            <p className="text-sm mt-1">
              {activeFilterCount > 0 || search
                ? "Try adjusting your filters."
                : "Add contacts and mark them as volunteers to see them here."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {volunteers.map(v => (
            <Card key={v.id} className="border-border shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center font-bold text-sm text-white shrink-0">
                    {(v.name ?? "?").charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm text-foreground truncate">{v.name ?? "Unknown"}</p>
                    <p className="text-xs text-muted-foreground font-mono">{formatPhone(v.mobile)}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {v.district && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-secondary text-muted-foreground">
                      <MapPin className="h-2.5 w-2.5" />
                      {v.district}
                    </span>
                  )}
                  {v.constituency && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-secondary text-muted-foreground">
                      {v.constituency}
                    </span>
                  )}
                  {v.booth_number && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-blue-50 text-blue-700">
                      Booth {v.booth_number}
                    </span>
                  )}
                  {v.political_party && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-primary/10 text-primary font-semibold uppercase">
                      {v.political_party}
                    </span>
                  )}
                  {v.leader_group && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-amber-50 text-amber-700">
                      <Star className="h-2.5 w-2.5" />
                      {v.leader_group}
                    </span>
                  )}
                  {v.gender && (
                    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-secondary text-muted-foreground capitalize">
                      {v.gender}
                    </span>
                  )}
                </div>
                <div className="mt-3 flex gap-2">
                  <a href={`tel:${v.mobile}`} className="flex-1">
                    <Button size="sm" variant="outline" className="w-full h-7 text-xs">
                      <Phone className="h-3 w-3 mr-1" /> Call
                    </Button>
                  </a>
                  {v.whatsapp_number && (
                    <a href={waLink(v.whatsapp_number)} target="_blank" rel="noreferrer" className="flex-1">
                      <Button size="sm" variant="outline" className="w-full h-7 text-xs text-green-600 border-green-200 hover:bg-green-50">
                        WhatsApp
                      </Button>
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
