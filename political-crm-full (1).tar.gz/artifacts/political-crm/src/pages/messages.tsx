import { useState, useEffect, useCallback, useRef } from "react";
import { useGetMessages, useGetContacts } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  Send, Mail, MessageCircle, Loader2, Facebook, Instagram, Twitter,
  Filter, Users, Plus, Trash2, ListFilter, RefreshCw, CheckCircle2,
  ChevronDown, ChevronUp, X, Save, BookUser,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { CG_DISTRICTS, CG_LOK_SABHA, CG_ASSEMBLIES } from "@/data/cg-assemblies";
import { getPartyOrg } from "@/data/party-organizations";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const CHANNELS = [
  { key: "whatsapp",  label: "WhatsApp",  emoji: "📱", icon: MessageCircle, color: "text-green-600",  bg: "bg-green-500/10",  border: "border-green-500" },
  { key: "email",     label: "Email",     emoji: "📧", icon: Mail,          color: "text-blue-600",   bg: "bg-blue-500/10",   border: "border-blue-500" },
  { key: "sms",       label: "SMS",       emoji: "💬", icon: Send,          color: "text-purple-600", bg: "bg-purple-500/10", border: "border-purple-500" },
  { key: "facebook",  label: "Facebook",  emoji: "📘", icon: Facebook,      color: "text-indigo-600", bg: "bg-indigo-500/10", border: "border-indigo-500" },
  { key: "instagram", label: "Instagram", emoji: "📷", icon: Instagram,     color: "text-pink-600",   bg: "bg-pink-500/10",   border: "border-pink-500" },
  { key: "twitter",   label: "Twitter/X", emoji: "𝕏",  icon: Twitter,       color: "text-sky-600",    bg: "bg-sky-500/10",    border: "border-sky-500" },
];

const TEMPLATES = {
  greeting: "Hello! Thank you for your continued support. Your trust means everything to us.",
  event: "You're invited to our upcoming community event. Together we can make a difference.",
  update: "Important update on our campaign initiatives. Stay connected for more details.",
  birthday: "Wishing you a very Happy Birthday! 🎂 May this year bring you joy and good health.",
  rally: "Join us at our grand rally this weekend! Your presence makes us stronger. Together we stand for change.",
};

const PARTY_LABELS: Record<string, string> = {
  bjp: "BJP", inc: "INC", aap: "AAP", bsp: "BSP", sp: "SP", jcc: "JCC(J)", independent: "Independent", other: "Other",
};

interface FilterState {
  party: string;
  party_frontal: string;
  district: string;
  assembly: string;
  lok_sabha: string;
  caste: string;
  religion: string;
  gender: string;
  leader_group: string;
  volunteer: boolean | null;
  has_whatsapp: boolean | null;
}

const EMPTY_FILTER: FilterState = {
  party: "", party_frontal: "", district: "", assembly: "", lok_sabha: "",
  caste: "", religion: "", gender: "", leader_group: "", volunteer: null, has_whatsapp: null,
};

interface RecipientList {
  id: string;
  name: string;
  description?: string;
  filters: string;
  contact_count: number;
  created_at: string;
}

function filterLabel(key: string, value: any): string {
  if (key === "party") return PARTY_LABELS[value] ?? value;
  if (key === "volunteer") return "Volunteers only";
  if (key === "has_whatsapp") return "Has WhatsApp";
  return String(value);
}

function activeFilterCount(f: FilterState): number {
  let n = 0;
  if (f.party) n++;
  if (f.party_frontal) n++;
  if (f.district) n++;
  if (f.assembly) n++;
  if (f.lok_sabha) n++;
  if (f.caste) n++;
  if (f.religion) n++;
  if (f.gender) n++;
  if (f.leader_group) n++;
  if (f.volunteer !== null) n++;
  if (f.has_whatsapp !== null) n++;
  return n;
}

function filtersToPayload(f: FilterState) {
  const out: Record<string, any> = {};
  if (f.party) out.party = f.party;
  if (f.party_frontal) out.party_frontal = f.party_frontal;
  if (f.district) out.district = f.district;
  if (f.assembly) out.assembly = f.assembly;
  if (f.lok_sabha) out.lok_sabha = f.lok_sabha;
  if (f.caste) out.caste = f.caste;
  if (f.religion) out.religion = f.religion;
  if (f.gender) out.gender = f.gender;
  if (f.leader_group) out.leader_group = f.leader_group;
  if (f.volunteer !== null) out.volunteer = f.volunteer;
  if (f.has_whatsapp !== null) out.has_whatsapp = f.has_whatsapp;
  return out;
}

function getChannelMeta(channel: string) {
  return CHANNELS.find(c => c.key === channel.toLowerCase());
}

// ─── Cascading helpers ────────────────────────────────────────────────────────
function getDistrictsByLokSabha(ls: string): string[] {
  const districts = CG_ASSEMBLIES
    .filter(a => a.lok_sabha === ls)
    .map(a => a.district);
  return [...new Set(districts)].sort();
}

function getAssembliesByDistrictAndLokSabha(district: string, ls: string): string[] {
  return CG_ASSEMBLIES
    .filter(a => a.district === district && (ls ? a.lok_sabha === ls : true))
    .map(a => a.name)
    .sort();
}

// ─── Detailed Filter Panel ────────────────────────────────────────────────────
function FilterPanel({
  filters, onChange, liveCount, counting,
}: {
  filters: FilterState;
  onChange: (f: FilterState) => void;
  liveCount: number;
  counting: boolean;
}) {
  const partyOrg = getPartyOrg(filters.party);

  // Cascading geography lists
  const districtOptions = filters.lok_sabha
    ? getDistrictsByLokSabha(filters.lok_sabha)
    : CG_DISTRICTS;
  const assemblyOptions = filters.district
    ? getAssembliesByDistrictAndLokSabha(filters.district, filters.lok_sabha)
    : filters.lok_sabha
      ? CG_ASSEMBLIES.filter(a => a.lok_sabha === filters.lok_sabha).map(a => a.name).sort()
      : CG_ASSEMBLIES.map(a => a.name).sort();

  const set = (key: keyof FilterState, val: any) => onChange({ ...filters, [key]: val });

  // Clear helpers — cascade down when parent changes
  const setLokSabha = (val: string) =>
    onChange({ ...filters, lok_sabha: val, district: "", assembly: "" });
  const setDistrict = (val: string) =>
    onChange({ ...filters, district: val, assembly: "" });
  const clearField = (key: keyof FilterState) => {
    if (key === "lok_sabha") return onChange({ ...filters, lok_sabha: "", district: "", assembly: "" });
    if (key === "district")  return onChange({ ...filters, district: "", assembly: "" });
    onChange({ ...filters, [key]: key === "volunteer" || key === "has_whatsapp" ? null : "" });
  };

  const FRow = ({ label, field, children }: { label: string; field: keyof FilterState; children: React.ReactNode }) => (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">{label}</label>
        {(filters[field] !== "" && filters[field] !== null) && (
          <button onClick={() => clearField(field)} className="text-[10px] text-muted-foreground hover:text-destructive transition-colors">
            <X className="h-3 w-3" />
          </button>
        )}
      </div>
      {children}
    </div>
  );

  const SField = ({ field, options, placeholder, onChangeFn }: {
    field: keyof FilterState;
    options: { value: string; label: string }[];
    placeholder: string;
    onChangeFn?: (v: string) => void;
  }) => (
    <Select value={(filters[field] as string) || ""} onValueChange={onChangeFn ?? (v => set(field, v))}>
      <SelectTrigger className="h-8 text-xs">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent className="max-h-52 overflow-y-auto">
        {options.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}
      </SelectContent>
    </Select>
  );

  return (
    <div className="space-y-4">
      {/* Live count banner */}
      <div className={cn(
        "flex items-center justify-between rounded-xl border-2 px-4 py-3 transition-colors",
        liveCount > 0 ? "border-primary/30 bg-primary/5" : "border-border bg-secondary/20"
      )}>
        <div className="flex items-center gap-2">
          <Users className={cn("h-4 w-4", liveCount > 0 ? "text-primary" : "text-muted-foreground")} />
          <span className="text-sm font-semibold text-foreground">
            {counting
              ? "Counting…"
              : <><span className={cn("text-lg font-bold mr-1", liveCount > 0 ? "text-primary" : "text-muted-foreground")}>{liveCount}</span> contacts match</>}
          </span>
        </div>
        {activeFilterCount(filters) > 0 && (
          <button onClick={() => onChange(EMPTY_FILTER)}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors">
            <X className="h-3 w-3" /> Clear all
          </button>
        )}
      </div>

      {/* Active filter chips */}
      {activeFilterCount(filters) > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {Object.entries(filtersToPayload(filters)).map(([k, v]) => (
            <span key={k} className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-semibold border border-primary/20">
              {filterLabel(k, v)}
              <button onClick={() => clearField(k as keyof FilterState)} className="hover:text-destructive ml-0.5">
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* ── Party ── */}
      <div className="grid grid-cols-2 gap-3">
        <FRow label="Political Party" field="party">
          <SField field="party" placeholder="Any party" options={[
            { value: "bjp", label: "BJP" }, { value: "inc", label: "INC" },
            { value: "aap", label: "AAP" }, { value: "bsp", label: "BSP" },
            { value: "sp", label: "SP"  }, { value: "jcc", label: "JCC(J)" },
            { value: "independent", label: "Independent" }, { value: "other", label: "Other" },
          ]} />
        </FRow>

        {filters.party && partyOrg.frontals.length > 0 && (
          <FRow label="Frontal / Wing" field="party_frontal">
            <SField field="party_frontal" placeholder="Any frontal"
              options={partyOrg.frontals.map(f => ({ value: f, label: f }))} />
          </FRow>
        )}
      </div>

      {/* ── Geography — cascaded ── */}
      <div className="rounded-xl border border-border/60 bg-secondary/10 p-3 space-y-3">
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
          Geography
          <span className="font-normal normal-case text-[9px] text-muted-foreground/70">(Lok Sabha → District → Assembly)</span>
        </p>

        {/* Row 1: Lok Sabha */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Lok Sabha Constituency</label>
            {filters.lok_sabha && (
              <button onClick={() => clearField("lok_sabha")} className="text-[10px] text-muted-foreground hover:text-destructive transition-colors flex items-center gap-0.5">
                <X className="h-3 w-3" /> Clear
              </button>
            )}
          </div>
          <Select value={filters.lok_sabha || ""} onValueChange={setLokSabha}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue placeholder="Any Lok Sabha constituency" />
            </SelectTrigger>
            <SelectContent className="max-h-52">
              {CG_LOK_SABHA.map(l => <SelectItem key={l} value={l} className="text-xs">{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Row 2: District — filtered by Lok Sabha */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className={cn(
              "text-[10px] font-bold uppercase tracking-wider",
              filters.lok_sabha ? "text-foreground" : "text-muted-foreground"
            )}>
              District
              {filters.lok_sabha && <span className="font-normal normal-case ml-1 text-primary/70 text-[9px]">in {filters.lok_sabha}</span>}
            </label>
            {filters.district && (
              <button onClick={() => clearField("district")} className="text-[10px] text-muted-foreground hover:text-destructive transition-colors flex items-center gap-0.5">
                <X className="h-3 w-3" /> Clear
              </button>
            )}
          </div>
          <Select value={filters.district || ""} onValueChange={setDistrict}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue placeholder={filters.lok_sabha ? `Districts under ${filters.lok_sabha}` : "Any district"} />
            </SelectTrigger>
            <SelectContent className="max-h-52">
              {districtOptions.map(d => <SelectItem key={d} value={d} className="text-xs">{d}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Row 3: Assembly — filtered by District (or Lok Sabha) */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <label className={cn(
              "text-[10px] font-bold uppercase tracking-wider",
              filters.district ? "text-foreground" : "text-muted-foreground"
            )}>
              Assembly Constituency
              {filters.district && <span className="font-normal normal-case ml-1 text-primary/70 text-[9px]">in {filters.district}</span>}
              {!filters.district && filters.lok_sabha && <span className="font-normal normal-case ml-1 text-primary/70 text-[9px]">in {filters.lok_sabha}</span>}
            </label>
            {filters.assembly && (
              <button onClick={() => clearField("assembly")} className="text-[10px] text-muted-foreground hover:text-destructive transition-colors flex items-center gap-0.5">
                <X className="h-3 w-3" /> Clear
              </button>
            )}
          </div>
          <Select value={filters.assembly || ""} onValueChange={v => set("assembly", v)}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue placeholder={
                filters.district ? `Assemblies in ${filters.district}` :
                filters.lok_sabha ? `Assemblies in ${filters.lok_sabha}` :
                "Any assembly constituency"
              } />
            </SelectTrigger>
            <SelectContent className="max-h-52">
              {assemblyOptions.map(a => <SelectItem key={a} value={a} className="text-xs">{a}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* ── Other filters ── */}
      <div className="grid grid-cols-2 gap-3">
        <FRow label="Caste" field="caste">
          <SField field="caste" placeholder="Any caste" options={[
            { value: "general", label: "General" }, { value: "obc", label: "OBC" },
            { value: "sc", label: "SC" }, { value: "st", label: "ST" },
          ]} />
        </FRow>

        <FRow label="Religion" field="religion">
          <SField field="religion" placeholder="Any religion" options={[
            { value: "hindu", label: "Hindu" }, { value: "muslim", label: "Muslim" },
            { value: "christian", label: "Christian" }, { value: "sikh", label: "Sikh" },
            { value: "other", label: "Other" },
          ]} />
        </FRow>

        <FRow label="Gender" field="gender">
          <SField field="gender" placeholder="Any gender" options={[
            { value: "male", label: "Male" }, { value: "female", label: "Female" }, { value: "other", label: "Other" },
          ]} />
        </FRow>

        <div className="col-span-2">
          <FRow label="Leader Group" field="leader_group">
            <Input className="h-8 text-xs" placeholder="Leader name contains…"
              value={filters.leader_group}
              onChange={e => set("leader_group", e.target.value)} />
          </FRow>
        </div>

        <FRow label="Volunteers" field="volunteer">
          <SField field="volunteer" placeholder="Any" options={[
            { value: "true", label: "Volunteers only" }, { value: "false", label: "Non-volunteers" },
          ]} />
        </FRow>

        <FRow label="Has WhatsApp" field="has_whatsapp">
          <SField field="has_whatsapp" placeholder="Any" options={[
            { value: "true", label: "Has WhatsApp" }, { value: "false", label: "No WhatsApp" },
          ]} />
        </FRow>
      </div>
    </div>
  );
}

// ─── Save List Dialog ─────────────────────────────────────────────────────────
function SaveListDialog({
  open, onOpenChange, filters, liveCount, onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  filters: FilterState;
  liveCount: number;
  onSaved: () => void;
}) {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await fetch(`${BASE}/api/recipient-lists`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), description: desc.trim() || undefined, filters: filtersToPayload(filters) }),
      });
      setName(""); setDesc("");
      onSaved();
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif">Save Recipient List</DialogTitle>
          <DialogDescription>Save these filters as a named list for reuse in future campaigns.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <div className="rounded-xl bg-primary/5 border border-primary/20 px-4 py-3 flex items-center gap-2">
            <Users className="h-4 w-4 text-primary shrink-0" />
            <span className="text-sm font-semibold text-primary">{liveCount} contacts will be in this list</span>
          </div>
          {activeFilterCount(filters) > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(filtersToPayload(filters)).map(([k, v]) => (
                <span key={k} className="px-2 py-0.5 rounded-full bg-secondary text-muted-foreground text-[10px] font-semibold border border-border">
                  {filterLabel(k, v)}
                </span>
              ))}
            </div>
          )}
          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">List Name *</label>
              <Input className="mt-1.5" placeholder="e.g. Balod District INC Volunteers" value={name}
                onChange={e => setName(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSave()} />
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Description (optional)</label>
              <Input className="mt-1.5" placeholder="Short description of this list" value={desc} onChange={e => setDesc(e.target.value)} />
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={!name.trim() || saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Save List
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function Messages() {
  const [activeTab, setActiveTab] = useState<"compose" | "lists">("compose");
  const [selectedChannel, setSelectedChannel] = useState("whatsapp");
  const [msgBody, setMsgBody] = useState("");
  const [sending, setSending] = useState(false);
  const [filters, setFilters] = useState<FilterState>(EMPTY_FILTER);
  const [liveCount, setLiveCount] = useState(0);
  const [counting, setCounting] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [isSaveListOpen, setIsSaveListOpen] = useState(false);
  const [recipientMode, setRecipientMode] = useState<"filter" | "list">("filter");
  const [selectedListId, setSelectedListId] = useState<string | null>(null);
  const [selectedListCount, setSelectedListCount] = useState(0);
  const [recipientLists, setRecipientLists] = useState<RecipientList[]>([]);
  const [listsLoading, setListsLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: messagesData, isLoading: messagesLoading, refetch } = useGetMessages();
  const { data: contactsData } = useGetContacts({});
  const allContacts = contactsData?.data ?? [];

  const fetchLiveCount = useCallback(async (f: FilterState) => {
    const payload = filtersToPayload(f);
    if (Object.keys(payload).length === 0) {
      setLiveCount(allContacts.length);
      return;
    }
    setCounting(true);
    try {
      const res = await fetch(`${BASE}/api/recipient-lists/preview`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const j = await res.json();
      if (j.success) setLiveCount(j.total);
    } finally {
      setCounting(false);
    }
  }, [allContacts.length]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => fetchLiveCount(filters), 400);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [filters, fetchLiveCount]);

  useEffect(() => {
    if (allContacts.length > 0 && activeFilterCount(filters) === 0) {
      setLiveCount(allContacts.length);
    }
  }, [allContacts.length]);

  const fetchLists = async () => {
    setListsLoading(true);
    try {
      const res = await fetch(`${BASE}/api/recipient-lists`);
      const j = await res.json();
      if (j.success) setRecipientLists(j.data);
    } finally {
      setListsLoading(false);
    }
  };

  useEffect(() => { fetchLists(); }, []);

  const handleDeleteList = async (id: string) => {
    setDeletingId(id);
    await fetch(`${BASE}/api/recipient-lists/${id}`, { method: "DELETE" });
    setRecipientLists(prev => prev.filter(l => l.id !== id));
    if (selectedListId === id) { setSelectedListId(null); setSelectedListCount(0); }
    setDeletingId(null);
  };

  const handleSelectList = (list: RecipientList) => {
    setSelectedListId(list.id);
    setSelectedListCount(list.contact_count ?? 0);
    setRecipientMode("list");
    setActiveTab("compose");
  };

  const recipientCount = recipientMode === "filter" ? liveCount : selectedListCount;
  const selectedList = recipientLists.find(l => l.id === selectedListId);

  const handleSend = async () => {
    if (!msgBody.trim() || recipientCount === 0) return;
    setSending(true);
    try {
      const res = await fetch(`${BASE}/api/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message_content: msgBody.trim(),
          message_channel: selectedChannel,
          recipient_type: recipientMode === "list" ? (selectedList?.name ?? "saved_list") : "filtered",
          recipient_count: recipientCount,
        }),
      });
      if (res.ok) {
        setMsgBody("");
        refetch();
      }
    } finally {
      setSending(false);
    }
  };

  const TABS = [
    { id: "compose", label: "Compose & Send", icon: Send },
    { id: "lists",   label: `Recipient Lists${recipientLists.length ? ` (${recipientLists.length})` : ""}`, icon: BookUser },
  ];

  return (
    <div className="space-y-5 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h2 className="text-2xl font-bold font-serif tracking-tight">Campaign Messaging</h2>
          <p className="text-muted-foreground text-sm mt-0.5">Broadcast to filtered audiences across channels.</p>
        </div>
      </div>

      {/* Page tabs */}
      <div className="flex border-b border-border gap-0">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveTab(id as any)}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap",
              activeTab === id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
            )}>
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </div>

      {/* ── COMPOSE TAB ── */}
      {activeTab === "compose" && (
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-5">

          {/* Left: Composer */}
          <Card className="xl:col-span-2 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="font-serif text-base flex items-center gap-2">
                <Send className="h-4 w-4 text-primary" /> Compose Message
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Channel */}
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Channel</p>
                <div className="flex flex-wrap gap-2">
                  {CHANNELS.map((ch) => (
                    <button key={ch.key} onClick={() => setSelectedChannel(ch.key)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all",
                        selectedChannel === ch.key
                          ? `${ch.bg} ${ch.border} ${ch.color}`
                          : "bg-background border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      )}>
                      {ch.emoji} {ch.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Recipient mode toggle */}
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Recipients</p>
                <div className="flex rounded-lg border border-border overflow-hidden text-xs font-semibold">
                  <button onClick={() => setRecipientMode("filter")}
                    className={cn("flex-1 px-3 py-2 transition-colors flex items-center justify-center gap-1.5",
                      recipientMode === "filter" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-secondary")}>
                    <ListFilter className="h-3.5 w-3.5" /> Filter Contacts
                  </button>
                  <button onClick={() => setRecipientMode("list")}
                    className={cn("flex-1 px-3 py-2 transition-colors flex items-center justify-center gap-1.5 border-l border-border",
                      recipientMode === "list" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-secondary")}>
                    <BookUser className="h-3.5 w-3.5" /> Saved List
                  </button>
                </div>

                {/* Recipient summary */}
                {recipientMode === "filter" ? (
                  <div className="mt-2 flex items-center justify-between rounded-lg border border-border px-3 py-2 bg-secondary/20">
                    <div className="flex items-center gap-1.5 text-sm">
                      <Users className="h-3.5 w-3.5 text-muted-foreground" />
                      {counting ? (
                        <span className="text-muted-foreground text-xs">Counting…</span>
                      ) : (
                        <span><strong className="text-foreground font-bold">{liveCount}</strong> <span className="text-muted-foreground text-xs">contacts</span></span>
                      )}
                      {activeFilterCount(filters) > 0 && (
                        <Badge variant="secondary" className="text-[9px] h-4 px-1.5">{activeFilterCount(filters)} filter{activeFilterCount(filters) > 1 ? "s" : ""}</Badge>
                      )}
                    </div>
                    <button onClick={() => setFilterOpen(v => !v)}
                      className="flex items-center gap-1 text-xs text-primary hover:underline font-medium">
                      <Filter className="h-3 w-3" /> {filterOpen ? "Hide" : "Edit Filters"}
                      {filterOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    </button>
                  </div>
                ) : (
                  <div className="mt-2">
                    {selectedList ? (
                      <div className="flex items-center justify-between rounded-lg border border-primary/30 bg-primary/5 px-3 py-2">
                        <div>
                          <p className="text-sm font-semibold text-foreground">{selectedList.name}</p>
                          <p className="text-xs text-muted-foreground">{selectedList.contact_count.toLocaleString()} contacts</p>
                        </div>
                        <button onClick={() => { setSelectedListId(null); setRecipientMode("filter"); }}
                          className="text-muted-foreground hover:text-destructive"><X className="h-4 w-4" /></button>
                      </div>
                    ) : (
                      <button onClick={() => setActiveTab("lists")}
                        className="w-full mt-2 flex items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border py-3 text-sm text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors">
                        <BookUser className="h-4 w-4" /> Choose a saved list →
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Message body */}
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Message</p>
                <textarea value={msgBody} onChange={(e) => setMsgBody(e.target.value)}
                  rows={5} placeholder="Type your message here…"
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
                <p className="text-[10px] text-muted-foreground mt-1">{msgBody.length} characters</p>
              </div>

              {/* Templates */}
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Quick Templates</p>
                <div className="flex flex-wrap gap-1.5">
                  {(Object.keys(TEMPLATES) as (keyof typeof TEMPLATES)[]).map((t) => (
                    <button key={t} onClick={() => setMsgBody(TEMPLATES[t])}
                      className="px-2.5 py-1 rounded-md border border-border bg-secondary/30 text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground capitalize transition-all">
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <Button onClick={handleSend}
                disabled={!msgBody.trim() || sending || recipientCount === 0}
                className="w-full font-semibold">
                {sending
                  ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Sending…</>
                  : <><Send className="h-4 w-4 mr-2" />Send to {recipientCount.toLocaleString()} recipients</>}
              </Button>
            </CardContent>
          </Card>

          {/* Right: Filter panel + History */}
          <div className="xl:col-span-3 flex flex-col gap-5">

            {/* Filter panel — collapsible when in compose/filter mode */}
            {recipientMode === "filter" && (
              <Card className={cn("shadow-sm transition-all", filterOpen ? "" : "hidden xl:block")}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="font-serif text-base flex items-center gap-2">
                      <Filter className="h-4 w-4 text-primary" /> Audience Filter
                      {activeFilterCount(filters) > 0 && (
                        <Badge className="text-[9px] h-4 px-1.5">{activeFilterCount(filters)} active</Badge>
                      )}
                    </CardTitle>
                    {activeFilterCount(filters) > 0 && liveCount > 0 && (
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5"
                        onClick={() => setIsSaveListOpen(true)}>
                        <Save className="h-3 w-3" /> Save as List
                      </Button>
                    )}
                  </div>
                  <CardDescription className="text-xs">Narrow your audience by combining multiple criteria.</CardDescription>
                </CardHeader>
                <CardContent>
                  <FilterPanel filters={filters} onChange={setFilters} liveCount={liveCount} counting={counting} />
                </CardContent>
              </Card>
            )}

            {/* Broadcast History */}
            <Card className="shadow-sm flex-1">
              <CardHeader className="bg-secondary/20 border-b border-border/50 pb-3">
                <CardTitle className="font-serif text-base">Broadcast History</CardTitle>
                <CardDescription>Log of all messages sent across channels</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {messagesLoading ? (
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="divide-y divide-border/50 max-h-80 overflow-y-auto">
                    {messagesData?.data?.map((msg) => {
                      const ch = getChannelMeta(msg.message_channel);
                      return (
                        <div key={msg.id} className="p-3.5 hover:bg-muted/30 transition-colors">
                          <div className="flex items-start gap-3 justify-between">
                            <div className="flex items-start gap-2.5">
                              <div className="bg-card border border-border shadow-sm p-2 rounded-lg shrink-0 mt-0.5">
                                {ch ? <ch.icon className={cn("h-4 w-4", ch.color)} /> : <Send className="h-4 w-4 text-muted-foreground" />}
                              </div>
                              <div className="space-y-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-bold text-[10px] uppercase tracking-wider bg-secondary px-2 py-0.5 rounded text-foreground">{msg.message_channel}</span>
                                  <span className="text-xs text-muted-foreground">→ <strong className="text-foreground">{msg.recipient_count.toLocaleString()}</strong> recipients</span>
                                  {(msg as any).recipient_type && (msg as any).recipient_type !== "filtered" && (msg as any).recipient_type !== "all" && (
                                    <span className="text-[10px] text-muted-foreground italic">{(msg as any).recipient_type}</span>
                                  )}
                                </div>
                                <p className="text-sm text-foreground leading-relaxed bg-primary/5 px-2.5 py-1.5 rounded-lg border border-primary/10 line-clamp-2">
                                  {msg.message_content}
                                </p>
                              </div>
                            </div>
                            <div className="shrink-0 text-xs text-muted-foreground text-right ml-2">
                              <div className="font-medium whitespace-nowrap">{format(new Date(msg.message_sent_at), "MMM d")}</div>
                              <div>{format(new Date(msg.message_sent_at), "h:mm a")}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {(!messagesData?.data || messagesData.data.length === 0) && (
                      <div className="p-10 text-center text-muted-foreground">
                        <Send className="h-10 w-10 text-muted-foreground/20 mx-auto mb-3" />
                        <p className="text-sm font-medium text-foreground">No broadcasts yet</p>
                        <p className="text-xs mt-1">Compose and send a message using the panel on the left.</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* ── RECIPIENT LISTS TAB ── */}
      {activeTab === "lists" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold font-serif">Saved Recipient Lists</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Reusable filtered audiences for targeted campaigns.</p>
            </div>
            <Button size="sm" className="gap-2" onClick={() => { setActiveTab("compose"); setFilterOpen(true); setRecipientMode("filter"); }}>
              <Plus className="h-4 w-4" /> Create New List
            </Button>
          </div>

          {listsLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : recipientLists.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="py-16 flex flex-col items-center text-center text-muted-foreground">
                <BookUser className="h-12 w-12 text-muted-foreground/20 mb-4" />
                <p className="text-base font-semibold text-foreground">No recipient lists yet</p>
                <p className="text-sm mt-1 max-w-sm">Use the filter panel in the Compose tab to define an audience, then save it as a named list.</p>
                <Button size="sm" className="mt-5 gap-2" onClick={() => { setActiveTab("compose"); setFilterOpen(true); }}>
                  <Filter className="h-4 w-4" /> Go to Filter Panel
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {recipientLists.map(list => {
                let parsedFilters: Record<string, any> = {};
                try { parsedFilters = JSON.parse(list.filters); } catch {}
                const isSelected = selectedListId === list.id;
                return (
                  <Card key={list.id} className={cn(
                    "shadow-sm transition-all cursor-pointer hover:shadow-md",
                    isSelected ? "border-primary/50 bg-primary/5 ring-1 ring-primary/30" : ""
                  )}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h4 className="font-bold text-sm font-serif text-foreground truncate">{list.name}</h4>
                          {list.description && <p className="text-xs text-muted-foreground mt-0.5 truncate">{list.description}</p>}
                        </div>
                        {isSelected && <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />}
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-primary">{(list.contact_count ?? 0).toLocaleString()}</span>
                        <span className="text-xs text-muted-foreground">contacts</span>
                      </div>

                      {Object.keys(parsedFilters).length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(parsedFilters).map(([k, v]) => (
                            <span key={k} className="px-1.5 py-0.5 rounded bg-secondary text-muted-foreground text-[9px] font-semibold border border-border">
                              {filterLabel(k, v)}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground italic">All contacts</p>
                      )}

                      <p className="text-[10px] text-muted-foreground">Created {format(new Date(list.created_at), "d MMM yyyy")}</p>

                      <div className="flex gap-2 pt-1">
                        <Button size="sm" className="flex-1 h-8 text-xs gap-1.5"
                          onClick={() => handleSelectList(list)}>
                          {isSelected ? <><CheckCircle2 className="h-3.5 w-3.5" /> Selected</> : <><Users className="h-3.5 w-3.5" /> Use for Message</>}
                        </Button>
                        <Button size="sm" variant="outline" className="h-8 w-8 p-0 text-destructive hover:bg-destructive/5 border-destructive/20"
                          disabled={deletingId === list.id}
                          onClick={() => handleDeleteList(list.id)}>
                          {deletingId === list.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Save List Dialog */}
      <SaveListDialog
        open={isSaveListOpen}
        onOpenChange={setIsSaveListOpen}
        filters={filters}
        liveCount={liveCount}
        onSaved={fetchLists}
      />
    </div>
  );
}
