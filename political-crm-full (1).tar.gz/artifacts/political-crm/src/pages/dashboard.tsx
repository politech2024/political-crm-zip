import { useGetStats } from "@workspace/api-client-react";
import { 
  Users, AlertTriangle, MessageSquare, MapPin, Loader2, ArrowRight, Heart, Cake, BarChart2, Activity
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Link } from "wouter";
import { formatPhone } from "@/lib/phone";

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

function SectionHeader({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description?: string }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div>
        <h2 className="text-sm font-semibold text-foreground tracking-wide uppercase">{title}</h2>
        {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
      </div>
      <div className="flex-1 h-px bg-border ml-2" />
    </div>
  );
}

export default function Dashboard() {
  const { data: statsResp, isLoading, isError } = useGetStats();

  if (isLoading) {
    return (
      <div className="flex h-[60vh] w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isError || !statsResp?.data) {
    return (
      <div className="flex h-[60vh] w-full items-center justify-center text-destructive">
        <p>Failed to load dashboard statistics.</p>
      </div>
    );
  }

  const stats = statsResp.data;

  const partyData = [
    { name: 'BJP', value: stats.party_breakdown.bjp },
    { name: 'Congress', value: stats.party_breakdown.congress },
    { name: 'AAP', value: stats.party_breakdown.aap },
    { name: 'Other', value: stats.party_breakdown.other },
  ].filter(d => d.value > 0);

  const casteData = [
    { name: 'General', count: stats.caste_breakdown.general },
    { name: 'OBC', count: stats.caste_breakdown.obc },
    { name: 'SC', count: stats.caste_breakdown.sc },
    { name: 'ST', count: stats.caste_breakdown.st },
  ];

  return (
    <div className="space-y-10">

      {/* ── KEY METRICS ─────────────────────────────────────────── */}
      <section>
        <SectionHeader icon={Users} title="Key Metrics" description="High-level counts across the system" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { title: "Contacts",      value: stats.total_contacts,         icon: Users,         color: "bg-blue-500/10 text-blue-600",   href: "/contacts" },
            { title: "Volunteers",    value: stats.volunteers,             icon: Heart,         color: "bg-violet-500/10 text-violet-600", href: "/volunteers" },
            { title: "Open Issues",   value: stats.open_issues,            icon: AlertTriangle, color: "bg-orange-500/10 text-orange-600", href: "/issues" },
            { title: "Messages",      value: stats.total_messages,         icon: MessageSquare, color: "bg-green-500/10 text-green-600",  href: "/messages" },
            { title: "Districts",     value: stats.districts_reached,      icon: MapPin,        color: "bg-purple-500/10 text-purple-600", href: "/assembly" },
            { title: "Seats Covered", value: stats.assembly_seats_covered, icon: MapPin,        color: "bg-teal-500/10 text-teal-600" },
          ].map((stat, i) => (
            <Card key={i} className="border-border shadow-sm hover:shadow-md transition-shadow">
              {stat.href ? (
                <Link href={stat.href}>
                  <CardContent className="p-4 cursor-pointer">
                    <div className={`w-8 h-8 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
                      <stat.icon className="h-4 w-4" />
                    </div>
                    <h3 className="text-2xl font-bold font-serif tracking-tight">{stat.value.toLocaleString()}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5 font-medium">{stat.title}</p>
                  </CardContent>
                </Link>
              ) : (
                <CardContent className="p-4">
                  <div className={`w-8 h-8 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
                    <stat.icon className="h-4 w-4" />
                  </div>
                  <h3 className="text-2xl font-bold font-serif tracking-tight">{stat.value.toLocaleString()}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5 font-medium">{stat.title}</p>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </section>

      {/* ── TODAY'S BIRTHDAYS ───────────────────────────────────── */}
      {(stats as any).today_birthdays?.length > 0 && (
        <section>
          <SectionHeader icon={Cake} title="Today's Birthdays" description="Contacts celebrating today" />
          <Card className="border-pink-200 bg-gradient-to-r from-pink-500/5 to-red-500/5 shadow-sm">
            <CardContent className="pt-5">
              <div className="flex flex-wrap gap-3">
                {(stats as any).today_birthdays.map((c: any) => (
                  <div key={c.id} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-background border border-pink-200 shadow-sm">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-red-500 flex items-center justify-center font-bold text-xs text-white shrink-0">
                      {(c.name ?? "?").charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{c.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{formatPhone(c.mobile)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* ── ANALYTICS ───────────────────────────────────────────── */}
      <section>
        <SectionHeader icon={BarChart2} title="Analytics" description="Political inclination and demographic breakdown" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif">Political Inclination</CardTitle>
              <CardDescription>Breakdown of contacts by supported party</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              {partyData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={partyData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {partyData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(val) => [`${val} Contacts`, 'Count']} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground">No party data available</div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif">Demographic Distribution</CardTitle>
              <CardDescription>Breakdown by major caste categories</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={casteData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                  <Tooltip cursor={{ fill: 'hsl(var(--secondary))' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={60} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* ── RECENT ACTIVITY ─────────────────────────────────────── */}
      <section>
        <SectionHeader icon={Activity} title="Recent Activity" description="Latest contacts added and issues raised" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div className="space-y-1">
                <CardTitle className="font-serif text-lg">Recent Contacts</CardTitle>
                <CardDescription>Latest additions to the database</CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild className="hover-elevate">
                <Link href="/contacts">View All <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mt-4">
                {stats.recent_contacts.slice(0, 5).map(c => (
                  <div key={c.id} className="flex items-center justify-between border-b border-border/50 pb-4 last:border-0 last:pb-0">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center font-serif font-bold text-primary">
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-sm text-foreground">{c.name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{formatPhone(c.mobile)} • {c.district || 'Unknown District'}</p>
                      </div>
                    </div>
                    {c.volunteer && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-[10px] font-medium bg-green-100 text-green-700">
                        Volunteer
                      </span>
                    )}
                  </div>
                ))}
                {stats.recent_contacts.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent contacts found.</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div className="space-y-1">
                <CardTitle className="font-serif text-lg">Active Issues</CardTitle>
                <CardDescription>Grievances requiring attention</CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild className="hover-elevate">
                <Link href="/issues">View All <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mt-4">
                {stats.recent_issues.slice(0, 5).map(i => (
                  <div key={i.id} className="flex flex-col border-b border-border/50 pb-4 last:border-0 last:pb-0 gap-2">
                    <div className="flex items-start justify-between">
                      <p className="font-medium text-sm text-foreground truncate pr-4">{i.issue_title}</p>
                      <span className={`shrink-0 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border
                        ${i.issue_status === 'new' ? 'bg-blue-50 text-blue-700 border-blue-200' : ''}
                        ${i.issue_status === 'in-progress' ? 'bg-orange-50 text-orange-700 border-orange-200' : ''}
                        ${i.issue_status === 'resolved' ? 'bg-green-50 text-green-700 border-green-200' : ''}
                      `}>
                        {i.issue_status.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{i.district || 'Unspecified location'}</span>
                      <span className="flex items-center gap-1">
                        <AlertTriangle className={`h-3 w-3 
                          ${i.issue_priority === 'high' ? 'text-destructive' : ''}
                          ${i.issue_priority === 'medium' ? 'text-orange-500' : ''}
                          ${i.issue_priority === 'low' ? 'text-green-500' : ''}
                        `} />
                        {i.issue_priority || 'Normal'}
                      </span>
                    </div>
                  </div>
                ))}
                {stats.recent_issues.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent issues logged.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

    </div>
  );
}
