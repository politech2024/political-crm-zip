import { useGetMessages, useGetStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Megaphone, MessageCircle, Mail, Facebook, Instagram, Twitter, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const CHANNEL_CONFIG = [
  { key: "whatsapp",  label: "WhatsApp",  icon: MessageCircle, color: "text-green-500",  bg: "bg-green-500/10",  bar: "bg-green-500" },
  { key: "email",     label: "Email",     icon: Mail,          color: "text-blue-500",   bg: "bg-blue-500/10",   bar: "bg-blue-500" },
  { key: "facebook",  label: "Facebook",  icon: Facebook,      color: "text-indigo-500", bg: "bg-indigo-500/10", bar: "bg-indigo-500" },
  { key: "instagram", label: "Instagram", icon: Instagram,     color: "text-pink-500",   bg: "bg-pink-500/10",   bar: "bg-pink-500" },
  { key: "twitter",   label: "Twitter/X", icon: Twitter,       color: "text-sky-500",    bg: "bg-sky-500/10",    bar: "bg-sky-500" },
];

const CAMPAIGN_CARDS = [
  {
    title: "Community Engagement",
    desc: "Ongoing community development initiative across the region.",
    gradient: "from-violet-500/20 to-blue-500/20",
    border: "border-violet-500/30",
    badge: "Active",
    badgeBg: "bg-violet-500/20 text-violet-400",
    reach: 850,
    engagement: "23%",
  },
  {
    title: "Development Works Update",
    desc: "Regular updates on infrastructure and development projects.",
    gradient: "from-green-500/20 to-emerald-500/20",
    border: "border-green-500/30",
    badge: "Active",
    badgeBg: "bg-green-500/20 text-green-400",
    reach: 1200,
    engagement: "31%",
  },
  {
    title: "Voter Awareness Drive",
    desc: "Educating voters about rights, processes, and upcoming elections.",
    gradient: "from-orange-500/20 to-red-500/20",
    border: "border-orange-500/30",
    badge: "Planned",
    badgeBg: "bg-orange-500/20 text-orange-400",
    reach: 0,
    engagement: "—",
  },
];

export default function Campaigns() {
  const { data: msgData, isLoading: msgLoading } = useGetMessages();
  const { data: statsData, isLoading: statsLoading } = useGetStats();

  const messages = msgData?.data ?? [];
  const stats = statsData?.data;

  const totalSent = messages.reduce((sum, m) => sum + (m.recipient_count ?? 0), 0);

  // Build channel breakdown from actual message history
  const channelCounts: Record<string, number> = {};
  messages.forEach((m) => {
    const ch = m.message_channel ?? "other";
    channelCounts[ch] = (channelCounts[ch] ?? 0) + (m.recipient_count ?? 0);
  });
  const maxChannelCount = Math.max(...Object.values(channelCounts), 1);

  if (msgLoading || statsLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold font-serif tracking-tight">Campaigns</h2>
        <p className="text-muted-foreground text-sm mt-1">Campaign analytics and performance overview.</p>
      </div>

      {/* Summary + Channel Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Summary */}
        <Card className="border-border shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif flex items-center gap-2">
              <Megaphone className="h-5 w-5 text-primary" /> Campaign Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { label: "Total Messages Sent", value: messages.length, color: "text-foreground" },
              { label: "Total Recipients Reached", value: totalSent.toLocaleString(), color: "text-primary" },
              { label: "Contacts in Database", value: (stats?.total_contacts ?? 0).toLocaleString(), color: "text-green-600" },
              { label: "Delivery Rate (est.)", value: "98%", color: "text-emerald-600" },
              { label: "Active Campaigns", value: CAMPAIGN_CARDS.filter(c => c.badge === "Active").length, color: "text-orange-600" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between p-3 rounded-xl bg-secondary/30 border border-border/50">
                <span className="text-sm text-muted-foreground">{item.label}</span>
                <span className={cn("text-xl font-bold font-serif", item.color)}>{item.value}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Channel Performance */}
        <Card className="border-border shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif">Channel Performance</CardTitle>
            <CardDescription>Recipients reached per channel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {CHANNEL_CONFIG.map((ch) => {
              const count = channelCounts[ch.key] ?? 0;
              const pct = messages.length > 0 ? Math.round((count / maxChannelCount) * 100) : 0;
              return (
                <div key={ch.key} className="flex items-center gap-3">
                  <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0", ch.bg)}>
                    <ch.icon className={cn("h-3.5 w-3.5", ch.color)} />
                  </div>
                  <span className="text-sm text-muted-foreground w-20 shrink-0">{ch.label}</span>
                  <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                    <div className={cn("h-full rounded-full transition-all duration-700", ch.bar)} style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-xs font-bold text-foreground w-8 text-right font-mono">{count > 0 ? count.toLocaleString() : "—"}</span>
                </div>
              );
            })}
            {messages.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">Send messages to see channel performance data.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Campaign cards */}
      <div>
        <h3 className="text-base font-semibold text-foreground mb-4">Active & Planned Campaigns</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CAMPAIGN_CARDS.map((camp) => (
            <div key={camp.title} className={cn(
              "rounded-xl border p-5 bg-gradient-to-br",
              camp.gradient, camp.border,
              "hover:-translate-y-0.5 hover:shadow-md transition-all duration-200"
            )}>
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-semibold text-foreground text-sm leading-tight pr-2">{camp.title}</h4>
                <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0", camp.badgeBg)}>
                  {camp.badge}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{camp.desc}</p>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Reach: <strong className="text-foreground">{camp.reach > 0 ? camp.reach.toLocaleString() : "—"}</strong></span>
                <span className="text-primary font-medium">{camp.engagement} engagement</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
