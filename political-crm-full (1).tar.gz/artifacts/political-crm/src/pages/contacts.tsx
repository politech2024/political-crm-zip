import { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import { useGetContacts, useDeleteContact, getGetContactsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Contact } from "@workspace/api-client-react/src/generated/api.schemas";
import { ContactFormDialog } from "@/components/contacts/contact-form-dialog";
import { ImportContactsDialog } from "@/components/contacts/import-contacts-dialog";
import { SmartFillDialog } from "@/components/contacts/smart-fill-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CG_DISTRICTS, CG_ASSEMBLIES, CG_LOK_SABHA } from "@/data/cg-assemblies";
import { getPartyOrg } from "@/data/party-organizations";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Search, Plus, Upload, Download, MoreHorizontal, Edit, Trash2,
  Loader2, SlidersHorizontal, X, Phone, MessageCircle, ExternalLink,
  CheckSquare, History, FileDown, Wand2
} from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { formatPhone, waLink } from "@/lib/phone";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const PARTY_LABELS: Record<string, string> = {
  bjp: "BJP", inc: "INC", congress: "INC", aap: "AAP", bsp: "BSP",
  jcc: "JCC", independent: "Independent", other: "Other",
};
const CASTE_LABELS: Record<string, string> = {
  general: "General", obc: "OBC", sc: "SC", st: "ST",
};

export default function Contacts() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [partyFilter, setPartyFilter] = useState("");
  const [frontalFilter, setFrontalFilter] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [casteFilter, setCasteFilter] = useState("");
  const [religionFilter, setReligionFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [lokSabhaFilter, setLokSabhaFilter] = useState("");
  const [districtFilter, setDistrictFilter] = useState("");
  const [assemblyFilter, setAssemblyFilter] = useState("");
  const [volunteerFilter, setVolunteerFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [leaderGroupFilter, setLeaderGroupFilter] = useState("");
  const [secondLeaderFilter, setSecondLeaderFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);
  const [confirmLastImport, setConfirmLastImport] = useState(false);
  const [lastImportInfo, setLastImportInfo] = useState<{ count: number; created_at: string } | null>(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  // Party org options — cascade from selected party
  const partyOrg = getPartyOrg(partyFilter);
  const hasFrontals = partyOrg.frontals.length > 0;
  const hasDepartments = partyOrg.departments.length > 0;
  const handlePartyChange = (val: string) => {
    setPartyFilter(val === "all" ? "" : val);
    setFrontalFilter("");
    setDepartmentFilter("");
  };

  // Cascading geography options
  const districtOptions = lokSabhaFilter
    ? [...new Set(CG_ASSEMBLIES.filter(a => a.lok_sabha === lokSabhaFilter).map(a => a.district))].sort()
    : CG_DISTRICTS;
  const assemblyOptions = districtFilter
    ? CG_ASSEMBLIES.filter(a => a.district === districtFilter && (lokSabhaFilter ? a.lok_sabha === lokSabhaFilter : true))
    : lokSabhaFilter
      ? CG_ASSEMBLIES.filter(a => a.lok_sabha === lokSabhaFilter)
      : CG_ASSEMBLIES;

  // Cascade setters
  const handleLokSabhaChange = (val: string) => {
    setLokSabhaFilter(val === "all" ? "" : val);
    setDistrictFilter("");
    setAssemblyFilter("");
  };
  const handleDistrictChange = (val: string) => {
    setDistrictFilter(val === "all" ? "" : val);
    setAssemblyFilter("");
  };

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isSmartFillOpen, setIsSmartFillOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);

  const activeFilterCount = [partyFilter, frontalFilter, departmentFilter, casteFilter, religionFilter, genderFilter, lokSabhaFilter, districtFilter, assemblyFilter, volunteerFilter, statusFilter, leaderGroupFilter, secondLeaderFilter].filter(v => v && v !== "all").length;

  const { data, isLoading } = useGetContacts({
    search: search || undefined,
    party: partyFilter && partyFilter !== "all" ? partyFilter : undefined,
    caste: casteFilter && casteFilter !== "all" ? casteFilter : undefined,
    district: districtFilter || undefined,
    assembly: assemblyFilter || undefined,
    volunteers: volunteerFilter === "yes" ? "true" : undefined,
    contact_status: statusFilter && statusFilter !== "all" ? statusFilter : undefined,
  } as any);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteMutation = useDeleteContact({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
        toast({ title: "Contact deleted successfully" });
      },
    },
  });

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this contact?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (contact: Contact) => {
    setEditingContact(contact);
    setIsFormOpen(true);
  };

  const clearFilters = () => {
    setPartyFilter(""); setFrontalFilter(""); setDepartmentFilter("");
    setCasteFilter(""); setReligionFilter(""); setGenderFilter("");
    setLokSabhaFilter(""); setDistrictFilter(""); setAssemblyFilter("");
    setVolunteerFilter(""); setStatusFilter(""); setLeaderGroupFilter(""); setSecondLeaderFilter("");
  };

  const handleExport = () => {
    const params = new URLSearchParams();
    if (partyFilter && partyFilter !== "all") params.set("party", partyFilter);
    if (casteFilter && casteFilter !== "all") params.set("caste", casteFilter);
    if (districtFilter) params.set("district", districtFilter);
    if (assemblyFilter) params.set("assembly", assemblyFilter);
    if (volunteerFilter === "yes") params.set("volunteers", "true");
    window.location.href = `${BASE}/api/contacts/export?${params.toString()}`;
  };

  const handleDownloadSample = () => {
    const headers = [
      "name", "mobile", "whatsapp", "email", "birthday",
      "gender", "caste", "religion",
      "political_party", "leader_group", "second_leader_group", "non_political_org",
      "village", "booth", "district", "constituency", "state",
      "social_media_facebook", "social_media_instagram", "social_media_twitter",
    ];
    const labels = [
      "Full Name *", "Mobile Number *", "WhatsApp Number", "Email", "Birthday (dd/mm/yyyy)",
      "Gender", "Caste", "Religion",
      "Political Party", "Leader / Group", "Second Leader / Group", "Non-Political Org",
      "Village / Ward", "Booth Number", "District", "Assembly Constituency", "Lok Sabha Constituency",
      "Facebook", "Instagram", "Twitter / X",
    ];
    const example = [
      "Ramesh Kumar Sahu", "+919876543210", "+919876543210", "ramesh@example.com", "15/08/1980",
      "male", "obc", "hindu",
      "bjp", "Raman Singh Group", "Ajay Chandrakar Group", "RSS",
      "Tikrapara", "42", "Raipur", "Raipur City South", "Raipur",
      "fb.com/ramesh", "", "@ramesh_x",
    ];
    const allowed = [
      "Any text", "+91XXXXXXXXXX (required)", "+91XXXXXXXXXX or blank", "email@example.com", "DD/MM/YYYY",
      "male / female / other", "general / obc / sc / st", "hindu / muslim / christian / sikh / other",
      "bjp / inc / aap / bsp / jcc / independent / other", "Any text", "Any text", "Any text",
      "Any text", "Number", "Any text", "Any text", "Any text",
      "URL or handle", "Handle", "Handle",
    ];

    const wb = XLSX.utils.book_new();

    // ── Sheet 1: Template (ready to fill) ──
    const templateData = [labels, example];
    const templateWs = XLSX.utils.aoa_to_sheet(templateData);

    // Style header row (bold + light blue background)
    const colCount = headers.length;
    for (let c = 0; c < colCount; c++) {
      const cellAddr = XLSX.utils.encode_cell({ r: 0, c });
      if (!templateWs[cellAddr]) continue;
      templateWs[cellAddr].s = {
        font: { bold: true, color: { rgb: "FFFFFF" } },
        fill: { fgColor: { rgb: "1D4ED8" } },
        alignment: { wrapText: true, vertical: "center" },
      };
    }
    // Set column widths
    templateWs["!cols"] = headers.map(() => ({ wch: 22 }));
    // Freeze top row
    templateWs["!freeze"] = { xSplit: 0, ySplit: 1 };
    XLSX.utils.book_append_sheet(wb, templateWs, "Import Template");

    // ── Sheet 2: Field Reference ──
    const refData = [
      ["Column Name (internal)", "Display Label", "Example Value", "Allowed Values / Notes"],
      ...headers.map((h, i) => [h, labels[i], example[i], allowed[i]]),
    ];
    const refWs = XLSX.utils.aoa_to_sheet(refData);
    refWs["!cols"] = [{ wch: 26 }, { wch: 26 }, { wch: 28 }, { wch: 46 }];
    for (let c = 0; c < 4; c++) {
      const cellAddr = XLSX.utils.encode_cell({ r: 0, c });
      if (refWs[cellAddr]) {
        refWs[cellAddr].s = {
          font: { bold: true, color: { rgb: "FFFFFF" } },
          fill: { fgColor: { rgb: "064E3B" } },
        };
      }
    }
    XLSX.utils.book_append_sheet(wb, refWs, "Field Reference");

    XLSX.writeFile(wb, "contacts_import_sample.xlsx");
  };

  // Fetch last import info on mount
  useEffect(() => {
    fetch(`${BASE}/api/contacts/import-batch/latest`)
      .then(r => r.json())
      .then(j => { if (j.data) setLastImportInfo(j.data); })
      .catch(() => {});
  }, []);

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length && filtered.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map(c => c.id)));
    }
  };

  const handleBulkDelete = async () => {
    setBulkDeleting(true);
    try {
      const res = await fetch(`${BASE}/api/contacts/bulk`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: Array.from(selectedIds) }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: `Deleted ${json.deleted} contact${json.deleted !== 1 ? "s" : ""}` });
        setSelectedIds(new Set());
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
      } else {
        toast({ title: "Delete failed", variant: "destructive" });
      }
    } catch {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setBulkDeleting(false);
      setConfirmBulkDelete(false);
    }
  };

  const handleDeleteLastImport = async () => {
    setBulkDeleting(true);
    try {
      const res = await fetch(`${BASE}/api/contacts/import-batch/latest`, { method: "DELETE" });
      const json = await res.json();
      if (json.success) {
        toast({ title: "Last import batch deleted successfully" });
        setLastImportInfo(null);
        queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
      } else {
        toast({ title: "Delete failed", variant: "destructive" });
      }
    } catch {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setBulkDeleting(false);
      setConfirmLastImport(false);
    }
  };

  const contacts = data?.data ?? [];
  // Client-side filters for fields not handled by the API
  const filtered = contacts
    .filter(c => genderFilter && genderFilter !== "all" ? c.gender === genderFilter : true)
    .filter(c => religionFilter ? c.religion === religionFilter : true)
    .filter(c => lokSabhaFilter ? c.lok_sabha_constituency?.toLowerCase() === lokSabhaFilter.toLowerCase() : true)
    .filter(c => frontalFilter ? (c as any).party_frontal === frontalFilter : true)
    .filter(c => departmentFilter ? (c as any).party_department === departmentFilter : true)
    .filter(c => leaderGroupFilter ? c.leader_group?.toLowerCase().includes(leaderGroupFilter.toLowerCase()) : true)
    .filter(c => secondLeaderFilter ? c.second_leader?.toLowerCase().includes(secondLeaderFilter.toLowerCase()) : true);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif tracking-tight">Contacts Directory</h2>
          <p className="text-muted-foreground text-sm mt-1">
            {isLoading ? "Loading…" : `${filtered.length} contact${filtered.length !== 1 ? "s" : ""}${activeFilterCount > 0 ? " (filtered)" : ""}`}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" className="bg-card shadow-sm" onClick={() => setIsImportOpen(true)}>
            <Upload className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Import</span>
            <span className="hidden sm:inline text-muted-foreground text-xs ml-1">CSV / Excel</span>
            <span className="sm:hidden">Import</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-foreground border border-dashed border-border hover:border-primary/40 hover:bg-primary/5 h-9 px-3"
            onClick={handleDownloadSample}
            title="Download a sample Excel template with all fields, an example row and a field reference sheet"
          >
            <FileDown className="mr-1.5 h-3.5 w-3.5" />
            <span className="text-xs">Sample .xlsx</span>
          </Button>
          {lastImportInfo && (
            <Button
              variant="outline"
              className="bg-card shadow-sm text-destructive border-destructive/30 hover:bg-destructive/5 hover:border-destructive/60"
              onClick={() => setConfirmLastImport(true)}
            >
              <History className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Delete Last Import ({lastImportInfo.count})</span>
              <span className="sm:hidden">Last Import</span>
            </Button>
          )}
          <Button variant="outline" className="bg-card shadow-sm" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" /> <span className="hidden sm:inline">Export CSV</span><span className="sm:hidden">Export</span>
          </Button>
          <Button
            variant="outline"
            className="bg-card shadow-sm border-primary/30 text-primary hover:bg-primary/5 hover:border-primary/50"
            onClick={() => setIsSmartFillOpen(true)}
            title="Scan all contacts and auto-fill empty fields from name and notes"
          >
            <Wand2 className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Smart Fill</span><span className="sm:hidden">Fill</span>
          </Button>
          <Button className="bg-primary text-primary-foreground shadow-md"
            onClick={() => { setEditingContact(null); setIsFormOpen(true); }}>
            <Plus className="mr-2 h-4 w-4" /> <span className="hidden sm:inline">Add Contact</span><span className="sm:hidden">Add</span>
          </Button>
        </div>
      </div>

      {/* Search + filter bar */}
      <div className="bg-card rounded-xl border border-border shadow-sm p-4 space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search name, mobile, village, constituency…"
              className="pl-9 bg-secondary/50"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <Button variant={showFilters ? "default" : "outline"} className="shrink-0 relative"
            onClick={() => setShowFilters(v => !v)}>
            <SlidersHorizontal className="h-4 w-4 mr-2" /> Filters
            {activeFilterCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </Button>
          {activeFilterCount > 0 && (
            <Button variant="ghost" size="icon" onClick={clearFilters} title="Clear all filters">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showFilters && (
          <div className="space-y-3 pt-1">

            {/* ── Section 1: Personal attributes ── */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-0.5">Personal Attributes</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <Select value={casteFilter} onValueChange={setCasteFilter}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Caste" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Castes</SelectItem>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="obc">OBC</SelectItem>
                    <SelectItem value="sc">SC</SelectItem>
                    <SelectItem value="st">ST</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={religionFilter} onValueChange={setReligionFilter}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Religion" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Religions</SelectItem>
                    <SelectItem value="hindu">Hindu</SelectItem>
                    <SelectItem value="muslim">Muslim</SelectItem>
                    <SelectItem value="christian">Christian</SelectItem>
                    <SelectItem value="sikh">Sikh</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={genderFilter} onValueChange={setGenderFilter}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Gender" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Genders</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={volunteerFilter} onValueChange={setVolunteerFilter}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Volunteer" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Contacts</SelectItem>
                    <SelectItem value="yes">Volunteers Only</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={statusFilter} onValueChange={v => setStatusFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-0.5">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
                  <Input
                    className="h-8 text-xs pl-7 bg-background"
                    placeholder="Leader Group contains…"
                    value={leaderGroupFilter}
                    onChange={e => setLeaderGroupFilter(e.target.value)}
                  />
                  {leaderGroupFilter && (
                    <button onClick={() => setLeaderGroupFilter("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
                  <Input
                    className="h-8 text-xs pl-7 bg-background"
                    placeholder="Second Leader contains…"
                    value={secondLeaderFilter}
                    onChange={e => setSecondLeaderFilter(e.target.value)}
                  />
                  {secondLeaderFilter && (
                    <button onClick={() => setSecondLeaderFilter("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* ── Section 2: Political affiliation (cascade: Party → Frontal → Department) ── */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-0.5">
                Political Affiliation
                <span className="font-normal normal-case text-muted-foreground/60 ml-1">— Party → Frontal / Wing → Department / Cell</span>
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {/* Party */}
                <Select value={partyFilter || "all"} onValueChange={handlePartyChange}>
                  <SelectTrigger className={cn("h-8 text-xs", partyFilter ? "bg-primary/5 border-primary/30" : "bg-background")}>
                    <SelectValue placeholder="All parties" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Parties</SelectItem>
                    <SelectItem value="bjp">BJP</SelectItem>
                    <SelectItem value="inc">INC (Congress)</SelectItem>
                    <SelectItem value="aap">AAP</SelectItem>
                    <SelectItem value="bsp">BSP</SelectItem>
                    <SelectItem value="sp">SP</SelectItem>
                    <SelectItem value="jcc">JCC (J)</SelectItem>
                    <SelectItem value="independent">Independent</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>

                {/* Frontal / Wing — shows only when party with frontals is selected */}
                <Select
                  value={frontalFilter || "all"}
                  onValueChange={v => { setFrontalFilter(v === "all" ? "" : v); setDepartmentFilter(""); }}
                  disabled={!hasFrontals}
                >
                  <SelectTrigger className={cn("h-8 text-xs", frontalFilter ? "bg-primary/5 border-primary/30" : "bg-background", !hasFrontals && "opacity-40 cursor-not-allowed")}>
                    <SelectValue placeholder={hasFrontals ? `Frontal / Wing (${partyOrg.frontals.length})` : "Select a party first"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    <SelectItem value="all">All Frontals / Wings</SelectItem>
                    {partyOrg.frontals.map(f => <SelectItem key={f} value={f} className="text-xs">{f}</SelectItem>)}
                  </SelectContent>
                </Select>

                {/* Department / Cell — shows only when party with departments is selected */}
                <Select
                  value={departmentFilter || "all"}
                  onValueChange={v => setDepartmentFilter(v === "all" ? "" : v)}
                  disabled={!hasDepartments}
                >
                  <SelectTrigger className={cn("h-8 text-xs", departmentFilter ? "bg-primary/5 border-primary/30" : "bg-background", !hasDepartments && "opacity-40 cursor-not-allowed")}>
                    <SelectValue placeholder={hasDepartments ? `Department / Cell (${partyOrg.departments.length})` : "Select a party first"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    <SelectItem value="all">All Departments / Cells</SelectItem>
                    {partyOrg.departments.map(d => <SelectItem key={d} value={d} className="text-xs">{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* ── Section 3: Geography cascade ── */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-0.5">
                Geography <span className="font-normal normal-case text-muted-foreground/60">— Lok Sabha → District → Assembly</span>
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <Select value={lokSabhaFilter || "all"} onValueChange={handleLokSabhaChange}>
                  <SelectTrigger className={cn("h-8 text-xs", lokSabhaFilter ? "bg-primary/5 border-primary/30" : "bg-background")}>
                    <SelectValue placeholder="All Lok Sabha seats" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Lok Sabha seats</SelectItem>
                    {CG_LOK_SABHA.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>

                <Select value={districtFilter || "all"} onValueChange={handleDistrictChange}>
                  <SelectTrigger className={cn("h-8 text-xs", districtFilter ? "bg-primary/5 border-primary/30" : "bg-background")}>
                    <SelectValue placeholder={lokSabhaFilter ? `Districts in ${lokSabhaFilter}` : "All districts"} />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    <SelectItem value="all">{lokSabhaFilter ? `All in ${lokSabhaFilter}` : "All districts"}</SelectItem>
                    {districtOptions.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>

                <Select value={assemblyFilter || "all"} onValueChange={v => setAssemblyFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className={cn("h-8 text-xs", assemblyFilter ? "bg-primary/5 border-primary/30" : "bg-background")}>
                    <SelectValue placeholder={
                      districtFilter ? `Assemblies in ${districtFilter}` :
                      lokSabhaFilter ? `Assemblies in ${lokSabhaFilter}` :
                      "All assemblies"
                    } />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    <SelectItem value="all">
                      {districtFilter ? `All in ${districtFilter}` : lokSabhaFilter ? `All in ${lokSabhaFilter}` : "All assemblies"}
                    </SelectItem>
                    {assemblyOptions.map(a => (
                      <SelectItem key={a.number} value={a.name}>#{a.number} {a.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-secondary/50">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-10 pl-4">
                    <Checkbox
                      checked={filtered.length > 0 && selectedIds.size === filtered.length}
                      onCheckedChange={toggleSelectAll}
                      aria-label="Select all"
                    />
                  </TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[160px]">Name</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[140px]">Number</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[130px] hidden sm:table-cell">District</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[150px] hidden md:table-cell">Assembly</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[140px] hidden lg:table-cell">Village / Booth</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[140px] hidden lg:table-cell">Party / Caste</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[80px] hidden xl:table-cell">Gender</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[120px] hidden xl:table-cell">Leader Group</TableHead>
                  <TableHead className="font-semibold text-foreground min-w-[100px] hidden xl:table-cell">Added</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((contact) => (
                  <TableRow
                    key={contact.id}
                    className={cn("hover:bg-muted/40 transition-colors", selectedIds.has(contact.id) && "bg-primary/5")}
                  >
                    {/* Checkbox */}
                    <TableCell className="pl-4 w-10">
                      <Checkbox
                        checked={selectedIds.has(contact.id)}
                        onCheckedChange={() => toggleSelect(contact.id)}
                        aria-label={`Select ${contact.name}`}
                        onClick={e => e.stopPropagation()}
                      />
                    </TableCell>
                    {/* Name */}
                    <TableCell>
                      <button onClick={() => navigate(`/contacts/${contact.id}`)}
                        className="font-medium text-foreground leading-tight hover:text-primary hover:underline underline-offset-2 text-left transition-colors">
                        {contact.name}
                      </button>
                      <div className="flex gap-1 mt-1 flex-wrap">
                        {contact.volunteer && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-green-100 text-green-700 uppercase tracking-wider">Volunteer</span>
                        )}
                        {contact.political_affiliation && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-blue-50 text-blue-600 border border-blue-100 truncate max-w-[100px]">{contact.political_affiliation}</span>
                        )}
                      </div>
                    </TableCell>

                    {/* Number */}
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm">
                        <Phone className="h-3 w-3 text-muted-foreground shrink-0" />
                        <span className="font-mono">{formatPhone(contact.mobile)}</span>
                      </div>
                      {contact.whatsapp_number && contact.whatsapp_number !== contact.mobile && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <MessageCircle className="h-3 w-3 shrink-0 text-green-600" />
                          <span className="font-mono">{formatPhone(contact.whatsapp_number)}</span>
                        </div>
                      )}
                      {contact.whatsapp_number === contact.mobile && (
                        <div className="flex items-center gap-1 mt-0.5">
                          <MessageCircle className="h-3 w-3 text-green-600" />
                          <span className="text-[10px] text-green-600 font-medium">Also WhatsApp</span>
                        </div>
                      )}
                      {contact.email && <div className="text-[10px] text-muted-foreground mt-0.5 truncate max-w-[130px]">{contact.email}</div>}
                    </TableCell>

                    {/* District */}
                    <TableCell className="hidden sm:table-cell">
                      <div className="text-sm font-medium">{contact.district || "—"}</div>
                      {contact.lok_sabha_constituency && (
                        <div className="text-[10px] text-muted-foreground/70 mt-0.5">LS: {contact.lok_sabha_constituency}</div>
                      )}
                    </TableCell>

                    {/* Assembly */}
                    <TableCell className="hidden md:table-cell">
                      <div className="text-sm font-medium leading-tight">{contact.constituency || "—"}</div>
                    </TableCell>

                    {/* Village / Booth */}
                    <TableCell className="hidden lg:table-cell">
                      <div className="text-sm font-medium">{contact.village_ward || "—"}</div>
                      {contact.booth_number && (
                        <div className="text-xs text-muted-foreground mt-0.5">Booth {contact.booth_number}</div>
                      )}
                    </TableCell>

                    {/* Party / Caste */}
                    <TableCell className="hidden lg:table-cell">
                      <div className="flex flex-wrap gap-1">
                        {contact.political_party && (
                          <span className={cn("inline-flex px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                            contact.political_party === "bjp" ? "bg-orange-100 text-orange-700" :
                            contact.political_party === "inc" || contact.political_party === "congress" ? "bg-blue-100 text-blue-700" :
                            contact.political_party === "aap" ? "bg-cyan-100 text-cyan-700" :
                            "bg-secondary text-secondary-foreground")}>
                            {PARTY_LABELS[contact.political_party] ?? contact.political_party}
                          </span>
                        )}
                        {contact.caste && (
                          <span className="inline-flex px-2 py-0.5 rounded border border-border text-[10px] uppercase text-muted-foreground">
                            {CASTE_LABELS[contact.caste] ?? contact.caste}
                          </span>
                        )}
                        {contact.religion && (
                          <span className="inline-flex px-1.5 py-0.5 rounded text-[10px] text-muted-foreground/70">
                            {contact.religion.charAt(0).toUpperCase() + contact.religion.slice(1)}
                          </span>
                        )}
                      </div>
                    </TableCell>

                    {/* Gender */}
                    <TableCell className="hidden xl:table-cell">
                      {contact.gender ? (
                        <span className={cn("text-xs font-medium capitalize",
                          contact.gender === "female" ? "text-pink-600" :
                          contact.gender === "male" ? "text-blue-600" : "text-muted-foreground")}>
                          {contact.gender}
                        </span>
                      ) : <span className="text-muted-foreground/40 text-xs">—</span>}
                    </TableCell>

                    {/* Leader Group */}
                    <TableCell className="hidden xl:table-cell">
                      <div className="text-xs text-foreground">{contact.leader_group || <span className="text-muted-foreground/40">—</span>}</div>
                      {contact.second_leader && <div className="text-[10px] text-muted-foreground">{contact.second_leader}</div>}
                    </TableCell>

                    {/* Added */}
                    <TableCell className="hidden xl:table-cell text-xs text-muted-foreground">
                      {format(new Date(contact.created_at), "d MMM yyyy")}
                      {contact.source && contact.source !== "manual" && (
                        <div className="text-[10px] mt-0.5 capitalize text-muted-foreground/60">{contact.source.replace("_", " ")}</div>
                      )}
                    </TableCell>

                    {/* Actions */}
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[160px]">
                          <DropdownMenuItem onClick={() => navigate(`/contacts/${contact.id}`)} className="cursor-pointer font-medium">
                            <ExternalLink className="mr-2 h-4 w-4 text-primary" /> View Profile
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleEdit(contact)} className="cursor-pointer">
                            <Edit className="mr-2 h-4 w-4 text-blue-600" /> Edit Details
                          </DropdownMenuItem>
                          {contact.whatsapp_number && (
                            <DropdownMenuItem asChild className="cursor-pointer">
                              <a href={waLink(contact.whatsapp_number)} target="_blank" rel="noreferrer">
                                <MessageCircle className="mr-2 h-4 w-4 text-green-600" /> WhatsApp
                              </a>
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDelete(contact.id)}
                            className="cursor-pointer text-destructive focus:text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" /> Delete Record
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={10} className="h-32 text-center text-muted-foreground">
                      {isLoading ? "Loading contacts…" : "No contacts found matching your filters."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Floating bulk-action bar */}
      {selectedIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-foreground text-background rounded-2xl shadow-2xl px-5 py-3 border border-border/20 animate-in slide-in-from-bottom-4">
          <CheckSquare className="h-4 w-4 shrink-0" />
          <span className="text-sm font-semibold">
            {selectedIds.size} contact{selectedIds.size !== 1 ? "s" : ""} selected
          </span>
          <div className="h-4 w-px bg-background/30" />
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-3 text-background/70 hover:text-background hover:bg-background/10"
            onClick={() => setSelectedIds(new Set())}
          >
            Deselect all
          </Button>
          <Button
            size="sm"
            className="h-7 px-3 bg-destructive hover:bg-destructive/90 text-white"
            onClick={() => setConfirmBulkDelete(true)}
            disabled={bulkDeleting}
          >
            {bulkDeleting ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Trash2 className="h-3.5 w-3.5 mr-1.5" />}
            Delete {selectedIds.size}
          </Button>
        </div>
      )}

      {/* Confirm bulk delete */}
      <AlertDialog open={confirmBulkDelete} onOpenChange={setConfirmBulkDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedIds.size} contacts?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {selectedIds.size} selected contact{selectedIds.size !== 1 ? "s" : ""}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDelete}
              disabled={bulkDeleting}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              {bulkDeleting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Delete {selectedIds.size} contacts
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirm delete last import */}
      <AlertDialog open={confirmLastImport} onOpenChange={setConfirmLastImport}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete last import?</AlertDialogTitle>
            <AlertDialogDescription>
              {lastImportInfo
                ? `This will permanently delete ${lastImportInfo.count} contacts from the import on ${format(new Date(lastImportInfo.created_at), "d MMM yyyy 'at' h:mm a")}. This action cannot be undone.`
                : "This will permanently delete all contacts from the last import batch."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteLastImport}
              disabled={bulkDeleting}
              className="bg-destructive hover:bg-destructive/90 text-white"
            >
              {bulkDeleting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Delete import
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <ContactFormDialog
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        contact={editingContact}
      />
      <ImportContactsDialog
        open={isImportOpen}
        onOpenChange={setIsImportOpen}
      />
      <SmartFillDialog
        open={isSmartFillOpen}
        onOpenChange={setIsSmartFillOpen}
        contacts={data?.data ?? []}
        onApplied={() => {
          queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
        }}
      />
    </div>
  );
}
