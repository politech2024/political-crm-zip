import { useState } from "react";
import { useGetIssues, useDeleteIssue, getGetIssuesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Issue } from "@workspace/api-client-react/src/generated/api.schemas";
import { IssueFormDialog } from "@/components/issues/issue-form-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { Plus, MoreHorizontal, Edit, Trash2, Loader2, AlertTriangle, Search, X, SlidersHorizontal } from "lucide-react";
import { format } from "date-fns";
import { CG_DISTRICTS, CG_ASSEMBLIES } from "@/data/cg-assemblies";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  "water","roads","electricity","health","education","agriculture",
  "employment","ration","pension","forest","law","other",
];

export default function Issues() {
  const [statusFilter, setStatusFilter] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("");
  const [districtFilter, setDistrictFilter] = useState("");
  const [assemblyFilter, setAssemblyFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingIssue, setEditingIssue] = useState<Issue | null>(null);

  const { data: rawData, isLoading } = useGetIssues({
    status: statusFilter && statusFilter !== "all" ? statusFilter : undefined,
    priority: priorityFilter && priorityFilter !== "all" ? priorityFilter : undefined,
  });

  // Client-side filters for district/assembly/category/search
  const issues = (rawData?.data ?? []).filter(issue => {
    if (districtFilter && districtFilter !== "all") {
      if (!issue.district?.toLowerCase().includes(districtFilter.toLowerCase())) return false;
    }
    if (assemblyFilter && assemblyFilter !== "all") {
      if (!issue.constituency?.toLowerCase().includes(assemblyFilter.toLowerCase())) return false;
    }
    if (categoryFilter && categoryFilter !== "all") {
      if (issue.category !== categoryFilter) return false;
    }
    if (search) {
      const s = search.toLowerCase();
      if (
        !issue.issue_title?.toLowerCase().includes(s) &&
        !issue.contact_name?.toLowerCase().includes(s) &&
        !issue.district?.toLowerCase().includes(s) &&
        !issue.constituency?.toLowerCase().includes(s) &&
        !issue.issue_description?.toLowerCase().includes(s)
      ) return false;
    }
    return true;
  });

  const assemblyOptions = districtFilter && districtFilter !== "all"
    ? CG_ASSEMBLIES.filter(a => a.district === districtFilter)
    : CG_ASSEMBLIES;

  const activeFilterCount = [statusFilter, priorityFilter, districtFilter, assemblyFilter, categoryFilter].filter(v => v && v !== "all").length;

  const clearFilters = () => {
    setStatusFilter(""); setPriorityFilter(""); setDistrictFilter("");
    setAssemblyFilter(""); setCategoryFilter(""); setSearch("");
  };

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteMutation = useDeleteIssue({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetIssuesQueryKey() });
        toast({ title: "Issue deleted successfully" });
      }
    }
  });

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this issue record?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (issue: Issue) => {
    setEditingIssue(issue);
    setIsFormOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif tracking-tight">Issue Tracking</h2>
          <p className="text-muted-foreground text-sm mt-1">Monitor and resolve constituent grievances.</p>
        </div>
        <Button
          className="bg-primary text-primary-foreground hover-elevate shadow-md"
          onClick={() => { setEditingIssue(null); setIsFormOpen(true); }}
        >
          <Plus className="mr-2 h-4 w-4" /> Log New Issue
        </Button>
      </div>

      {/* Filter bar */}
      <div className="bg-card p-4 rounded-xl border border-border shadow-sm space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search title, reporter, location…"
              className="pl-9 bg-secondary/50"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            className="shrink-0 relative"
            onClick={() => setShowFilters(v => !v)}
          >
            <SlidersHorizontal className="h-4 w-4 mr-2" /> Filters
            {activeFilterCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </Button>
          {(activeFilterCount > 0 || search) && (
            <Button variant="ghost" size="icon" onClick={clearFilters} title="Clear all filters">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showFilters && (
          <div className="space-y-2 pt-1">
            {/* Row 1: Status + Priority + Category */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Issue State</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <Select value={statusFilter} onValueChange={v => setStatusFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={v => setPriorityFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Priority" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={categoryFilter} onValueChange={v => setCategoryFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Row 2: Geography */}
            <div className="rounded-lg border border-border/60 bg-secondary/20 p-2.5 space-y-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Geography</p>
              <div className="grid grid-cols-2 gap-2">
                <Select value={districtFilter} onValueChange={v => { setDistrictFilter(v === "all" ? "" : v); setAssemblyFilter(""); }}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="District" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Districts</SelectItem>
                    {CG_DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={assemblyFilter} onValueChange={v => setAssemblyFilter(v === "all" ? "" : v)}>
                  <SelectTrigger className="bg-background h-8 text-xs"><SelectValue placeholder="Assembly" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Assemblies</SelectItem>
                    {assemblyOptions.map(a => <SelectItem key={a.number} value={a.name}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Table>
            <TableHeader className="bg-secondary/50">
              <TableRow className="hover:bg-transparent">
                <TableHead className="font-semibold text-foreground w-[40%]">Issue Details</TableHead>
                <TableHead className="font-semibold text-foreground">Status & Priority</TableHead>
                <TableHead className="font-semibold text-foreground hidden md:table-cell">Location</TableHead>
                <TableHead className="font-semibold text-foreground hidden lg:table-cell">Date Logged</TableHead>
                <TableHead className="text-right font-semibold text-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {issues.map((issue) => (
                <TableRow key={issue.id} className="hover:bg-muted/50 transition-colors group">
                  <TableCell>
                    <div className="font-medium text-foreground text-base mb-1">{issue.issue_title}</div>
                    {issue.contact_name && (
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        Reported by: <span className="font-medium text-foreground/80">{issue.contact_name}</span>
                      </div>
                    )}
                    {(issue as any).category && (
                      <span className="inline-flex mt-1 items-center text-[10px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground capitalize">
                        {(issue as any).category}
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col items-start gap-2">
                      <span className={cn(
                        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border",
                        issue.issue_status === "new" && "bg-blue-50 text-blue-700 border-blue-200",
                        issue.issue_status === "in-progress" && "bg-orange-50 text-orange-700 border-orange-200",
                        issue.issue_status === "resolved" && "bg-green-50 text-green-700 border-green-200",
                        issue.issue_status === "closed" && "bg-gray-50 text-gray-600 border-gray-200",
                      )}>
                        {issue.issue_status.replace("-", " ").toUpperCase()}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs font-medium">
                        <AlertTriangle className={cn(
                          "h-3.5 w-3.5",
                          issue.issue_priority === "urgent" && "text-rose-600",
                          issue.issue_priority === "high" && "text-destructive",
                          issue.issue_priority === "medium" && "text-amber-500",
                          issue.issue_priority === "low" && "text-emerald-500",
                        )} />
                        <span className="capitalize">{issue.issue_priority || "Normal"}</span>
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <div className="text-sm font-medium">{issue.constituency || "—"}</div>
                    <div className="text-xs text-muted-foreground">{issue.district || "—"}</div>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                    {format(new Date(issue.created_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-[160px]">
                        <DropdownMenuItem onClick={() => handleEdit(issue)} className="cursor-pointer">
                          <Edit className="mr-2 h-4 w-4 text-blue-600" /> Update Status
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => handleDelete(issue.id)}
                          className="cursor-pointer text-destructive focus:text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" /> Delete Issue
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
              {issues.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                    No issues found matching your criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>

      <IssueFormDialog
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        issue={editingIssue}
      />
    </div>
  );
}
