import { useState, useEffect, useMemo, useRef } from "react";
import { useGetContacts, useGetIssues } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Building2, Users, AlertTriangle, TrendingUp, MapPin,
  Search, ChevronRight, Loader2, Edit, Plus, User,
  BarChart3, Activity, Shield, Lightbulb, AlertCircle, CheckCircle,
} from "lucide-react";
import { CG_ASSEMBLIES, CG_DISTRICTS, CG_LOK_SABHA, getAssemblyByName, getAssembliesByDistrict, getAssembliesByLokSabha } from "@/data/cg-assemblies";
import { cn } from "@/lib/utils";
import { formatPhone } from "@/lib/phone";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const SECTIONS = [
  { id: "basic",    label: "Basic Info",     icon: Building2 },
  { id: "electoral",label: "Electoral",      icon: Users },
  { id: "mla",      label: "MLA",            icon: User },
  { id: "booths",   label: "Booths",         icon: MapPin },
  { id: "contacts", label: "Contacts",       icon: Users },
  { id: "issues",   label: "Issues",         icon: AlertTriangle },
  { id: "performance", label: "Performance", icon: TrendingUp },
  { id: "insights", label: "Insights",       icon: Lightbulb },
];

const BOOTH_STATUSES = [
  { value: "strong",   label: "Strong",   color: "bg-orange-400", border: "border-orange-400" },
  { value: "moderate", label: "Moderate", color: "bg-yellow-400", border: "border-yellow-400" },
  { value: "swing",    label: "Swing",    color: "bg-blue-400",   border: "border-blue-400" },
  { value: "risk",     label: "At Risk",  color: "bg-red-500",    border: "border-red-500" },
  { value: "no_data",  label: "No Data",  color: "bg-gray-200",   border: "border-gray-300" },
];

interface AssemblyData {
  reservation_type?: string; area_type?: string;
  total_voters?: number; male_voters?: number; female_voters?: number; other_voters?: number;
  total_booths?: number; urban_booths?: number; rural_booths?: number; sensitive_booths?: number;
  mla_name?: string; mla_party?: string; winning_margin?: number;
  winning_margin_pct?: number; vote_share_pct?: number; term_since?: number;
  previous_mla_name?: string; linked_mp?: string;
  party_strength_pct?: number; org_score?: number; campaign_score?: number;
  ground_score?: number; media_score?: number; d2d_coverage_pct?: number;
  issue_resolution_rate?: number; sentiment_positive?: number;
  sentiment_neutral?: number; sentiment_negative?: number;
  d2d_villages_covered?: number; d2d_villages_total?: number;
}

interface BoothRecord {
  id: string; assembly_name: string; booth_number: string; village_ward?: string;
  status?: string; total_voters?: number; male_voters?: number;
  female_voters?: number; worker_name?: string; notes?: string;
}

const emptyAsmData = (): AssemblyData => ({});

function Pct({ value, color = "bg-primary" }: { value: number; color?: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 rounded-full bg-secondary overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", color)} style={{ width: `${Math.min(100, value)}%` }} />
      </div>
      <span className="text-xs font-mono text-muted-foreground w-9 text-right">{value.toFixed(1)}%</span>
    </div>
  );
}

function ScoreRing({ score, label }: { score: number; label: string }) {
  const pct = Math.min(100, Math.max(0, score));
  const r = 22, circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  const color = pct >= 70 ? "#22c55e" : pct >= 40 ? "#f59e0b" : "#ef4444";
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width="56" height="56">
        <circle cx="28" cy="28" r={r} fill="none" stroke="#e5e7eb" strokeWidth="4" />
        <circle cx="28" cy="28" r={r} fill="none" stroke={color} strokeWidth="4"
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round" transform="rotate(-90 28 28)" />
        <text x="28" y="32" textAnchor="middle" fontSize="11" fontWeight="bold" fill={color}>{pct}</text>
      </svg>
      <span className="text-[10px] text-muted-foreground text-center leading-tight">{label}</span>
    </div>
  );
}

export default function AssemblyDashboard() {
  const [browseMode, setBrowseMode] = useState<"district" | "loksabha">("district");
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [selectedLokSabha, setSelectedLokSabha] = useState("");
  const [selectedAssembly, setSelectedAssembly] = useState("");
  const [asmData, setAsmData] = useState<AssemblyData>(emptyAsmData());
  const [booths, setBooths] = useState<BoothRecord[]>([]);
  const [loadingAsm, setLoadingAsm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSection, setActiveSection] = useState("basic");
  const [editModal, setEditModal] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Record<string, any>>({});
  const [boothModal, setBoothModal] = useState(false);
  const [boothForm, setBoothForm] = useState<Record<string, any>>({});
  const [savingEdit, setSavingEdit] = useState(false);
  const [hoveredBooth, setHoveredBooth] = useState<BoothRecord | null>(null);
  const { toast } = useToast();
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const { data: contactsData } = useGetContacts({});
  const { data: issuesData } = useGetIssues({});
  const allContacts = contactsData?.data ?? [];
  const allIssues = issuesData?.data ?? [];

  const asm = selectedAssembly ? getAssemblyByName(selectedAssembly) : null;
  const asmContacts = allContacts.filter(c => c.constituency === selectedAssembly);
  const asmIssues = allIssues.filter(i => i.constituency === selectedAssembly);

  useEffect(() => {
    if (!selectedAssembly) return;
    setLoadingAsm(true);
    setAsmData(emptyAsmData());
    setBooths([]);
    Promise.all([
      fetch(`${BASE}/api/assembly-data/${encodeURIComponent(selectedAssembly)}`).then(r => r.json()),
      fetch(`${BASE}/api/booth-records/${encodeURIComponent(selectedAssembly)}`).then(r => r.json()),
    ]).then(([asmRes, boothRes]) => {
      if (asmRes.success && asmRes.data) setAsmData(asmRes.data);
      if (boothRes.success) setBooths(boothRes.data);
    }).catch(() => {}).finally(() => setLoadingAsm(false));
  }, [selectedAssembly]);

  const scrollTo = (id: string) => {
    setActiveSection(id);
    sectionRefs.current[id]?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const saveAsmData = async (updates: Partial<AssemblyData>) => {
    setSavingEdit(true);
    try {
      const r = await fetch(`${BASE}/api/assembly-data/${encodeURIComponent(selectedAssembly)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const j = await r.json();
      if (j.success) {
        setAsmData(d => ({ ...d, ...updates }));
        toast({ title: "Saved" });
        setEditModal(null);
      } else {
        toast({ title: "Error", description: j.error, variant: "destructive" });
      }
    } catch (e: any) {
      toast({ title: "Network error", description: e.message, variant: "destructive" });
    } finally { setSavingEdit(false); }
  };

  const saveBooth = async () => {
    if (!boothForm.booth_number) {
      toast({ title: "Booth number required", variant: "destructive" }); return;
    }
    setSavingEdit(true);
    try {
      const r = await fetch(`${BASE}/api/booth-records`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assembly_name: selectedAssembly, ...boothForm }),
      });
      const j = await r.json();
      if (j.success) {
        toast({ title: "Booth updated" });
        setBoothModal(false);
        setBoothForm({});
        const res = await fetch(`${BASE}/api/booth-records/${encodeURIComponent(selectedAssembly)}`);
        const br = await res.json();
        if (br.success) setBooths(br.data);
      }
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSavingEdit(false); }
  };

  const openEdit = (section: string) => {
    const base: Record<string, any> = {};
    if (section === "electoral") {
      ["reservation_type","area_type","total_voters","male_voters","female_voters",
       "other_voters","total_booths","urban_booths","rural_booths","sensitive_booths"].forEach(k => {
        base[k] = (asmData as any)[k] ?? "";
      });
    } else if (section === "mla") {
      ["mla_name","mla_party","winning_margin","winning_margin_pct","vote_share_pct",
       "term_since","previous_mla_name","linked_mp"].forEach(k => {
        base[k] = (asmData as any)[k] ?? "";
      });
    } else if (section === "performance") {
      ["party_strength_pct","org_score","campaign_score","ground_score","media_score",
       "d2d_coverage_pct","issue_resolution_rate","d2d_villages_covered","d2d_villages_total",
       "sentiment_positive","sentiment_neutral","sentiment_negative"].forEach(k => {
        base[k] = (asmData as any)[k] ?? "";
      });
    }
    setEditForm(base);
    setEditModal(section);
  };

  const boothStatusColor = (s?: string) =>
    BOOTH_STATUSES.find(b => b.value === (s || "no_data"))?.color ?? "bg-gray-200";

  const vol = asmContacts.filter(c => c.volunteer).length;
  const leaders = asmContacts.filter(c => c.leader_group).length;
  const totalV = asmData.total_voters ?? 0;
  const maleV = asmData.male_voters ?? 0;
  const femaleV = asmData.female_voters ?? 0;
  const otherV = asmData.other_voters ?? 0;
  const boothCovPct = asmData.total_booths
    ? (booths.filter(b => b.status !== "no_data").length / asmData.total_booths) * 100 : 0;

  const searchResults = useMemo(() => {
    if (!searchQuery || searchQuery.length < 2) return null;
    const q = searchQuery.toLowerCase();
    return {
      contacts: asmContacts.filter(c => c.name?.toLowerCase().includes(q) || c.mobile?.includes(q)).slice(0, 5),
      issues: asmIssues.filter(i => i.issue_title?.toLowerCase().includes(q)).slice(0, 5),
    };
  }, [searchQuery, asmContacts, asmIssues]);

  const insights = useMemo(() => {
    if (!selectedAssembly) return { risks: [], actions: [], positives: [] };
    const risks: string[] = [];
    const actions: string[] = [];
    const positives: string[] = [];
    const noWorkerBooths = booths.filter(b => !b.worker_name).length;
    if (noWorkerBooths > 0) risks.push(`${noWorkerBooths} booth${noWorkerBooths > 1 ? "s" : ""} have no assigned worker`);
    const urgentIssues = asmIssues.filter(i => i.issue_priority === "urgent" && i.issue_status !== "resolved").length;
    if (urgentIssues > 0) risks.push(`${urgentIssues} urgent issue${urgentIssues > 1 ? "s" : ""} unresolved`);
    if (boothCovPct < 50 && asmData.total_booths) risks.push("Less than half of booths have data");
    if (asmContacts.length < 10) actions.push("Add more contacts to build your network here");
    if (!asmData.total_voters) actions.push("Add electoral data for accurate insights");
    if (asmContacts.filter(c => ["leader","president","in_charge"].some(r => c.leader_group?.includes(r))).length < 5) actions.push("Strengthen organisational structure");
    if (asmContacts.length >= 20) positives.push(`Strong network with ${asmContacts.length} contacts`);
    if (vol >= 5) positives.push(`${vol} active volunteers identified`);
    if (asmData.org_score && asmData.org_score >= 70) positives.push("Organisation score is strong");
    return { risks, actions, positives };
  }, [selectedAssembly, booths, asmIssues, asmData, asmContacts, boothCovPct, vol]);

  const ef = (k: string, v: any) => setEditForm(f => ({ ...f, [k]: v }));

  const filteredAssemblies = browseMode === "loksabha"
    ? (selectedLokSabha ? getAssembliesByLokSabha(selectedLokSabha) : [])
    : (selectedDistrict ? getAssembliesByDistrict(selectedDistrict) : []);

  if (!selectedAssembly) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold font-serif tracking-tight">Assembly Dashboard</h2>
          <p className="text-muted-foreground text-sm mt-1">Browse by Lok Sabha or District, then select a constituency.</p>
        </div>

        {/* Mode Toggle */}
        <div className="grid grid-cols-2 gap-3 max-w-sm">
          <button
            onClick={() => { setBrowseMode("loksabha"); setSelectedDistrict(""); }}
            className={cn(
              "flex flex-col items-center gap-2 rounded-xl border-2 py-5 px-4 transition-all",
              browseMode === "loksabha"
                ? "border-primary bg-primary/5 text-primary shadow-sm"
                : "border-border bg-background text-muted-foreground hover:border-primary/40 hover:bg-secondary/50"
            )}>
            <MapPin className="h-7 w-7" />
            <span className="text-sm font-semibold">Lok Sabha</span>
            <span className="text-[11px] text-muted-foreground">11 constituencies</span>
          </button>
          <button
            onClick={() => { setBrowseMode("district"); setSelectedLokSabha(""); }}
            className={cn(
              "flex flex-col items-center gap-2 rounded-xl border-2 py-5 px-4 transition-all",
              browseMode === "district"
                ? "border-primary bg-primary/5 text-primary shadow-sm"
                : "border-border bg-background text-muted-foreground hover:border-primary/40 hover:bg-secondary/50"
            )}>
            <Building2 className="h-7 w-7" />
            <span className="text-sm font-semibold">District</span>
            <span className="text-[11px] text-muted-foreground">33 districts</span>
          </button>
        </div>

        {/* Filter & Assembly List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          {/* Left: Filter selector */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="font-serif text-base flex items-center gap-2">
                {browseMode === "loksabha" ? <><MapPin className="h-4 w-4 text-primary" /> Select Lok Sabha Seat</> : <><Building2 className="h-4 w-4 text-primary" /> Select District</>}
              </CardTitle>
              <CardDescription>
                {browseMode === "loksabha" ? "Choose one of the 11 CG parliamentary constituencies" : "Choose one of the 33 CG districts"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {browseMode === "loksabha" ? (
                CG_LOK_SABHA.map(ls => (
                  <button key={ls} onClick={() => setSelectedLokSabha(ls)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2.5 rounded-lg border text-sm font-medium transition-all",
                      selectedLokSabha === ls
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:bg-secondary/60 text-foreground"
                    )}>
                    <span>{ls}</span>
                    <span className={cn("text-xs", selectedLokSabha === ls ? "text-primary-foreground/70" : "text-muted-foreground")}>
                      {getAssembliesByLokSabha(ls).length} seats
                    </span>
                  </button>
                ))
              ) : (
                CG_DISTRICTS.map(d => (
                  <button key={d} onClick={() => setSelectedDistrict(d)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2.5 rounded-lg border text-sm font-medium transition-all",
                      selectedDistrict === d
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:bg-secondary/60 text-foreground"
                    )}>
                    <span>{d}</span>
                    <span className={cn("text-xs", selectedDistrict === d ? "text-primary-foreground/70" : "text-muted-foreground")}>
                      {getAssembliesByDistrict(d).length} seats
                    </span>
                  </button>
                ))
              )}
            </CardContent>
          </Card>

          {/* Right: Assembly list */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="font-serif text-base flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" /> Assembly Constituencies
              </CardTitle>
              <CardDescription>
                {filteredAssemblies.length > 0
                  ? `${filteredAssemblies.length} seats — click to open`
                  : browseMode === "loksabha" ? "Select a Lok Sabha seat on the left" : "Select a district on the left"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {filteredAssemblies.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3">
                  <Building2 className="h-10 w-10 text-muted-foreground/20" />
                  <p className="text-sm">No constituency selected</p>
                </div>
              ) : (
                filteredAssemblies.map(a => (
                  <button key={a.name} onClick={() => setSelectedAssembly(a.name)}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-border bg-background hover:bg-primary/5 hover:border-primary/40 transition-all group text-left">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono text-muted-foreground w-6 shrink-0">{a.number}</span>
                      <div>
                        <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{a.name}</p>
                        <p className="text-[11px] text-muted-foreground">{browseMode === "loksabha" ? a.district : a.lok_sabha + " LS"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {a.reservation && a.reservation !== "GEN" && (
                        <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded",
                          a.reservation === "ST" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700")}>
                          {a.reservation}
                        </span>
                      )}
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </button>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-2xl font-bold font-serif tracking-tight">{selectedAssembly}</h2>
            {asm && (
              <>
                <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full", asm.reservation === "ST" ? "bg-green-100 text-green-700" : asm.reservation === "SC" ? "bg-blue-100 text-blue-700" : "bg-secondary text-muted-foreground")}>
                  {asm.reservation}
                </span>
                {asmData.mla_party && (
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-orange-100 text-orange-700">
                    {asmData.mla_party?.toUpperCase()}
                  </span>
                )}
              </>
            )}
          </div>
          {asm && (
            <p className="text-sm text-muted-foreground mt-1">
              #{asm.number} · {asm.district} · {asm.lok_sabha} LS · State: Chhattisgarh
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select className="h-9 rounded-md border border-input bg-background px-3 text-sm"
            value={selectedAssembly} onChange={e => setSelectedAssembly(e.target.value)}>
            {CG_ASSEMBLIES.map(a => <option key={a.name} value={a.name}>{a.number}. {a.name}</option>)}
          </select>
          <Button size="sm" variant="outline" onClick={() => setSelectedAssembly("")}>Change</Button>
        </div>
      </div>

      {/* Section Nav */}
      <div className="flex overflow-x-auto gap-1 pb-1 no-scrollbar">
        {SECTIONS.map(s => (
          <button key={s.id} onClick={() => scrollTo(s.id)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap border transition-all",
              activeSection === s.id
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background border-border text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
            )}>
            <s.icon className="h-3 w-3" /> {s.label}
          </button>
        ))}
      </div>

      {/* Global Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search contacts, issues in this assembly (min 2 chars)…"
          className="pl-9 bg-card border-border"
          value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
        {searchResults && (
          <div className="absolute top-full mt-1 left-0 right-0 z-50 bg-card border border-border rounded-xl shadow-lg">
            {searchResults.contacts.length === 0 && searchResults.issues.length === 0 ? (
              <p className="p-4 text-sm text-muted-foreground">No results found.</p>
            ) : (
              <>
                {searchResults.contacts.length > 0 && (
                  <div className="p-3">
                    <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-2">Contacts</p>
                    {searchResults.contacts.map(c => (
                      <div key={c.id} className="flex items-center gap-2 py-1.5 px-2 hover:bg-secondary/50 rounded-md cursor-pointer">
                        <User className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-sm font-medium">{c.name}</span>
                        <span className="text-xs text-muted-foreground font-mono">{formatPhone(c.mobile)}</span>
                      </div>
                    ))}
                  </div>
                )}
                {searchResults.issues.length > 0 && (
                  <div className="p-3 border-t border-border/50">
                    <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-2">Issues</p>
                    {searchResults.issues.map(i => (
                      <div key={i.id} className="flex items-center gap-2 py-1.5 px-2 hover:bg-secondary/50 rounded-md cursor-pointer">
                        <AlertTriangle className="h-3.5 w-3.5 text-orange-500" />
                        <span className="text-sm">{i.issue_title}</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {loadingAsm && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading assembly data…
        </div>
      )}

      {/* ── Section 1: Basic Info ──────────────────────── */}
      <div ref={el => { sectionRefs.current["basic"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3 flex flex-row items-center justify-between">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" /> Basic Information
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => openEdit("electoral")}>
              <Edit className="h-3 w-3 mr-1" /> Edit
            </Button>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Assembly No.", value: asm?.number },
                { label: "District", value: asm?.district },
                { label: "Lok Sabha", value: asm?.lok_sabha },
                { label: "State", value: "Chhattisgarh" },
                { label: "Reservation", value: asmData.reservation_type || asm?.reservation },
                { label: "Area Type", value: asmData.area_type || "—" },
              ].map(({ label, value }) => (
                <div key={label} className="bg-secondary/30 rounded-lg p-3 border border-border/40">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{label}</p>
                  <p className="text-sm font-semibold text-foreground mt-0.5">{value ?? "—"}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Section 2: Electoral Overview ─────────────── */}
      <div ref={el => { sectionRefs.current["electoral"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3 flex flex-row items-center justify-between">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" /> Electoral Overview
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => openEdit("electoral")}>
              <Edit className="h-3 w-3 mr-1" /> Edit
            </Button>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "Total Voters", value: totalV?.toLocaleString() || "—", color: "text-blue-600" },
                { label: "Male", value: maleV?.toLocaleString() || "—", color: "text-indigo-600" },
                { label: "Female", value: femaleV?.toLocaleString() || "—", color: "text-pink-600" },
                { label: "Total Booths", value: asmData.total_booths?.toLocaleString() || "—", color: "text-teal-600" },
              ].map(({ label, value, color }) => (
                <div key={label} className="text-center bg-secondary/30 rounded-lg p-3 border border-border/40">
                  <p className={cn("text-xl font-bold", color)}>{value}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
                </div>
              ))}
            </div>
            {totalV > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Gender Split</p>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs"><span className="w-12 text-muted-foreground">Male</span><Pct value={totalV ? (maleV / totalV) * 100 : 0} color="bg-indigo-500" /></div>
                  <div className="flex items-center gap-2 text-xs"><span className="w-12 text-muted-foreground">Female</span><Pct value={totalV ? (femaleV / totalV) * 100 : 0} color="bg-pink-500" /></div>
                  {otherV > 0 && <div className="flex items-center gap-2 text-xs"><span className="w-12 text-muted-foreground">Other</span><Pct value={totalV ? (otherV / totalV) * 100 : 0} color="bg-gray-400" /></div>}
                </div>
              </div>
            )}
            {asmData.total_booths && (
              <div className="grid grid-cols-3 gap-3 text-center">
                {[
                  { label: "Urban Booths", value: asmData.urban_booths },
                  { label: "Rural Booths", value: asmData.rural_booths },
                  { label: "Sensitive Booths", value: asmData.sensitive_booths },
                ].map(({ label, value }) => (
                  <div key={label} className="bg-secondary/30 rounded-lg p-2 border border-border/40">
                    <p className="text-base font-bold text-foreground">{value ?? "—"}</p>
                    <p className="text-[10px] text-muted-foreground">{label}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Section 3: MLA Info ───────────────────────── */}
      <div ref={el => { sectionRefs.current["mla"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3 flex flex-row items-center justify-between">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <User className="h-4 w-4 text-primary" /> Current Representation
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => openEdit("mla")}>
              <Edit className="h-3 w-3 mr-1" /> Update MLA
            </Button>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { label: "Current MLA", value: asmData.mla_name },
                { label: "Party", value: asmData.mla_party?.toUpperCase() },
                { label: "Term Since", value: asmData.term_since },
                { label: "Vote Share", value: asmData.vote_share_pct ? `${asmData.vote_share_pct}%` : undefined },
                { label: "Win Margin", value: asmData.winning_margin?.toLocaleString() },
                { label: "Linked MP", value: asmData.linked_mp },
                { label: "Previous MLA", value: asmData.previous_mla_name },
              ].map(({ label, value }) => (
                <div key={label} className="bg-secondary/30 rounded-lg p-3 border border-border/40">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{label}</p>
                  <p className="text-sm font-semibold text-foreground mt-0.5">{value || "—"}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Section 4: Booth Heatmap ──────────────────── */}
      <div ref={el => { sectionRefs.current["booths"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3 flex flex-row items-center justify-between">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" /> Booth Coverage Heatmap
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => { setBoothForm({ assembly_name: selectedAssembly }); setBoothModal(true); }}>
              <Plus className="h-3 w-3 mr-1" /> Update Booth
            </Button>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="flex flex-wrap gap-3 mb-2">
              {BOOTH_STATUSES.map(s => (
                <div key={s.value} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className={cn("w-3 h-3 rounded-sm", s.color)} />
                  {s.label}
                </div>
              ))}
            </div>
            {booths.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No booth data yet. Click "Update Booth" to add records.</p>
            ) : (
              <div className="relative">
                <div className="flex flex-wrap gap-1.5">
                  {booths.map(b => (
                    <div key={b.id}
                      className={cn("w-8 h-8 rounded-md cursor-pointer transition-all hover:opacity-80 hover:scale-110 flex items-center justify-center text-[9px] font-bold text-white border", boothStatusColor(b.status), BOOTH_STATUSES.find(s => s.value === (b.status || "no_data"))?.border)}
                      title={`Booth ${b.booth_number}: ${b.village_ward || ""}`}
                      onMouseEnter={() => setHoveredBooth(b)}
                      onMouseLeave={() => setHoveredBooth(null)}>
                      {b.booth_number}
                    </div>
                  ))}
                </div>
                {hoveredBooth && (
                  <div className="absolute top-0 right-0 bg-card border border-border rounded-xl shadow-lg p-3 z-10 text-xs min-w-48">
                    <p className="font-bold text-foreground">Booth {hoveredBooth.booth_number}</p>
                    {hoveredBooth.village_ward && <p className="text-muted-foreground">{hoveredBooth.village_ward}</p>}
                    {hoveredBooth.worker_name && <p>Worker: <span className="font-medium">{hoveredBooth.worker_name}</span></p>}
                    {hoveredBooth.total_voters && <p>Voters: {hoveredBooth.total_voters.toLocaleString()}</p>}
                    <p className="capitalize mt-1 font-medium">{BOOTH_STATUSES.find(s => s.value === hoveredBooth.status)?.label}</p>
                  </div>
                )}
              </div>
            )}
            {asmData.total_booths && (
              <div className="pt-2">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Booth Coverage</span>
                  <span>{booths.filter(b => b.status !== "no_data").length} / {asmData.total_booths} booths</span>
                </div>
                <Pct value={boothCovPct} color="bg-primary" />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Section 5: Contacts ───────────────────────── */}
      <div ref={el => { sectionRefs.current["contacts"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-serif text-base flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" /> Contacts & Network
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
              {[
                { label: "Total Contacts", value: asmContacts.length },
                { label: "Volunteers", value: vol },
                { label: "With Leader Group", value: leaders },
                { label: "Booths Covered", value: booths.filter(b => b.worker_name).length },
              ].map(({ label, value }) => (
                <div key={label} className="bg-secondary/30 rounded-lg p-3 border border-border/40">
                  <p className="text-xl font-bold text-foreground">{value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
                </div>
              ))}
            </div>
            {asmContacts.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {asmContacts.slice(0, 6).map(c => (
                  <div key={c.id} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg border border-border/40">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                      {c.name?.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">{c.name}</p>
                      <p className="text-[10px] text-muted-foreground font-mono">{formatPhone(c.mobile)}</p>
                      {c.leader_group && <p className="text-[10px] text-primary font-medium">{c.leader_group}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
            {asmContacts.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">No contacts for this assembly yet. Add contacts with constituency set to "{selectedAssembly}".</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Section 6: Issues ─────────────────────────── */}
      <div ref={el => { sectionRefs.current["issues"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-primary" /> Issues & Ground Sentiment
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            {asmData.sentiment_positive != null && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Ground Sentiment</p>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-xs"><span className="w-16 text-muted-foreground">Positive</span><Pct value={asmData.sentiment_positive ?? 0} color="bg-green-500" /></div>
                  <div className="flex items-center gap-2 text-xs"><span className="w-16 text-muted-foreground">Neutral</span><Pct value={asmData.sentiment_neutral ?? 0} color="bg-yellow-400" /></div>
                  <div className="flex items-center gap-2 text-xs"><span className="w-16 text-muted-foreground">Negative</span><Pct value={asmData.sentiment_negative ?? 0} color="bg-red-500" /></div>
                </div>
                <Button size="sm" variant="ghost" className="text-xs h-7" onClick={() => openEdit("performance")}>
                  <Edit className="h-3 w-3 mr-1" /> Edit Sentiment
                </Button>
              </div>
            )}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Issues ({asmIssues.length})</p>
              </div>
              {asmIssues.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No issues for this assembly. Set constituency to "{selectedAssembly}" when reporting issues.</p>
              ) : (
                <div className="space-y-2">
                  {asmIssues.slice(0, 5).map(issue => (
                    <div key={issue.id} className="flex items-start gap-3 p-3 bg-secondary/30 rounded-lg border border-border/40">
                      <span className={cn("w-2 h-2 rounded-full mt-1.5 flex-shrink-0",
                        issue.issue_priority === "urgent" ? "bg-red-500" :
                        issue.issue_priority === "high" ? "bg-orange-500" : "bg-yellow-400")} />
                      <div>
                        <p className="text-sm font-medium text-foreground">{issue.issue_title}</p>
                        <p className="text-[10px] text-muted-foreground capitalize">{issue.issue_status} · {issue.issue_priority}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Section 7: Performance ────────────────────── */}
      <div ref={el => { sectionRefs.current["performance"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3 flex flex-row items-center justify-between">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Performance Dashboard
            </CardTitle>
            <Button size="sm" variant="outline" onClick={() => openEdit("performance")}>
              <Edit className="h-3 w-3 mr-1" /> Edit Scores
            </Button>
          </CardHeader>
          <CardContent className="pt-4 space-y-5">
            <div className="flex flex-wrap gap-6 justify-center py-2">
              {[
                { score: asmData.org_score ?? 0, label: "Org" },
                { score: asmData.campaign_score ?? 0, label: "Campaign" },
                { score: asmData.ground_score ?? 0, label: "Ground" },
                { score: asmData.media_score ?? 0, label: "Media" },
              ].map(s => <ScoreRing key={s.label} score={s.score} label={s.label} />)}
            </div>
            <div className="space-y-2">
              {[
                { label: "Party Strength", value: asmData.party_strength_pct ?? 0, color: "bg-primary" },
                { label: "Booth Coverage", value: boothCovPct, color: "bg-teal-500" },
                { label: "D2D Coverage", value: asmData.d2d_coverage_pct ?? 0, color: "bg-purple-500" },
                { label: "Issue Resolution", value: asmData.issue_resolution_rate ?? 0, color: "bg-green-500" },
              ].map(({ label, value, color }) => (
                <div key={label} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-36 shrink-0">{label}</span>
                  <Pct value={value} color={color} />
                </div>
              ))}
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground pt-2 border-t border-border/50">
              <Users className="h-4 w-4 text-primary" />
              <span>Active Volunteers: <strong className="text-foreground">{vol}</strong></span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Section 8: Strategy Insights ─────────────── */}
      <div ref={el => { sectionRefs.current["insights"] = el; }}>
        <Card className="shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3">
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-primary" /> Strategy Insights
            </CardTitle>
            <CardDescription>Rule-based analysis from all available data</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <p className="text-xs font-bold text-red-600 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertCircle className="h-3.5 w-3.5" /> Risk Alerts
                </p>
                {insights.risks.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No risks detected.</p>
                ) : insights.risks.map((r, i) => (
                  <div key={i} className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">{r}</div>
                ))}
              </div>
              <div className="space-y-2">
                <p className="text-xs font-bold text-orange-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="h-3.5 w-3.5" /> Recommended Actions
                </p>
                {insights.actions.length === 0 ? (
                  <p className="text-xs text-muted-foreground">All good.</p>
                ) : insights.actions.map((a, i) => (
                  <div key={i} className="p-2.5 bg-orange-50 border border-orange-200 rounded-lg text-xs text-orange-700">{a}</div>
                ))}
              </div>
              <div className="space-y-2">
                <p className="text-xs font-bold text-green-600 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle className="h-3.5 w-3.5" /> Positive Signals
                </p>
                {insights.positives.length === 0 ? (
                  <p className="text-xs text-muted-foreground">Keep building momentum.</p>
                ) : insights.positives.map((p, i) => (
                  <div key={i} className="p-2.5 bg-green-50 border border-green-200 rounded-lg text-xs text-green-700">{p}</div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Edit Modals ───────────────────────────────── */}
      <Dialog open={!!editModal} onOpenChange={o => { if (!o) setEditModal(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif capitalize">
              Edit {editModal === "electoral" ? "Electoral & Booth Data" : editModal === "mla" ? "MLA Information" : "Performance Scores"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            {editModal === "electoral" && (
              <>
                <div className="space-y-1.5">
                  <Label className="text-xs">Reservation Type</Label>
                  <select className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                    value={editForm.reservation_type ?? ""} onChange={e => ef("reservation_type", e.target.value)}>
                    <option value="">—</option>
                    <option value="General">General</option>
                    <option value="SC">SC</option>
                    <option value="ST">ST</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Area Type</Label>
                  <select className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                    value={editForm.area_type ?? ""} onChange={e => ef("area_type", e.target.value)}>
                    <option value="">—</option>
                    <option>Rural</option><option>Urban</option><option>Mixed</option><option>Semi-Urban</option>
                  </select>
                </div>
                {["total_voters","male_voters","female_voters","other_voters",
                  "total_booths","urban_booths","rural_booths","sensitive_booths"].map(k => (
                  <div key={k} className="space-y-1.5">
                    <Label className="text-xs capitalize">{k.replace(/_/g, " ")}</Label>
                    <Input type="number" value={editForm[k] ?? ""} onChange={e => ef(k, e.target.value)} />
                  </div>
                ))}
              </>
            )}
            {editModal === "mla" && (
              <>
                {["mla_name","mla_party","winning_margin","winning_margin_pct","vote_share_pct",
                  "term_since","previous_mla_name","linked_mp"].map(k => (
                  <div key={k} className="space-y-1.5">
                    <Label className="text-xs capitalize">{k.replace(/_/g, " ")}</Label>
                    <Input value={editForm[k] ?? ""} onChange={e => ef(k, e.target.value)} />
                  </div>
                ))}
              </>
            )}
            {editModal === "performance" && (
              <>
                {["party_strength_pct","org_score","campaign_score","ground_score","media_score",
                  "d2d_coverage_pct","issue_resolution_rate","sentiment_positive","sentiment_neutral",
                  "sentiment_negative","d2d_villages_covered","d2d_villages_total"].map(k => (
                  <div key={k} className="space-y-1.5">
                    <Label className="text-xs capitalize">{k.replace(/_/g, " ")}</Label>
                    <Input type="number" value={editForm[k] ?? ""} onChange={e => ef(k, e.target.value)} />
                  </div>
                ))}
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditModal(null)}>Cancel</Button>
            <Button disabled={savingEdit} onClick={() => saveAsmData(editForm)}>
              {savingEdit ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Saving…</> : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Booth Modal */}
      <Dialog open={boothModal} onOpenChange={setBoothModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif">Update Booth Record</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Booth Number *</Label>
              <Input value={boothForm.booth_number ?? ""} onChange={e => setBoothForm(f => ({ ...f, booth_number: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Status</Label>
              <select className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                value={boothForm.status ?? "no_data"} onChange={e => setBoothForm(f => ({ ...f, status: e.target.value }))}>
                {BOOTH_STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div className="col-span-2 space-y-1.5">
              <Label className="text-xs">Village / Ward</Label>
              <Input value={boothForm.village_ward ?? ""} onChange={e => setBoothForm(f => ({ ...f, village_ward: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Total Voters</Label>
              <Input type="number" value={boothForm.total_voters ?? ""} onChange={e => setBoothForm(f => ({ ...f, total_voters: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Worker Name</Label>
              <Input value={boothForm.worker_name ?? ""} onChange={e => setBoothForm(f => ({ ...f, worker_name: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1.5">
              <Label className="text-xs">Notes</Label>
              <textarea rows={2} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none"
                value={boothForm.notes ?? ""} onChange={e => setBoothForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBoothModal(false)}>Cancel</Button>
            <Button disabled={savingEdit} onClick={saveBooth}>
              {savingEdit ? "Saving…" : "Save Booth"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
