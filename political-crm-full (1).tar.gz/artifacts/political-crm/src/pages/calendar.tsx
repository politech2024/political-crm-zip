import { useState, useEffect } from "react";
import { useGetContacts } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon,
  MapPin, Users, Clock, Cake, Phone, X,
} from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth,
         eachDayOfInterval, isSameDay, isToday, getDay, addDays } from "date-fns";
import { CG_ASSEMBLIES, CG_DISTRICTS, getAssembliesByDistrict } from "@/data/cg-assemblies";
import { cn } from "@/lib/utils";
import { formatPhone, waLink } from "@/lib/phone";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const ACTIVITY_TYPES = [
  { value: "rally",        label: "Rally/Sabha",        color: "bg-orange-500",  dot: "bg-orange-400" },
  { value: "padyatra",     label: "Pad Yatra",          color: "bg-green-500",   dot: "bg-green-400" },
  { value: "meeting",      label: "Meeting",            color: "bg-blue-500",    dot: "bg-blue-400" },
  { value: "booth_visit",  label: "Booth Visit",        color: "bg-teal-500",    dot: "bg-teal-400" },
  { value: "d2d",          label: "Door-to-Door",       color: "bg-purple-500",  dot: "bg-purple-400" },
  { value: "sampark",      label: "Sampark Abhiyan",    color: "bg-cyan-500",    dot: "bg-cyan-400" },
  { value: "review_call",  label: "Review Call",        color: "bg-slate-500",   dot: "bg-slate-400" },
  { value: "issue_followup", label: "Issue Follow-up",  color: "bg-red-500",     dot: "bg-red-400" },
  { value: "birthday_visit", label: "Birthday Visit",   color: "bg-yellow-500",  dot: "bg-yellow-400" },
  { value: "other",        label: "Other",              color: "bg-gray-500",    dot: "bg-gray-400" },
];

const PRIORITIES = ["normal", "high", "urgent"];

interface CalEvent {
  id: string;
  title: string;
  activity_type: string;
  event_date: string;
  start_time?: string;
  end_time?: string;
  location?: string;
  district?: string;
  constituency?: string;
  booth_number?: string;
  expected_attendance?: number;
  priority?: string;
  reminder?: boolean;
  linked_issue?: string;
  notes?: string;
}

const blank = (): Omit<CalEvent, "id"> => ({
  title: "",
  activity_type: "meeting",
  event_date: format(new Date(), "yyyy-MM-dd"),
  start_time: "",
  end_time: "",
  location: "",
  district: "",
  constituency: "",
  booth_number: "",
  expected_attendance: undefined,
  priority: "normal",
  reminder: false,
  linked_issue: "",
  notes: "",
});

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(blank());
  const [saving, setSaving] = useState(false);
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [districtFilter, setDistrictFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const { toast } = useToast();

  const { data: contactsData } = useGetContacts({});
  const allContacts = contactsData?.data ?? [];

  const fetchEvents = async () => {
    try {
      const r = await fetch(`${BASE}/api/events`);
      const j = await r.json();
      if (j.success) setEvents(j.data);
    } catch {}
  };

  useEffect(() => { fetchEvents(); }, []);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startPad = getDay(monthStart);

  // Apply district + type filters to events
  const filteredEvents = events.filter(e => {
    if (districtFilter && districtFilter !== "all") {
      if (!e.district?.toLowerCase().includes(districtFilter.toLowerCase())) return false;
    }
    if (typeFilter && typeFilter !== "all") {
      if (e.activity_type !== typeFilter) return false;
    }
    return true;
  });

  const eventsOnDay = (d: Date) =>
    filteredEvents.filter(e => e.event_date === format(d, "yyyy-MM-dd"));

  const birthdaysOnDay = (d: Date) => {
    const dd = format(d, "dd");
    const mm = format(d, "MM");
    return allContacts.filter(c => {
      if (!c.birthday) return false;
      const parts = c.birthday.split("/");
      if (parts.length < 2) return false;
      return parts[0] === dd && parts[1] === mm;
    });
  };

  const upcomingEvents = [...filteredEvents]
    .filter(e => e.event_date >= format(new Date(), "yyyy-MM-dd"))
    .sort((a, b) => a.event_date.localeCompare(b.event_date))
    .slice(0, 10);

  const birthdaysThisWeek = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i))
    .flatMap(d =>
      birthdaysOnDay(d).map(c => ({
        contact: c,
        date: d,
        label: format(d, "EEE, d MMM"),
      }))
    );

  const activityDot = (type: string) =>
    ACTIVITY_TYPES.find(t => t.value === type)?.dot ?? "bg-gray-400";

  const activityLabel = (type: string) =>
    ACTIVITY_TYPES.find(t => t.value === type)?.label ?? type;

  const field = (k: keyof typeof form, v: any) => setForm(f => ({ ...f, [k]: v }));

  const districtAssemblies = form.district
    ? getAssembliesByDistrict(form.district)
    : CG_ASSEMBLIES;

  const handleSave = async () => {
    if (!form.title || !form.event_date) {
      toast({ title: "Title and date are required", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const r = await fetch(`${BASE}/api/events`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await r.json();
      if (j.success) {
        toast({ title: "Event saved" });
        setShowAdd(false);
        setForm(blank());
        fetchEvents();
      } else {
        toast({ title: "Error saving event", description: j.error, variant: "destructive" });
      }
    } catch (e: any) {
      toast({ title: "Network error", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const openAdd = (date?: Date) => {
    setForm({ ...blank(), event_date: format(date ?? new Date(), "yyyy-MM-dd") });
    setShowAdd(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold font-serif tracking-tight">Calendar & Activity Planner</h2>
          <p className="text-muted-foreground text-sm mt-1">Manage events, meetings, and track upcoming birthdays.</p>
        </div>
        <Button onClick={() => openAdd()} className="bg-primary text-primary-foreground shadow-md">
          <Plus className="mr-2 h-4 w-4" /> Add Event
        </Button>
      </div>

      {/* Filter bar */}
      <div className="bg-card p-3 rounded-xl border border-border shadow-sm flex flex-wrap gap-2 items-center">
        <Select value={districtFilter} onValueChange={v => setDistrictFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-[160px] bg-secondary/50 h-8 text-xs"><SelectValue placeholder="All Districts" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Districts</SelectItem>
            {CG_DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={v => setTypeFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-[170px] bg-secondary/50 h-8 text-xs"><SelectValue placeholder="All Activity Types" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Activity Types</SelectItem>
            {ACTIVITY_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        {(districtFilter || typeFilter) && (
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs text-muted-foreground"
            onClick={() => { setDistrictFilter(""); setTypeFilter(""); }}>
            <X className="h-3.5 w-3.5 mr-1" /> Clear
          </Button>
        )}
        {(districtFilter || typeFilter) && (
          <span className="text-xs text-muted-foreground ml-auto">
            {filteredEvents.length} event{filteredEvents.length !== 1 ? "s" : ""} match
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* ── Calendar Grid ─────────────────────────── */}
        <Card className="xl:col-span-2 shadow-sm">
          <CardHeader className="border-b border-border/50 pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="font-serif text-lg">{format(currentMonth, "MMMM yyyy")}</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 text-xs px-3" onClick={() => setCurrentMonth(new Date())}>
                  Today
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-3">
            <div className="grid grid-cols-7 gap-0.5 mb-1">
              {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d => (
                <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-0.5">
              {Array.from({ length: startPad }).map((_, i) => <div key={`pad-${i}`} />)}
              {days.map(day => {
                const dayEvents = eventsOnDay(day);
                const dayBirths = birthdaysOnDay(day);
                const isSelected = selectedDay && isSameDay(day, selectedDay);
                const todayDay = isToday(day);
                return (
                  <div key={day.toISOString()} onClick={() => {
                      setSelectedDay(isSameDay(day, selectedDay ?? new Date("1900-01-01")) ? null : day);
                    }}
                    className={cn(
                      "min-h-[68px] p-1.5 rounded-lg cursor-pointer transition-all text-sm border",
                      todayDay
                        ? "bg-primary/10 border-primary/50 text-primary font-bold"
                        : isSelected
                          ? "bg-secondary border-primary/30"
                          : "border-transparent hover:bg-secondary/50 hover:border-border/40"
                    )}>
                    <div className={cn("text-xs font-semibold mb-1", todayDay ? "text-primary" : "text-foreground")}>
                      {format(day, "d")}
                    </div>
                    <div className="flex flex-wrap gap-0.5">
                      {dayEvents.slice(0, 2).map(e => (
                        <span key={e.id} className={cn("inline-block w-2 h-2 rounded-full", activityDot(e.activity_type))} title={e.title} />
                      ))}
                      {dayBirths.length > 0 && (
                        <span className="inline-block w-2 h-2 rounded-full bg-yellow-400" title="Birthday" />
                      )}
                      {dayEvents.length > 2 && (
                        <span className="text-[9px] text-muted-foreground font-mono">+{dayEvents.length - 2}</span>
                      )}
                    </div>
                    {dayBirths.length > 0 && (
                      <div className="text-[9px] text-yellow-600 mt-0.5">🎂 {dayBirths.length}</div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Day detail panel */}
            {selectedDay && (
              <div className="mt-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-sm text-foreground">
                    {format(selectedDay, "EEEE, MMMM d, yyyy")}
                  </h4>
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => openAdd(selectedDay)}>
                    <Plus className="h-3 w-3 mr-1" /> Add
                  </Button>
                </div>
                <div className="space-y-2">
                  {eventsOnDay(selectedDay).length === 0 && birthdaysOnDay(selectedDay).length === 0 && (
                    <p className="text-xs text-muted-foreground">No events on this day.</p>
                  )}
                  {eventsOnDay(selectedDay).map(e => (
                    <div key={e.id} className="flex items-start gap-3 p-3 bg-secondary/30 rounded-lg border border-border/40">
                      <span className={cn("w-2.5 h-2.5 rounded-full mt-1 flex-shrink-0", activityDot(e.activity_type))} />
                      <div>
                        <p className="text-sm font-medium text-foreground">{e.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {activityLabel(e.activity_type)}
                          {e.start_time && ` · ${e.start_time}`}
                          {e.location && ` · ${e.location}`}
                        </p>
                      </div>
                    </div>
                  ))}
                  {birthdaysOnDay(selectedDay).map(c => (
                    <div key={c.id} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <span className="text-base">🎂</span>
                      <div>
                        <p className="text-sm font-medium text-foreground">{c.name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{formatPhone(c.mobile)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── Right Panel ────────────────────────────── */}
        <div className="space-y-5">
          {/* Upcoming events */}
          <Card className="shadow-sm">
            <CardHeader className="border-b border-border/50 pb-3">
              <CardTitle className="font-serif text-sm flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-primary" /> Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border/40 max-h-64 overflow-y-auto">
                {upcomingEvents.length === 0 && (
                  <p className="p-4 text-xs text-muted-foreground">No upcoming events.</p>
                )}
                {upcomingEvents.map(e => (
                  <div key={e.id} className="p-3 hover:bg-secondary/30 transition-colors">
                    <div className="flex items-start gap-2">
                      <span className={cn("w-2 h-2 rounded-full mt-1.5 flex-shrink-0", activityDot(e.activity_type))} />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-foreground truncate">{e.title}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {format(new Date(e.event_date), "dd MMM")}
                          {e.start_time && ` · ${e.start_time}`}
                        </p>
                        {e.location && (
                          <p className="text-[10px] text-muted-foreground flex items-center gap-0.5 mt-0.5">
                            <MapPin className="h-2.5 w-2.5" /> {e.location}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Birthdays this week */}
          <Card className="shadow-sm">
            <CardHeader className="border-b border-border/50 pb-3">
              <CardTitle className="font-serif text-sm flex items-center gap-2">
                <Cake className="h-4 w-4 text-yellow-500" /> Birthdays This Week
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border/40 max-h-56 overflow-y-auto">
                {birthdaysThisWeek.length === 0 && (
                  <p className="p-4 text-xs text-muted-foreground">No birthdays in the next 7 days.</p>
                )}
                {birthdaysThisWeek.map(({ contact, date, label }) => (
                  <div key={contact.id + label} className="p-3 hover:bg-yellow-50 transition-colors">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="text-xs font-semibold text-foreground">{contact.name}</p>
                        <p className="text-[10px] text-muted-foreground">🎂 {label}</p>
                        <p className="text-[10px] text-muted-foreground font-mono">{formatPhone(contact.mobile)}</p>
                      </div>
                      {contact.mobile && (
                        <a href={waLink(contact.mobile)}
                          target="_blank" rel="noopener noreferrer"
                          className="shrink-0 p-1.5 rounded-lg bg-green-100 hover:bg-green-200 text-green-700 transition-colors"
                          title="WhatsApp">
                          <Phone className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Activity type legend */}
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Legend</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-1.5">
                {ACTIVITY_TYPES.map(t => (
                  <div key={t.value} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className={cn("w-2 h-2 rounded-full flex-shrink-0", t.dot)} />
                    {t.label}
                  </div>
                ))}
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full flex-shrink-0 bg-yellow-400" />
                  Birthday
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── Add Event Modal ─────────────────────────── */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif">Add New Event</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Event Title *</Label>
              <Input placeholder="Enter event title" value={form.title} onChange={e => field("title", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Activity Type</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                value={form.activity_type} onChange={e => field("activity_type", e.target.value)}>
                {ACTIVITY_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Priority</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm capitalize"
                value={form.priority} onChange={e => field("priority", e.target.value)}>
                {PRIORITIES.map(p => <option key={p} value={p} className="capitalize">{p}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Date *</Label>
              <Input type="date" value={form.event_date} onChange={e => field("event_date", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Start Time</Label>
              <Input type="time" value={form.start_time} onChange={e => field("start_time", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>End Time</Label>
              <Input type="time" value={form.end_time} onChange={e => field("end_time", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Expected Attendance</Label>
              <Input type="number" placeholder="0" value={form.expected_attendance ?? ""}
                onChange={e => field("expected_attendance", e.target.value ? Number(e.target.value) : undefined)} />
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Location / Venue</Label>
              <Input placeholder="Village, ward, or venue name" value={form.location} onChange={e => field("location", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>District</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                value={form.district} onChange={e => { field("district", e.target.value); field("constituency", ""); }}>
                <option value="">All Districts</option>
                {CG_DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Assembly</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                value={form.constituency} onChange={e => field("constituency", e.target.value)}>
                <option value="">Select Assembly</option>
                {districtAssemblies.map(a => <option key={a.name} value={a.name}>{a.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Booth Number</Label>
              <Input placeholder="e.g. 44" value={form.booth_number} onChange={e => field("booth_number", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Set Reminder</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                value={form.reminder ? "yes" : "no"} onChange={e => field("reminder", e.target.value === "yes")}>
                <option value="no">No</option>
                <option value="yes">Yes</option>
              </select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Linked Issue (optional)</Label>
              <Input placeholder="Issue reference or title" value={form.linked_issue} onChange={e => field("linked_issue", e.target.value)} />
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Notes</Label>
              <textarea rows={3} placeholder="Additional notes…"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                value={form.notes} onChange={e => field("notes", e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? "Saving…" : "Save Event"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
