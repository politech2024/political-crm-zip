import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useUpdateContact, getGetContactsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ContactFormDialog } from "@/components/contacts/contact-form-dialog";
import { format, formatDistanceToNow, parseISO, isAfter } from "date-fns";
import { formatPhone, waLink, telLink } from "@/lib/phone";
import {
  ArrowLeft, Phone, MessageCircle, Edit, Trash2, Loader2, Plus,
  MapPin, Flag, Users, Share2, Calendar, AlertTriangle, Clock,
  CheckCircle, Star, TrendingUp, Bell, FileText, Activity,
  ChevronRight, X, User, Zap, Camera, Heart, CreditCard,
} from "lucide-react";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type Contact = Record<string, any>;
type Interaction = Record<string, any>;
type Issue = Record<string, any>;

const INTERACTION_TYPES = [
  { value: "call",       label: "Phone Call",     icon: "📞", color: "bg-blue-100 text-blue-700 border-blue-200" },
  { value: "whatsapp",   label: "WhatsApp",        icon: "💬", color: "bg-green-100 text-green-700 border-green-200" },
  { value: "visit",      label: "Field Visit",     icon: "🚗", color: "bg-purple-100 text-purple-700 border-purple-200" },
  { value: "meeting",    label: "Meeting",          icon: "🤝", color: "bg-amber-100 text-amber-700 border-amber-200" },
  { value: "event",      label: "Rally / Event",   icon: "🎤", color: "bg-red-100 text-red-700 border-red-200" },
  { value: "note",       label: "Note",             icon: "📝", color: "bg-gray-100 text-gray-700 border-gray-200" },
  { value: "reminder",   label: "Reminder",         icon: "⏰", color: "bg-orange-100 text-orange-700 border-orange-200" },
];

const OUTCOME_OPTIONS = [
  { value: "positive",  label: "Positive — supportive" },
  { value: "neutral",   label: "Neutral — undecided" },
  { value: "negative",  label: "Negative — opposed" },
  { value: "pending",   label: "Pending / No answer" },
];

const TABS = [
  { id: "profile",      label: "Profile",       icon: User },
  { id: "interactions", label: "Interactions",  icon: Activity },
  { id: "issues",       label: "Issues",        icon: AlertTriangle },
  { id: "reminders",    label: "Reminders",     icon: Bell },
  { id: "insights",     label: "Insights",      icon: TrendingUp },
];

const PARTY_COLORS: Record<string, string> = {
  bjp: "bg-orange-100 text-orange-700", inc: "bg-blue-100 text-blue-700",
  congress: "bg-blue-100 text-blue-700", aap: "bg-cyan-100 text-cyan-700",
  bsp: "bg-blue-50 text-blue-600", other: "bg-secondary text-secondary-foreground",
};

function getInitials(name: string) {
  return name.split(" ").slice(0, 2).map(w => w[0]).join("").toUpperCase();
}

function interactionMeta(type: string) {
  return INTERACTION_TYPES.find(t => t.value === type) ?? { label: type, icon: "•", color: "bg-gray-100 text-gray-600 border-gray-200" };
}

// ─── Add Interaction Dialog ──────────────────────────────────────────────────
function AddInteractionDialog({ contactId, open, onOpenChange, onSaved }: {
  contactId: string; open: boolean; onOpenChange: (v: boolean) => void; onSaved: () => void;
}) {
  const { toast } = useToast();
  const [type, setType] = useState("call");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [scheduledFor, setScheduledFor] = useState("");
  const [outcome, setOutcome] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const isReminder = type === "reminder";

  const handleSave = async () => {
    setSaving(true);
    try {
      const r = await fetch(`${BASE}/api/contacts/${contactId}/interactions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, notes, outcome, interaction_date: date, scheduled_for: isReminder ? scheduledFor : undefined }),
      });
      const j = await r.json();
      if (j.success) {
        toast({ title: isReminder ? "Reminder set" : "Interaction logged" });
        onSaved();
        onOpenChange(false);
        setNotes(""); setOutcome(""); setType("call");
      } else {
        toast({ title: "Error", description: j.error, variant: "destructive" });
      }
    } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px] bg-card">
        <DialogHeader>
          <DialogTitle className="font-serif">{isReminder ? "Set Reminder" : "Log Interaction"}</DialogTitle>
          <DialogDescription>Record a touchpoint with this contact.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Type</Label>
            <div className="grid grid-cols-4 gap-2 mt-2">
              {INTERACTION_TYPES.map(t => (
                <button key={t.value} onClick={() => setType(t.value)}
                  className={cn("flex flex-col items-center gap-1 p-2 rounded-lg border text-xs font-medium transition-all",
                    type === t.value ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground hover:border-primary/30")}>
                  <span className="text-lg">{t.icon}</span>
                  <span className="text-[10px] leading-tight text-center">{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                {isReminder ? "Reminder Date" : "Interaction Date"}
              </Label>
              <Input type="date" value={isReminder ? scheduledFor : date}
                onChange={e => isReminder ? setScheduledFor(e.target.value) : setDate(e.target.value)}
                className="mt-1.5" />
            </div>
            {!isReminder && (
              <div>
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Outcome</Label>
                <Select value={outcome} onValueChange={setOutcome}>
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="Select outcome" />
                  </SelectTrigger>
                  <SelectContent>
                    {OUTCOME_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Notes</Label>
            <textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)}
              placeholder={isReminder ? "What to discuss or follow up on…" : "How did the conversation go?"}
              className="mt-1.5 w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving || (isReminder && !scheduledFor)} className="font-semibold">
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {isReminder ? "Set Reminder" : "Log Interaction"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Photo Avatar with upload ────────────────────────────────────────────────
function PhotoAvatar({
  contact, onPhotoSaved,
}: { contact: Contact; onPhotoSaved: (url: string) => void }) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const photoSrc = contact.photo_url
    ? `${BASE}/api/storage${contact.photo_url}`
    : null;

  const handleFile = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({ title: "Please select an image file", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image must be under 5 MB", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const urlRes = await fetch(`${BASE}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();

      const putRes = await fetch(uploadURL, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!putRes.ok) throw new Error("Upload failed");

      const saveRes = await fetch(`${BASE}/api/contacts/${contact.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...contact, photo_url: objectPath }),
      });
      if (!saveRes.ok) throw new Error("Failed to save photo");

      onPhotoSaved(objectPath);
      toast({ title: "Photo updated" });
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  }, [contact, onPhotoSaved, toast]);

  return (
    <div className="shrink-0 relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])}
      />
      <div className="h-20 w-20 rounded-full bg-primary/10 border-2 border-primary/20 overflow-hidden flex items-center justify-center">
        {photoSrc ? (
          <img src={photoSrc} alt={contact.name} className="h-full w-full object-cover" />
        ) : (
          <span className="text-2xl font-bold text-primary font-serif">{getInitials(contact.name)}</span>
        )}
      </div>
      <div className={cn(
        "absolute inset-0 rounded-full flex items-center justify-center transition-opacity",
        uploading ? "opacity-100 bg-black/50" : "opacity-0 group-hover:opacity-100 bg-black/40"
      )}>
        {uploading
          ? <Loader2 className="h-6 w-6 text-white animate-spin" />
          : <Camera className="h-6 w-6 text-white" />}
      </div>
      <div className="absolute -bottom-0.5 -right-0.5 h-6 w-6 rounded-full bg-primary border-2 border-background flex items-center justify-center">
        <Camera className="h-3 w-3 text-primary-foreground" />
      </div>
    </div>
  );
}

// ─── Relationship score ──────────────────────────────────────────────────────
function computeInsights(interactions: Interaction[]) {
  const past = interactions.filter(i => i.type !== "reminder");
  const now = new Date();
  const last = past.length ? past.slice().sort((a, b) => b.interaction_date.localeCompare(a.interaction_date))[0] : null;
  const daysSinceLast = last ? Math.floor((now.getTime() - new Date(last.interaction_date).getTime()) / 86400000) : null;
  const positiveCount = past.filter(i => i.outcome === "positive").length;
  const negativeCount = past.filter(i => i.outcome === "negative").length;

  let score = 50;
  if (past.length > 0) score += Math.min(past.length * 5, 25);
  if (daysSinceLast !== null) {
    if (daysSinceLast <= 7) score += 20;
    else if (daysSinceLast <= 30) score += 10;
    else if (daysSinceLast > 90) score -= 20;
    else if (daysSinceLast > 60) score -= 10;
  } else { score -= 20; }
  score += positiveCount * 3 - negativeCount * 4;
  score = Math.max(0, Math.min(100, score));

  const level = score >= 75 ? "Strong" : score >= 50 ? "Growing" : score >= 25 ? "Weak" : "Cold";
  const levelColor = score >= 75 ? "text-green-600" : score >= 50 ? "text-blue-600" : score >= 25 ? "text-amber-600" : "text-red-500";
  return { score, level, levelColor, daysSinceLast, totalInteractions: past.length, positiveCount, negativeCount };
}

// ─── Main profile page ───────────────────────────────────────────────────────
export default function ContactProfile({ params }: { params: { id: string } }) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [contact, setContact] = useState<Contact | null>(null);
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAddInteractionOpen, setIsAddInteractionOpen] = useState(false);
  const [deletingInteraction, setDeletingInteraction] = useState<string | null>(null);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [cRes, iRes, issRes] = await Promise.all([
        fetch(`${BASE}/api/contacts/${params.id}`),
        fetch(`${BASE}/api/contacts/${params.id}/interactions`),
        fetch(`${BASE}/api/contacts/${params.id}/issues`),
      ]);
      const [cj, ij, isj] = await Promise.all([cRes.json(), iRes.json(), issRes.json()]);
      if (cj.success) setContact(cj.data);
      else navigate("/contacts");
      if (ij.success) setInteractions(ij.data.sort((a: Interaction, b: Interaction) => b.interaction_date.localeCompare(a.interaction_date)));
      if (isj.success) setIssues(isj.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, [params.id]);

  const handleDelete = async () => {
    if (!confirm(`Delete ${contact?.name}? This cannot be undone.`)) return;
    await fetch(`${BASE}/api/contacts/${params.id}`, { method: "DELETE" });
    queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
    toast({ title: "Contact deleted" });
    navigate("/contacts");
  };

  const handleDeleteInteraction = async (id: string) => {
    setDeletingInteraction(id);
    await fetch(`${BASE}/api/contacts/${params.id}/interactions/${id}`, { method: "DELETE" });
    setInteractions(prev => prev.filter(i => i.id !== id));
    setDeletingInteraction(null);
  };

  const handlePhotoSaved = useCallback((objectPath: string) => {
    setContact(prev => prev ? { ...prev, photo_url: objectPath } : prev);
    queryClient.invalidateQueries({ queryKey: getGetContactsQueryKey() });
  }, [queryClient]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
  if (!contact) return null;

  const pastInteractions = interactions.filter(i => i.type !== "reminder");
  const reminders = interactions.filter(i => i.type === "reminder");
  const upcomingReminders = reminders.filter(i => i.scheduled_for && isAfter(parseISO(i.scheduled_for), new Date()));
  const insights = computeInsights(interactions);

  const InfoRow = ({ label, value }: { label: string; value?: string | null }) =>
    value ? (
      <div>
        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">{label}</p>
        <p className="text-sm text-foreground">{value}</p>
      </div>
    ) : null;

  return (
    <div className="space-y-5 max-w-5xl mx-auto">
      {/* ── Back ── */}
      <button onClick={() => navigate("/contacts")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back to Contacts Directory
      </button>

      {/* ── Hero card ── */}
      <Card className="shadow-sm overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-primary via-primary/60 to-primary/20" />
        <CardContent className="pt-5 pb-5">
          <div className="flex flex-col sm:flex-row gap-5 items-start">
            {/* Avatar */}
            <PhotoAvatar contact={contact} onPhotoSaved={handlePhotoSaved} />

            {/* Core info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start gap-2 flex-wrap">
                <h1 className="text-xl font-bold font-serif text-foreground">{contact.name}</h1>
                {contact.volunteer && <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-100 text-green-700 uppercase tracking-wider mt-1">Volunteer</span>}
                {contact.political_party && (
                  <span className={cn("px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider mt-1", PARTY_COLORS[contact.political_party] ?? "bg-secondary text-foreground")}>
                    {contact.political_party}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
                {contact.mobile && <span className="flex items-center gap-1 font-mono"><Phone className="h-3.5 w-3.5" />{formatPhone(contact.mobile)}</span>}
                {contact.constituency && <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{contact.constituency}{contact.district ? `, ${contact.district}` : ""}</span>}
                {contact.village_ward && <span className="flex items-center gap-1"><ChevronRight className="h-3 w-3" />{contact.village_ward}{contact.booth_number ? ` · Booth ${contact.booth_number}` : ""}</span>}
              </div>

              {/* Relationship score pill */}
              <div className="flex items-center gap-3 mt-3 flex-wrap">
                <div className={cn("flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border", insights.score >= 75 ? "bg-green-50 border-green-200 text-green-700" : insights.score >= 50 ? "bg-blue-50 border-blue-200 text-blue-700" : insights.score >= 25 ? "bg-amber-50 border-amber-200 text-amber-700" : "bg-red-50 border-red-200 text-red-600")}>
                  <Star className="h-3 w-3" /> {insights.level} Relationship · {insights.score}/100
                </div>
                {insights.daysSinceLast !== null ? (
                  <span className="text-xs text-muted-foreground">{insights.daysSinceLast === 0 ? "Contacted today" : `Last contact ${insights.daysSinceLast}d ago`}</span>
                ) : (
                  <span className="text-xs text-amber-600 flex items-center gap-1"><Clock className="h-3 w-3" />Never contacted</span>
                )}
                {upcomingReminders.length > 0 && (
                  <span className="text-xs text-orange-600 flex items-center gap-1"><Bell className="h-3 w-3" />{upcomingReminders.length} reminder{upcomingReminders.length > 1 ? "s" : ""} due</span>
                )}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-row flex-wrap sm:flex-col gap-2 shrink-0">
              {contact.whatsapp_number && (
                <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white gap-2" asChild>
                  <a href={waLink(contact.whatsapp_number)} target="_blank" rel="noreferrer">
                    <MessageCircle className="h-4 w-4" /> <span className="hidden xs:inline sm:inline">WhatsApp</span>
                  </a>
                </Button>
              )}
              {contact.mobile && (
                <Button size="sm" variant="outline" className="gap-2" asChild>
                  <a href={telLink(contact.mobile)}>
                    <Phone className="h-4 w-4" /> <span>Call</span>
                  </a>
                </Button>
              )}
              <Button size="sm" variant="outline" className="gap-2" onClick={() => { setIsAddInteractionOpen(true); }}>
                <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Log Interaction</span><span className="sm:hidden">Log</span>
              </Button>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => setIsEditOpen(true)}>
                <Edit className="h-4 w-4" /> Edit
              </Button>
              <Button size="sm" variant="outline" className="gap-2 text-destructive hover:text-destructive border-destructive/20 hover:border-destructive/50 hover:bg-destructive/5" onClick={handleDelete}>
                <Trash2 className="h-4 w-4" /> Delete
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Tabs ── */}
      <div className="flex gap-0 border-b border-border overflow-x-auto">
        {TABS.map(({ id, label, icon: Icon }) => {
          const badge = id === "issues" ? issues.length : id === "reminders" ? upcomingReminders.length : id === "interactions" ? pastInteractions.length : null;
          return (
            <button key={id} onClick={() => setActiveTab(id)}
              className={cn("flex items-center gap-1.5 px-4 py-3 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap relative",
                activeTab === id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground hover:border-border")}>
              <Icon className="h-4 w-4" /> {label}
              {badge !== null && badge > 0 && (
                <span className={cn("ml-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full", activeTab === id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground")}>
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  TAB 1 — PROFILE                                                       */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "profile" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Personal */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm font-serif flex items-center gap-2"><User className="h-4 w-4 text-primary" />Personal Information</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              {contact.first_name ? (
                <>
                  <InfoRow label="First Name" value={contact.first_name} />
                  {contact.middle_name && <InfoRow label="Middle Name" value={contact.middle_name} />}
                  <InfoRow label="Last Name" value={contact.last_name} />
                </>
              ) : (
                <InfoRow label="Full Name" value={contact.name} />
              )}
              <InfoRow label="Mobile" value={formatPhone(contact.mobile)} />
              {Array.isArray(contact.additional_mobiles) && contact.additional_mobiles.length > 0 && (
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground mb-1">Additional Numbers</p>
                  <div className="flex flex-wrap gap-2">
                    {contact.additional_mobiles.map((m: string, i: number) => (
                      <a key={i} href={`tel:${m}`} className="text-xs font-mono bg-secondary px-2 py-0.5 rounded hover:bg-secondary/80 transition-colors">
                        <Phone className="h-3 w-3 inline mr-1" />{formatPhone(m)}
                      </a>
                    ))}
                  </div>
                </div>
              )}
              <InfoRow label="WhatsApp" value={formatPhone(contact.whatsapp_number)} />
              <InfoRow label="Email" value={contact.email} />
              {contact.voter_id && (
                <div className="col-span-2 flex items-center gap-2 py-1 border-t border-border/40 mt-1">
                  <CreditCard className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <span className="text-xs text-muted-foreground">Voter ID (EPIC)</span>
                  <span className="text-xs font-mono font-semibold tracking-wider ml-auto bg-secondary px-2 py-0.5 rounded">{contact.voter_id}</span>
                </div>
              )}
              <InfoRow label="Date of Birth" value={contact.birthday} />
              <InfoRow label="Gender" value={contact.gender ? contact.gender.charAt(0).toUpperCase() + contact.gender.slice(1) : null} />
            </CardContent>
          </Card>

          {/* Family Members */}
          {Array.isArray(contact.family_members) && contact.family_members.length > 0 && (
            <Card className="shadow-sm">
              <CardHeader className="pb-3"><CardTitle className="text-sm font-serif flex items-center gap-2"><Heart className="h-4 w-4 text-rose-500" />Family Tree</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {contact.family_members.map((member: any, idx: number) => (
                  <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/20 border border-border/50">
                    <div className="h-8 w-8 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                      <Heart className="h-4 w-4 text-rose-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold leading-tight">{member.name}</p>
                      {member.relation && <p className="text-xs text-muted-foreground capitalize">{member.relation}</p>}
                      <div className="flex flex-wrap gap-3 mt-1">
                        {member.mobile && (
                          <a href={`tel:${member.mobile}`} className="text-xs text-blue-600 font-mono hover:underline flex items-center gap-1">
                            <Phone className="h-3 w-3" />{formatPhone(member.mobile)}
                          </a>
                        )}
                        {member.voter_id && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <CreditCard className="h-3 w-3" />{member.voter_id}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Location */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm font-serif flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" />Location</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <InfoRow label="Village / Ward" value={contact.village_ward} />
              <InfoRow label="Booth Number" value={contact.booth_number} />
              <InfoRow label="Assembly Constituency" value={contact.constituency} />
              <InfoRow label="Lok Sabha" value={contact.lok_sabha_constituency} />
              <InfoRow label="District" value={contact.district} />
            </CardContent>
          </Card>

          {/* Political */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm font-serif flex items-center gap-2"><Flag className="h-4 w-4 text-primary" />Political</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <InfoRow label="Party" value={contact.political_party?.toUpperCase()} />
              <InfoRow label="Designation / Role" value={contact.political_affiliation} />
              <InfoRow label="Frontal / Wing" value={contact.party_frontal} />
              <InfoRow label="Department / Cell" value={contact.party_department} />
              <InfoRow label="Leader Group" value={contact.leader_group} />
              <InfoRow label="Second Leader" value={contact.second_leader} />
              <InfoRow label="Non-Political Org" value={contact.non_political_org} />
            </CardContent>
          </Card>

          {/* Social + Notes */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm font-serif flex items-center gap-2"><Users className="h-4 w-4 text-primary" />Social Profile</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <InfoRow label="Caste Category" value={contact.caste} />
              <InfoRow label="Religion" value={contact.religion} />
              <InfoRow label="Source" value={contact.source} />
              <InfoRow label="Added On" value={contact.created_at ? format(parseISO(contact.created_at), "d MMM yyyy") : undefined} />
              {(contact.facebook || contact.instagram || contact.twitter) && (
                <div className="col-span-2">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Social Media</p>
                  <div className="flex gap-2 flex-wrap">
                    {contact.facebook && <a href={`https://facebook.com/${contact.facebook}`} target="_blank" rel="noreferrer" className="text-xs text-blue-600 underline underline-offset-2">Facebook</a>}
                    {contact.instagram && <a href={`https://instagram.com/${contact.instagram}`} target="_blank" rel="noreferrer" className="text-xs text-pink-600 underline underline-offset-2">@{contact.instagram}</a>}
                    {contact.twitter && <a href={`https://twitter.com/${contact.twitter}`} target="_blank" rel="noreferrer" className="text-xs text-sky-600 underline underline-offset-2">@{contact.twitter}</a>}
                  </div>
                </div>
              )}
              {contact.notes && (
                <div className="col-span-2">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">Notes</p>
                  <p className="text-sm text-foreground whitespace-pre-wrap bg-secondary/30 rounded-lg p-3 border border-border/40">{contact.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  TAB 2 — INTERACTIONS                                                  */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "interactions" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{pastInteractions.length} interaction{pastInteractions.length !== 1 ? "s" : ""} logged</p>
            <Button size="sm" onClick={() => setIsAddInteractionOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" /> Log Interaction
            </Button>
          </div>

          {pastInteractions.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="flex flex-col items-center justify-center h-48 text-center">
                <Activity className="h-10 w-10 text-muted-foreground/20 mb-3" />
                <p className="font-medium text-foreground">No interactions yet</p>
                <p className="text-sm text-muted-foreground mt-1">Log your first call, visit, or message.</p>
                <Button size="sm" className="mt-4 gap-2" onClick={() => setIsAddInteractionOpen(true)}>
                  <Plus className="h-4 w-4" /> Add First Interaction
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-px bg-border/50" />
              <div className="space-y-3">
                {pastInteractions.map((interaction) => {
                  const meta = interactionMeta(interaction.type);
                  return (
                    <div key={interaction.id} className="relative flex gap-4 group">
                      {/* Icon bubble */}
                      <div className={cn("relative z-10 flex items-center justify-center h-12 w-12 rounded-full border-2 border-background text-lg shrink-0", meta.color.split(" ").slice(0,1).join(" "))}>
                        {meta.icon}
                      </div>
                      {/* Content */}
                      <Card className="flex-1 shadow-sm hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full border", meta.color)}>{meta.label}</span>
                                {interaction.outcome && (
                                  <span className={cn("text-[10px] font-medium px-2 py-0.5 rounded-full",
                                    interaction.outcome === "positive" ? "bg-green-100 text-green-700" :
                                    interaction.outcome === "negative" ? "bg-red-100 text-red-600" :
                                    "bg-gray-100 text-gray-600")}>
                                    {interaction.outcome}
                                  </span>
                                )}
                                <span className="text-xs text-muted-foreground ml-auto">
                                  {format(parseISO(interaction.interaction_date), "d MMM yyyy")}
                                </span>
                              </div>
                              {interaction.notes && (
                                <p className="text-sm text-foreground mt-2 leading-relaxed">{interaction.notes}</p>
                              )}
                            </div>
                            <button onClick={() => handleDeleteInteraction(interaction.id)}
                              className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-all shrink-0">
                              {deletingInteraction === interaction.id
                                ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                : <X className="h-3.5 w-3.5" />}
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  TAB 3 — ISSUES                                                        */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "issues" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{issues.length} issue{issues.length !== 1 ? "s" : ""} linked to this contact</p>
            <Button size="sm" variant="outline" className="gap-2" onClick={() => navigate("/issues")}>
              <Plus className="h-4 w-4" /> New Issue
            </Button>
          </div>

          {issues.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="flex flex-col items-center justify-center h-48 text-center">
                <AlertTriangle className="h-10 w-10 text-muted-foreground/20 mb-3" />
                <p className="font-medium text-foreground">No issues linked</p>
                <p className="text-sm text-muted-foreground mt-1">No issues have been reported by or linked to this contact.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {issues.map((issue) => (
                <Card key={issue.id} className="shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={cn("mt-0.5 h-8 w-8 rounded-full flex items-center justify-center shrink-0",
                        issue.issue_priority === "urgent" ? "bg-red-100" :
                        issue.issue_priority === "high" ? "bg-orange-100" :
                        issue.issue_priority === "medium" ? "bg-yellow-100" : "bg-gray-100")}>
                        <AlertTriangle className={cn("h-4 w-4",
                          issue.issue_priority === "urgent" ? "text-red-600" :
                          issue.issue_priority === "high" ? "text-orange-600" :
                          issue.issue_priority === "medium" ? "text-yellow-600" : "text-gray-500")} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-sm text-foreground">{issue.issue_title}</p>
                          <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
                            issue.issue_status === "resolved" ? "bg-green-100 text-green-700" :
                            issue.issue_status === "in_progress" ? "bg-blue-100 text-blue-700" :
                            "bg-yellow-100 text-yellow-700")}>
                            {issue.issue_status}
                          </span>
                          {issue.issue_priority && (
                            <span className="text-[10px] text-muted-foreground capitalize">{issue.issue_priority} priority</span>
                          )}
                        </div>
                        {issue.issue_description && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{issue.issue_description}</p>
                        )}
                        <p className="text-[10px] text-muted-foreground mt-1.5">
                          {issue.district && `${issue.district} · `}{format(parseISO(issue.created_at), "d MMM yyyy")}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  TAB 4 — REMINDERS                                                     */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "reminders" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{upcomingReminders.length} upcoming · {reminders.filter(i => !i.scheduled_for || !isAfter(parseISO(i.scheduled_for), new Date())).length} past</p>
            <Button size="sm" onClick={() => { setIsAddInteractionOpen(true); }} className="gap-2">
              <Bell className="h-4 w-4" /> Set Reminder
            </Button>
          </div>

          {reminders.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="flex flex-col items-center justify-center h-48 text-center">
                <Bell className="h-10 w-10 text-muted-foreground/20 mb-3" />
                <p className="font-medium text-foreground">No reminders set</p>
                <p className="text-sm text-muted-foreground mt-1">Set a reminder to follow up with this contact.</p>
                <Button size="sm" className="mt-4 gap-2" onClick={() => setIsAddInteractionOpen(true)}>
                  <Plus className="h-4 w-4" /> Set Reminder
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {reminders
                .slice()
                .sort((a, b) => (a.scheduled_for ?? "").localeCompare(b.scheduled_for ?? ""))
                .map((reminder) => {
                  const isUpcoming = reminder.scheduled_for && isAfter(parseISO(reminder.scheduled_for), new Date());
                  return (
                    <Card key={reminder.id} className={cn("shadow-sm", !isUpcoming && "opacity-60")}>
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className={cn("h-9 w-9 rounded-full flex items-center justify-center shrink-0 text-lg", isUpcoming ? "bg-orange-100" : "bg-gray-100")}>
                          ⏰
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            {reminder.scheduled_for && (
                              <p className={cn("text-sm font-semibold", isUpcoming ? "text-orange-600" : "text-muted-foreground")}>
                                {format(parseISO(reminder.scheduled_for), "d MMM yyyy")}
                              </p>
                            )}
                            {isUpcoming ? (
                              <span className="text-[10px] bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-semibold">
                                {formatDistanceToNow(parseISO(reminder.scheduled_for!), { addSuffix: true })}
                              </span>
                            ) : (
                              <span className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">Past</span>
                            )}
                          </div>
                          {reminder.notes && <p className="text-sm text-muted-foreground mt-1">{reminder.notes}</p>}
                        </div>
                        <button onClick={() => handleDeleteInteraction(reminder.id)}
                          className="p-1 rounded hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors">
                          <X className="h-4 w-4" />
                        </button>
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  TAB 5 — INSIGHTS                                                      */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "insights" && (
        <div className="space-y-4">
          {/* Score card */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-serif flex items-center gap-2"><Zap className="h-4 w-4 text-primary" />Relationship Health Score</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-6">
                <div className="relative h-24 w-24 shrink-0">
                  <svg className="h-24 w-24 -rotate-90" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-secondary" />
                    <circle cx="18" cy="18" r="15.9" fill="none" strokeWidth="2.5"
                      stroke={insights.score >= 75 ? "#16a34a" : insights.score >= 50 ? "#2563eb" : insights.score >= 25 ? "#d97706" : "#dc2626"}
                      strokeDasharray={`${insights.score} ${100 - insights.score}`}
                      strokeLinecap="round" className="transition-all duration-700" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-xl font-bold font-mono">{insights.score}</span>
                    <span className="text-[10px] text-muted-foreground">/100</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <p className={cn("text-lg font-bold font-serif", insights.levelColor)}>{insights.level} Relationship</p>
                  <p className="text-sm text-muted-foreground">
                    {insights.daysSinceLast === null ? "You have never contacted this person." :
                     insights.daysSinceLast === 0 ? "You contacted them today." :
                     `Last contact was ${insights.daysSinceLast} day${insights.daysSinceLast !== 1 ? "s" : ""} ago.`}
                  </p>
                  {insights.score < 50 && (
                    <p className="text-xs text-amber-600 flex items-center gap-1"><Clock className="h-3 w-3" />Reach out soon to strengthen this relationship.</p>
                  )}
                </div>
              </div>

              {/* Score breakdown */}
              <div className="h-px bg-border" />
              <div className="h-3 rounded-full bg-secondary overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${insights.score}%`,
                    background: insights.score >= 75 ? "#16a34a" : insights.score >= 50 ? "#2563eb" : insights.score >= 25 ? "#d97706" : "#dc2626",
                  }} />
              </div>
            </CardContent>
          </Card>

          {/* Stats grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Total Interactions", value: insights.totalInteractions, icon: Activity, color: "text-blue-600" },
              { label: "Positive Outcomes", value: insights.positiveCount, icon: CheckCircle, color: "text-green-600" },
              { label: "Negative Outcomes", value: insights.negativeCount, icon: X, color: "text-red-500" },
              { label: "Reminders Set", value: reminders.length, icon: Bell, color: "text-orange-500" },
            ].map(s => (
              <Card key={s.label} className="shadow-sm">
                <CardContent className="p-4 text-center">
                  <s.icon className={cn("h-5 w-5 mx-auto mb-2", s.color)} />
                  <p className={cn("text-2xl font-bold font-mono", s.color)}>{s.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{s.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Interaction breakdown by type */}
          {pastInteractions.length > 0 && (
            <Card className="shadow-sm">
              <CardHeader className="pb-3"><CardTitle className="text-sm font-serif">Interaction Breakdown</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {INTERACTION_TYPES.filter(t => t.value !== "reminder").map(t => {
                  const count = pastInteractions.filter(i => i.type === t.value).length;
                  if (count === 0) return null;
                  return (
                    <div key={t.value} className="flex items-center gap-3">
                      <span className="text-base w-6">{t.icon}</span>
                      <span className="text-xs text-muted-foreground w-28">{t.label}</span>
                      <div className="flex-1 h-2 rounded-full bg-secondary overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${(count / pastInteractions.length) * 100}%` }} />
                      </div>
                      <span className="text-xs font-semibold text-foreground w-6 text-right">{count}</span>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          <Card className="shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm font-serif">Recommended Actions</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {[
                insights.daysSinceLast === null && { icon: "📞", text: "Initiate first contact — introduce yourself and understand their concerns.", action: "Log Call" },
                insights.daysSinceLast !== null && insights.daysSinceLast > 30 && { icon: "⚠️", text: `It's been ${insights.daysSinceLast} days since last contact. Follow up now.`, action: "Log Interaction" },
                upcomingReminders.length === 0 && { icon: "⏰", text: "Set a follow-up reminder to maintain regular contact.", action: "Set Reminder" },
                issues.length > 0 && issues.some(i => i.issue_status === "new") && { icon: "🔔", text: `${issues.filter(i => i.issue_status === "new").length} open issue(s) need attention.`, action: "View Issues" },
                !contact.whatsapp_number && contact.mobile && { icon: "💬", text: "Add WhatsApp number for easier communication.", action: "Edit Contact" },
              ].filter(Boolean).map((r: any, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 border border-border/40">
                  <span className="text-lg shrink-0">{r.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">{r.text}</p>
                  </div>
                  <button onClick={() => {
                    if (r.action === "Log Call" || r.action === "Log Interaction") { setIsAddInteractionOpen(true); }
                    else if (r.action === "Set Reminder") { setIsAddInteractionOpen(true); }
                    else if (r.action === "View Issues") { setActiveTab("issues"); }
                    else if (r.action === "Edit Contact") { setIsEditOpen(true); }
                  }}
                    className="text-xs font-semibold text-primary hover:underline shrink-0">{r.action}</button>
                </div>
              ))}
              {[
                insights.daysSinceLast === null,
                insights.daysSinceLast !== null && insights.daysSinceLast > 30,
                upcomingReminders.length === 0,
                issues.length > 0 && issues.some(i => i.issue_status === "new"),
                !contact.whatsapp_number && contact.mobile,
              ].every(v => !v) && (
                <p className="text-sm text-muted-foreground text-center py-4">All good! This relationship looks healthy.</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ── Dialogs ── */}
      <AddInteractionDialog
        contactId={params.id}
        open={isAddInteractionOpen}
        onOpenChange={setIsAddInteractionOpen}
        onSaved={fetchAll}
      />
      <ContactFormDialog
        open={isEditOpen}
        onOpenChange={(v) => { setIsEditOpen(v); if (!v) fetchAll(); }}
        contact={contact as any}
      />
    </div>
  );
}
