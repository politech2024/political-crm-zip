import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout/app-layout";
import Dashboard from "@/pages/dashboard";
import Contacts from "@/pages/contacts";
import Volunteers from "@/pages/volunteers";
import Issues from "@/pages/issues";
import Messages from "@/pages/messages";
import Campaigns from "@/pages/campaigns";
import CalendarPage from "@/pages/calendar";
import AssemblyDashboard from "@/pages/assembly-dashboard";
import AiIntake from "@/pages/ai-intake";
import ContactProfile from "@/pages/contact-profile";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/contacts" component={Contacts} />
        <Route path="/contacts/:id" component={ContactProfile} />
        <Route path="/volunteers" component={Volunteers} />
        <Route path="/issues" component={Issues} />
        <Route path="/messages" component={Messages} />
        <Route path="/campaigns" component={Campaigns} />
        <Route path="/calendar" component={CalendarPage} />
        <Route path="/assembly" component={AssemblyDashboard} />
        <Route path="/ai-intake" component={AiIntake} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
