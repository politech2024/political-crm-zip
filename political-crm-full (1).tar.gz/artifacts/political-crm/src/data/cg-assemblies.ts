export interface Assembly {
  number: number;
  name: string;
  district: string;
  lok_sabha: string;
}

export const CG_ASSEMBLIES: Assembly[] = [
  { number: 1,  name: "Bharatpur-Sonhat",       district: "Manendragarh-Chirmiri-Bharatpur", lok_sabha: "Korba" },
  { number: 2,  name: "Manendragarh",            district: "Manendragarh-Chirmiri-Bharatpur", lok_sabha: "Korba" },
  { number: 3,  name: "Baikunthpur",             district: "Koriya",                          lok_sabha: "Korba" },
  { number: 4,  name: "Premnagar",               district: "Surajpur",                        lok_sabha: "Surguja" },
  { number: 5,  name: "Bhatgaon",                district: "Surajpur",                        lok_sabha: "Surguja" },
  { number: 6,  name: "Pratappur",               district: "Balrampur",                       lok_sabha: "Surguja" },
  { number: 7,  name: "Ramanujganj",             district: "Balrampur",                       lok_sabha: "Surguja" },
  { number: 8,  name: "Samri",                   district: "Balrampur",                       lok_sabha: "Surguja" },
  { number: 9,  name: "Lundra",                  district: "Surguja",                         lok_sabha: "Surguja" },
  { number: 10, name: "Ambikapur",               district: "Surguja",                         lok_sabha: "Surguja" },
  { number: 11, name: "Sitapur",                 district: "Surguja",                         lok_sabha: "Surguja" },
  { number: 12, name: "Jashpur",                 district: "Jashpur",                         lok_sabha: "Raigarh" },
  { number: 13, name: "Kunkuri",                 district: "Jashpur",                         lok_sabha: "Raigarh" },
  { number: 14, name: "Pathalgaon",              district: "Jashpur",                         lok_sabha: "Raigarh" },
  { number: 15, name: "Lailunga",                district: "Raigarh",                         lok_sabha: "Raigarh" },
  { number: 16, name: "Raigarh",                 district: "Raigarh",                         lok_sabha: "Raigarh" },
  { number: 17, name: "Sarangarh",               district: "Sarangarh-Bilaigarh",             lok_sabha: "Raigarh" },
  { number: 18, name: "Kharsia",                 district: "Raigarh",                         lok_sabha: "Raigarh" },
  { number: 19, name: "Dharamjaigarh",           district: "Raigarh",                         lok_sabha: "Raigarh" },
  { number: 20, name: "Rampur",                  district: "Korba",                           lok_sabha: "Korba" },
  { number: 21, name: "Korba",                   district: "Korba",                           lok_sabha: "Korba" },
  { number: 22, name: "Katghora",                district: "Korba",                           lok_sabha: "Korba" },
  { number: 23, name: "Pali-Tanakhar",           district: "Korba",                           lok_sabha: "Korba" },
  { number: 24, name: "Marwahi",                 district: "Gaurela-Pendra-Marwahi",          lok_sabha: "Korba" },
  { number: 25, name: "Kota",                    district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 26, name: "Lormi",                   district: "Mungeli",                         lok_sabha: "Bilaspur" },
  { number: 27, name: "Mungeli",                 district: "Mungeli",                         lok_sabha: "Bilaspur" },
  { number: 28, name: "Takhatpur",               district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 29, name: "Bilha",                   district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 30, name: "Bilaspur",                district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 31, name: "Beltara",                 district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 32, name: "Masturi",                 district: "Bilaspur",                        lok_sabha: "Bilaspur" },
  { number: 33, name: "Akaltara",                district: "Janjgir-Champa",                  lok_sabha: "Janjgir-Champa" },
  { number: 34, name: "Janjgir-Champa",          district: "Janjgir-Champa",                  lok_sabha: "Janjgir-Champa" },
  { number: 35, name: "Sakti",                   district: "Sakti",                           lok_sabha: "Janjgir-Champa" },
  { number: 36, name: "Chandrapur",              district: "Sakti",                           lok_sabha: "Janjgir-Champa" },
  { number: 37, name: "Jaijaipur",               district: "Janjgir-Champa",                  lok_sabha: "Janjgir-Champa" },
  { number: 38, name: "Pamgarh",                 district: "Janjgir-Champa",                  lok_sabha: "Janjgir-Champa" },
  { number: 39, name: "Saraipali",               district: "Mahasamund",                      lok_sabha: "Mahasamund" },
  { number: 40, name: "Basna",                   district: "Mahasamund",                      lok_sabha: "Mahasamund" },
  { number: 41, name: "Khallari",                district: "Mahasamund",                      lok_sabha: "Mahasamund" },
  { number: 42, name: "Mahasamund",              district: "Mahasamund",                      lok_sabha: "Mahasamund" },
  { number: 43, name: "Bilaigarh",               district: "Baloda Bazar",                    lok_sabha: "Mahasamund" },
  { number: 44, name: "Kasdol",                  district: "Baloda Bazar",                    lok_sabha: "Mahasamund" },
  { number: 45, name: "Baloda Bazar",            district: "Baloda Bazar",                    lok_sabha: "Raipur" },
  { number: 46, name: "Bhatapara",               district: "Baloda Bazar",                    lok_sabha: "Raipur" },
  { number: 47, name: "Dharsiwa",                district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 48, name: "Raipur Rural",            district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 49, name: "Raipur City West",        district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 50, name: "Raipur City North",       district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 51, name: "Raipur City South",       district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 52, name: "Arang",                   district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 53, name: "Abhanpur",                district: "Raipur",                          lok_sabha: "Raipur" },
  { number: 54, name: "Rajim",                   district: "Gariaband",                       lok_sabha: "Mahasamund" },
  { number: 55, name: "Bindranawagarh",          district: "Gariaband",                       lok_sabha: "Mahasamund" },
  { number: 56, name: "Sihawa",                  district: "Dhamtari",                        lok_sabha: "Mahasamund" },
  { number: 57, name: "Kurud",                   district: "Dhamtari",                        lok_sabha: "Mahasamund" },
  { number: 58, name: "Dhamtari",                district: "Dhamtari",                        lok_sabha: "Mahasamund" },
  { number: 59, name: "Sanjari Balod",           district: "Balod",                           lok_sabha: "Kanker" },
  { number: 60, name: "Dondi Lohara",            district: "Balod",                           lok_sabha: "Kanker" },
  { number: 61, name: "Gunderdehi",              district: "Balod",                           lok_sabha: "Kanker" },
  { number: 62, name: "Patan",                   district: "Durg",                            lok_sabha: "Durg" },
  { number: 63, name: "Durg Rural",              district: "Durg",                            lok_sabha: "Durg" },
  { number: 64, name: "Durg City",               district: "Durg",                            lok_sabha: "Durg" },
  { number: 65, name: "Bhilai Nagar",            district: "Durg",                            lok_sabha: "Durg" },
  { number: 66, name: "Vaishali Nagar",          district: "Durg",                            lok_sabha: "Durg" },
  { number: 67, name: "Ahiwara",                 district: "Durg",                            lok_sabha: "Durg" },
  { number: 68, name: "Saja",                    district: "Bemetara",                        lok_sabha: "Rajnandgaon" },
  { number: 69, name: "Bemetara",                district: "Bemetara",                        lok_sabha: "Rajnandgaon" },
  { number: 70, name: "Navagarh",                district: "Bemetara",                        lok_sabha: "Rajnandgaon" },
  { number: 71, name: "Pandariya",               district: "Kabirdham",                       lok_sabha: "Rajnandgaon" },
  { number: 72, name: "Kawardha",                district: "Kabirdham",                       lok_sabha: "Rajnandgaon" },
  { number: 73, name: "Khairagarh",              district: "Khairagarh-Chhuikhadan-Gandai",  lok_sabha: "Rajnandgaon" },
  { number: 74, name: "Dongargarh",              district: "Rajnandgaon",                     lok_sabha: "Rajnandgaon" },
  { number: 75, name: "Rajnandgaon",             district: "Rajnandgaon",                     lok_sabha: "Rajnandgaon" },
  { number: 76, name: "Dongargaon",              district: "Rajnandgaon",                     lok_sabha: "Rajnandgaon" },
  { number: 77, name: "Khujji",                  district: "Rajnandgaon",                     lok_sabha: "Rajnandgaon" },
  { number: 78, name: "Mohla-Manpur",            district: "Mohla-Manpur",                    lok_sabha: "Rajnandgaon" },
  { number: 79, name: "Antagarh",                district: "Kanker",                          lok_sabha: "Kanker" },
  { number: 80, name: "Bhanupratappur",          district: "Kanker",                          lok_sabha: "Kanker" },
  { number: 81, name: "Kanker",                  district: "Kanker",                          lok_sabha: "Kanker" },
  { number: 82, name: "Keshkal",                 district: "Kondagaon",                       lok_sabha: "Bastar" },
  { number: 83, name: "Kondagaon",               district: "Kondagaon",                       lok_sabha: "Bastar" },
  { number: 84, name: "Narayanpur",              district: "Narayanpur",                      lok_sabha: "Bastar" },
  { number: 85, name: "Bastar",                  district: "Bastar",                          lok_sabha: "Bastar" },
  { number: 86, name: "Jagdalpur",               district: "Bastar",                          lok_sabha: "Bastar" },
  { number: 87, name: "Chitrakot",               district: "Bastar",                          lok_sabha: "Bastar" },
  { number: 88, name: "Dantewada",               district: "Dantewada",                       lok_sabha: "Bastar" },
  { number: 89, name: "Bijapur",                 district: "Bijapur",                         lok_sabha: "Bastar" },
  { number: 90, name: "Konta",                   district: "Sukma",                           lok_sabha: "Bastar" },
];

export const CG_DISTRICTS: string[] = [
  "Balod", "Baloda Bazar", "Balrampur", "Bastar", "Bemetara", "Bijapur",
  "Bilaspur", "Dantewada", "Dhamtari", "Durg", "Gariaband",
  "Gaurela-Pendra-Marwahi", "Janjgir-Champa", "Jashpur", "Kabirdham", "Kanker",
  "Khairagarh-Chhuikhadan-Gandai", "Kondagaon", "Korba", "Koriya", "Mahasamund",
  "Manendragarh-Chirmiri-Bharatpur", "Mohla-Manpur", "Mungeli", "Narayanpur",
  "Raigarh", "Raipur", "Rajnandgaon", "Sakti", "Sarangarh-Bilaigarh",
  "Sukma", "Surajpur", "Surguja",
];

export const CG_LOK_SABHA: string[] = [
  "Bastar", "Bilaspur", "Durg", "Janjgir-Champa", "Kanker",
  "Korba", "Mahasamund", "Raigarh", "Raipur", "Rajnandgaon", "Surguja",
];

export function getAssemblyByName(name: string): Assembly | undefined {
  return CG_ASSEMBLIES.find(a => a.name === name);
}

export function getAssembliesByDistrict(district: string): Assembly[] {
  return CG_ASSEMBLIES.filter(a => a.district === district);
}

export function getAssembliesByLokSabha(ls: string): Assembly[] {
  return CG_ASSEMBLIES.filter(a => a.lok_sabha === ls);
}
